# Dokumentacja projektu

## Dane projektu

| Pole | Wartosc |
| --- | --- |
| Nazwa projektu | Klub_Stal_Stalowa_Wola |
| Autor | Jan Kowalski |
| Numer albumu | 111111 |
| Technologia | Laravel, PHP, PostgreSQL, Blade, Tailwind CSS |
| Typ aplikacji | System obslugi kibicow i zarzadzania klubem pilkarskim |

## Cel projektu

Aplikacja **Klub_Stal_Stalowa_Wola** jest systemem internetowym przygotowanym dla klubu Stal Stalowa Wola. System pozwala gosciom przegladac podstawowe informacje o klubie, terminarz, tabele ligowa, kadre, historie oraz kontakt. Zalogowani kibice moga rezerwowac bilety na mecze, a uzytkownik z rola prezesa ma dostep do paneli administracyjnych.

Projekt korzysta z bazy PostgreSQL. Dane z bazy sa widoczne miedzy innymi na stronie glownej, w terminarzu, tabeli ligowej, kadrze oraz module biletow.

## Role uzytkownikow

| Rola | Uprawnienia |
| --- | --- |
| Gosc | Przegladanie strony glownej, terminarza, tabeli, kadry, historii i kontaktu |
| Kibic | Rezerwacja biletow, podglad wlasnych biletow oraz kodow rezerwacji |
| Prezes | Zarzadzanie terminarzem, kadra, tabela ligowa oraz pelnymi danymi rezerwacji |

### Konto prezesa

```text
E-mail: prezes@stal.pl
Haslo: 1938St@lowka
```

Haslo nie jest przechowywane jawnie w bazie danych. Laravel zapisuje je w postaci hasha.

## Najwazniejsze funkcje

### Strona glowna

Strona glowna daje gosciowi szybki wglad w system i pokazuje dane pobierane z bazy:

- najblizszy mecz,
- najblizsze mecze z terminarza,
- czolowke tabeli ligowej,
- panel zalezy od statusu zalogowania uzytkownika.

Panel zmienia sie w zaleznosci od roli. Gosc widzi zachete do logowania lub rejestracji, kibic szybki dostep do biletow, a prezes skroty do zarzadzania systemem.

### Terminarz

Zakladka **Terminarz** prezentuje czysta liste meczow: data, godzina, rywal oraz miejsce rozegrania spotkania. Dane meczow sa powiazane z tabela druzyn, dzieki czemu nie trzeba powielac nazw zespolow.

Prezes moze dodawac, edytowac i usuwac mecze.

### Tabela

Zakladka **Tabela** prezentuje klasyczna tabele ligowa Betclic 2. Ligi. Zespoly sa sortowane wedlug:

1. liczby punktow,
2. bilansu bramkowego,
3. liczby strzelonych bramek,
4. nazwy druzyny.

Prezes moze dodawac, edytowac i usuwac zespoly oraz zmieniac ich statystyki.

### Kadra

Zakladka **Kadra** pokazuje pilkarzy i sztab. Dostepne sa:

- wyszukiwanie po imieniu, nazwisku i numerze,
- filtrowanie po pozycji,
- sortowanie po numerze, nazwisku, golach i wystepach.

Formularze maja walidacje, dlatego nie mozna dodac pilkarza z niepoprawnym imieniem, nazwiskiem lub stanowiskiem.

### Bilety

Zakladka **Bilety** zawiera prosty formularz rezerwacji biletu. Kibic wybiera:

- mecz,
- trybune lub sektor,
- typ biletu: normalny albo ulgowy.

Po zapisaniu system generuje kod biletu, np. `STAL-1234-XYZ`, i zapisuje rezerwacje w bazie danych.

Ograniczenia:

- bilety moga kupowac tylko zalogowani kibice,
- gosc widzi komunikat z przyciskami logowania i rejestracji,
- jeden kibic moze kupic maksymalnie jeden bilet na jeden mecz,
- prezes widzi pelne dane kibica, w tym PESEL.

## Struktura bazy danych

Najwazniejsze tabele:

| Tabela | Opis |
| --- | --- |
| `uzytkownicy` | Konta uzytkownikow, role, dane osobowe i hashe hasel |
| `druzyny` | Zespoly ligowe oraz ich statystyki |
| `mecze` | Terminarz spotkan, powiazany z druzynami |
| `pilkarze` | Kadra zawodnikow i sztabu |
| `bilety` | Rezerwacje biletow oraz kody biletow |

Relacja miedzy meczami i druzynami pozwala utrzymac poprawna strukture bez powtarzania danych.

## Walidacja danych

W systemie zastosowano walidacje formularzy:

- imie i nazwisko musza skladac sie z liter, spacji lub myslnikow,
- PESEL musi miec 11 cyfr,
- e-mail musi miec poprawny format i byc unikalny,
- haslo jest wymagane przy rejestracji,
- statystyki liczbowe nie moga byc ujemne,
- pozycja pilkarza musi nalezec do dozwolonej listy.

## Bezpieczenstwo

- Hasla sa hashowane mechanizmem Laravel.
- Zakup biletu wymaga zalogowania.
- Panel prezesa jest dostepny tylko dla uzytkownika z rola `prezes`.
- Po zalogowaniu cofniecie w przegladarce nie powinno pokazywac ponownie formularza logowania jako aktywnego ekranu konta.
- Dane wrazliwe nie powinny byc publikowane w repozytorium w pliku `.env`.

## Responsywnosc

Widoki zostaly przygotowane tak, aby dzialaly na komputerze oraz w trybie tabletu testowanym przez narzedzia developerskie przegladarki. Nawigacja, tabele, formularze i karty dopasowuja sie do mniejszej szerokosci ekranu.

## Uruchomienie projektu

1. Skopiowac `.env.example` do `.env`.
2. Ustawic polaczenie z baza PostgreSQL.
3. Zainstalowac zaleznosci:

```bash
composer install
```

4. Wygenerowac klucz aplikacji:

```bash
php artisan key:generate
```

5. Wykonac migracje i seedery:

```bash
php artisan migrate --seed
```

6. Uruchomic aplikacje:

```bash
php artisan serve
```

## Testowanie

Sprawdzone elementy:

- migracje bazy danych,
- poprawne ladowanie strony glownej,
- poprawne ladowanie terminarza,
- poprawne ladowanie tabeli,
- poprawne ladowanie kadry,
- poprawne ladowanie biletow,
- walidacja formularzy,
- konto prezesa,
- favicon,
- responsywnosc widokow.
