<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            DruzynySeeder::class,
            DaneLigoweSeeder::class,
            UzytkownikSeeder::class,
            PilkarzSeeder::class,
            StatystykiPilkarzySeeder::class,
        ]);
    }
}
