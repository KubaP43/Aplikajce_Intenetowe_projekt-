<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StatystykiPilkarzySeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('TRUNCATE TABLE statystyki_pilkarzy RESTART IDENTITY CASCADE');

        $stats = [
            'Smyłek' => ['wystepy' => 16, 'minuty' => 1470, 'gole' => 0, 'asysty' => 0, 'czyste_konta' => 1, 'zolte_kartki' => 1, 'czerwone_kartki' => 0],
            'Stępak' => ['wystepy' => 17, 'minuty' => 1530, 'gole' => 0, 'asysty' => 0, 'czyste_konta' => 1, 'zolte_kartki' => 1, 'czerwone_kartki' => 0],
            'Harciński' => ['wystepy' => 0, 'minuty' => 0, 'gole' => 0, 'asysty' => 0, 'czyste_konta' => 0, 'zolte_kartki' => 0, 'czerwone_kartki' => 0],
            'Kukułowicz' => ['wystepy' => 28, 'minuty' => 1479, 'gole' => 4, 'asysty' => 3, 'czyste_konta' => 0, 'zolte_kartki' => 7, 'czerwone_kartki' => 0],
            'Furtak' => ['wystepy' => 26, 'minuty' => 2364, 'gole' => 1, 'asysty' => 0, 'czyste_konta' => 0, 'zolte_kartki' => 10, 'czerwone_kartki' => 2],
            'Żemło' => ['wystepy' => 26, 'minuty' => 2179, 'gole' => 2, 'asysty' => 1, 'czyste_konta' => 0, 'zolte_kartki' => 11, 'czerwone_kartki' => 0],
            'Zaucha' => ['wystepy' => 33, 'minuty' => 2514, 'gole' => 5, 'asysty' => 2, 'czyste_konta' => 0, 'zolte_kartki' => 2, 'czerwone_kartki' => 0],
            'Getinger' => ['wystepy' => 26, 'minuty' => 2113, 'gole' => 0, 'asysty' => 3, 'czyste_konta' => 0, 'zolte_kartki' => 5, 'czerwone_kartki' => 0],
            'Oko' => ['wystepy' => 21, 'minuty' => 1749, 'gole' => 4, 'asysty' => 0, 'czyste_konta' => 0, 'zolte_kartki' => 6, 'czerwone_kartki' => 1],
            'Radecki' => ['wystepy' => 32, 'minuty' => 2311, 'gole' => 2, 'asysty' => 1, 'czyste_konta' => 0, 'zolte_kartki' => 9, 'czerwone_kartki' => 1],
            'Hrnciar' => ['wystepy' => 32, 'minuty' => 1927, 'gole' => 1, 'asysty' => 6, 'czyste_konta' => 0, 'zolte_kartki' => 4, 'czerwone_kartki' => 0],
            'Hebel' => ['wystepy' => 33, 'minuty' => 2423, 'gole' => 5, 'asysty' => 10, 'czyste_konta' => 0, 'zolte_kartki' => 7, 'czerwone_kartki' => 0],
            'Surzyn' => ['wystepy' => 28, 'minuty' => 1327, 'gole' => 0, 'asysty' => 1, 'czyste_konta' => 0, 'zolte_kartki' => 0, 'czerwone_kartki' => 0],
            'Nowak' => ['wystepy' => 12, 'minuty' => 632, 'gole' => 1, 'asysty' => 1, 'czyste_konta' => 0, 'zolte_kartki' => 2, 'czerwone_kartki' => 0],
            'Lelek' => ['wystepy' => 19, 'minuty' => 835, 'gole' => 3, 'asysty' => 0, 'czyste_konta' => 0, 'zolte_kartki' => 1, 'czerwone_kartki' => 0],
            'Tomalski' => ['wystepy' => 26, 'minuty' => 1281, 'gole' => 1, 'asysty' => 2, 'czyste_konta' => 0, 'zolte_kartki' => 3, 'czerwone_kartki' => 0],
            'Wolny' => ['wystepy' => 34, 'minuty' => 1719, 'gole' => 11, 'asysty' => 1, 'czyste_konta' => 0, 'zolte_kartki' => 4, 'czerwone_kartki' => 0],
            'Śpiewak' => ['wystepy' => 14, 'minuty' => 803, 'gole' => 1, 'asysty' => 0, 'czyste_konta' => 0, 'zolte_kartki' => 2, 'czerwone_kartki' => 0],
            'Kendzia' => ['wystepy' => 29, 'minuty' => 1912, 'gole' => 5, 'asysty' => 4, 'czyste_konta' => 0, 'zolte_kartki' => 0, 'czerwone_kartki' => 1],
        ];

        foreach ($stats as $nazwisko => $dane) {
            $pilkarz = DB::table('pilkarze')->where('nazwisko', 'ILIKE', $nazwisko)->first();

            if ($pilkarz) {
                DB::table('statystyki_pilkarzy')->updateOrInsert(
                    ['pilkarz_id' => $pilkarz->id],
                    array_merge($dane, [
                        'created_at' => now(),
                        'updated_at' => now(),
                    ])
                );
            }
        }
    }
}