<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DaneLigoweSeeder extends Seeder
{
    public function run(): void
    {
        $mecze = [
            [
                'rywal' => 'Polonia Bytom',
                'data_meczu' => '2026-06-11 17:00:00',
                'miejsce' => 'Stadion wyjazdowy',
                'czy_domowy' => false,
            ],
            [
                'rywal' => 'Kotwica Kołobrzeg',
                'data_meczu' => '2026-06-18 18:00:00',
                'miejsce' => 'Stadion wyjazdowy',
                'czy_domowy' => false,
            ],
            [
                'rywal' => 'KKS 1925 Kalisz',
                'data_meczu' => '2026-06-25 15:00:00',
                'miejsce' => 'Stadion wyjazdowy',
                'czy_domowy' => false,
            ],
            [
                'rywal' => 'Chojniczanka Chojnice',
                'data_meczu' => '2026-07-05 18:00:00',
                'miejsce' => 'PCPN Stalowa Wola',
                'czy_domowy' => true,
            ],
        ];

        foreach ($mecze as $mecz) {
            $druzynaId = DB::table('druzyny')->where('nazwa', $mecz['rywal'])->value('id');

            if (!$druzynaId) {
                continue;
            }

            DB::table('mecze')->updateOrInsert(
                [
                    'druzyna_id' => $druzynaId,
                    'data_meczu' => $mecz['data_meczu'],
                ],
                [
                    'miejsce' => $mecz['miejsce'],
                    'czy_domowy' => $mecz['czy_domowy'],
                    'wynik_stal' => null,
                    'wynik_rywal' => null,
                    'status' => 'Planowany',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}
