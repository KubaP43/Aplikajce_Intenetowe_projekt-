<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DruzynySeeder extends Seeder
{
    public function run(): void
    {
        $druzyny = [
            ['nazwa' => 'Polonia Bytom', 'punkty' => 38, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 34, 'bramki_stracone' => 17],
            ['nazwa' => 'KKS 1925 Kalisz', 'punkty' => 35, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 29, 'bramki_stracone' => 18],
            ['nazwa' => 'Stal Stalowa Wola', 'punkty' => 33, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 28, 'bramki_stracone' => 20],
            ['nazwa' => 'Chojniczanka Chojnice', 'punkty' => 31, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 27, 'bramki_stracone' => 19],
            ['nazwa' => 'Kotwica Kołobrzeg', 'punkty' => 30, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 25, 'bramki_stracone' => 20],
            ['nazwa' => 'Hutnik Kraków', 'punkty' => 29, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 24, 'bramki_stracone' => 21],
            ['nazwa' => 'Rekord Bielsko-Biała', 'punkty' => 27, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 23, 'bramki_stracone' => 22],
            ['nazwa' => 'Sandecja Nowy Sącz', 'punkty' => 26, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 21, 'bramki_stracone' => 19],
            ['nazwa' => 'GKS Jastrzębie', 'punkty' => 25, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 22, 'bramki_stracone' => 23],
            ['nazwa' => 'Olimpia Grudziądz', 'punkty' => 24, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 20, 'bramki_stracone' => 21],
            ['nazwa' => 'Wisła Puławy', 'punkty' => 23, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 19, 'bramki_stracone' => 21],
            ['nazwa' => 'Stomil Olsztyn', 'punkty' => 22, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 18, 'bramki_stracone' => 22],
            ['nazwa' => 'Olimpia Elbląg', 'punkty' => 21, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 18, 'bramki_stracone' => 24],
            ['nazwa' => 'Skra Częstochowa', 'punkty' => 20, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 17, 'bramki_stracone' => 23],
            ['nazwa' => 'Podhale Nowy Targ', 'punkty' => 19, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 16, 'bramki_stracone' => 24],
            ['nazwa' => 'Pogoń Siedlce', 'punkty' => 18, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 15, 'bramki_stracone' => 25],
            ['nazwa' => 'ŁKS II Łódź', 'punkty' => 17, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 16, 'bramki_stracone' => 28],
            ['nazwa' => 'Zagłębie II Lubin', 'punkty' => 15, 'mecze_rozegrane' => 18, 'bramki_zdobyte' => 14, 'bramki_stracone' => 30],
        ];

        foreach ($druzyny as $druzyna) {
            DB::table('druzyny')->updateOrInsert(
                ['nazwa' => $druzyna['nazwa']],
                array_merge($druzyna, [
                    'created_at' => now(),
                    'updated_at' => now(),
                ])
            );
        }
    }
}
