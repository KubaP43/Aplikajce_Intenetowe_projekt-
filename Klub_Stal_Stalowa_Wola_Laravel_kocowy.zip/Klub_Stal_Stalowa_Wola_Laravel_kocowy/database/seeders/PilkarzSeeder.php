<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PilkarzSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('TRUNCATE TABLE pilkarze RESTART IDENTITY CASCADE');

        $ludzie = [
            // BRAMKARZE
            ['imie' => 'Krystian', 'nazwisko' => 'Harciński', 'pozycja' => 'Bramkarz', 'numer' => 1, 'zdjecie' => 'Krystian_Harcinski.png'],
            ['imie' => 'Mikołaj', 'nazwisko' => 'Smyłek', 'pozycja' => 'Bramkarz', 'numer' => 12, 'zdjecie' => 'Mikołaj_Smylek.png'], // ł jest, e nie ma
            ['imie' => 'Jakub', 'nazwisko' => 'Stępak', 'pozycja' => 'Bramkarz', 'numer' => 33, 'zdjecie' => 'Jakub_Stepak.png'],

            // OBROŃCY
            ['imie' => 'Bartłomiej', 'nazwisko' => 'Kukułowicz', 'pozycja' => 'Obrońca', 'numer' => 2, 'zdjecie' => 'Bartlomiej_Kukulowicz.png'],
            ['imie' => 'Łukasz', 'nazwisko' => 'Furtak', 'pozycja' => 'Obrońca', 'numer' => 3, 'zdjecie' => 'Lukasz_Furtak.png'],
            ['imie' => 'Piotr', 'nazwisko' => 'Żemło', 'pozycja' => 'Obrońca', 'numer' => 4, 'zdjecie' => 'Piotr_Zemlo.png'],
            ['imie' => 'Maciej', 'nazwisko' => 'Jaroszewski', 'pozycja' => 'Obrońca', 'numer' => 5, 'zdjecie' => 'Maciej_Jaroszewski.png'],
            ['imie' => 'Krystian', 'nazwisko' => 'Getinger', 'pozycja' => 'Obrońca', 'numer' => 6, 'zdjecie' => 'Krystian_Getinger.png'],
            ['imie' => 'Igor', 'nazwisko' => 'Fedejko', 'pozycja' => 'Obrońca', 'numer' => 13, 'zdjecie' => 'Igor_Fedejko.png'],
            ['imie' => 'Damian', 'nazwisko' => 'Oko', 'pozycja' => 'Obrońca', 'numer' => 22, 'zdjecie' => 'Damian_Oko.png'],

            // POMOCNICY
            ['imie' => 'Mateusz', 'nazwisko' => 'Radecki', 'pozycja' => 'Pomocnik', 'numer' => 7, 'zdjecie' => 'Mateusz_Radecki.png'],
            ['imie' => 'Lukas', 'nazwisko' => 'Hrnciar', 'pozycja' => 'Pomocnik', 'numer' => 8, 'zdjecie' => 'Lukas_Hrnciar.png'],
            ['imie' => 'Maksymilian', 'nazwisko' => 'Hebel', 'pozycja' => 'Pomocnik', 'numer' => 10, 'zdjecie' => 'Maksymilian_Hebel.png'],
            ['imie' => 'Patryk', 'nazwisko' => 'Zaucha', 'pozycja' => 'Pomocnik', 'numer' => 11, 'zdjecie' => 'Patryk_Zaucha.png'],
            ['imie' => 'Krystian', 'nazwisko' => 'Lelek', 'pozycja' => 'Pomocnik', 'numer' => 14, 'zdjecie' => 'Krystian_Lelek.png'],
            ['imie' => 'Hubert', 'nazwisko' => 'Tomalski', 'pozycja' => 'Pomocnik', 'numer' => 17, 'zdjecie' => 'Hubert_Tomalski.png'],
            ['imie' => 'Michał', 'nazwisko' => 'Surzyn', 'pozycja' => 'Pomocnik', 'numer' => 18, 'zdjecie' => 'Michał_Surzyn.png'],
            ['imie' => 'Jakub', 'nazwisko' => 'Niedbała', 'pozycja' => 'Pomocnik', 'numer' => 19, 'zdjecie' => 'Jakub_Niedbala.png'],
            ['imie' => 'Jakub', 'nazwisko' => 'Sobeczko', 'pozycja' => 'Pomocnik', 'numer' => 20, 'zdjecie' => 'Jakub_Sobeczko.png'],
            ['imie' => 'Piotr', 'nazwisko' => 'Wójs', 'pozycja' => 'Pomocnik', 'numer' => 21, 'zdjecie' => 'Piotr_Wojs.png'], // Poprawiony klucz i nazwa pliku!
            ['imie' => 'Jakub', 'nazwisko' => 'Kendzia', 'pozycja' => 'Pomocnik', 'numer' => 23, 'zdjecie' => 'Jakub_Kendzia.png'],

            // NAPASTNICY
            ['imie' => 'Dawid', 'nazwisko' => 'Wolny', 'pozycja' => 'Napastnik', 'numer' => 9, 'zdjecie' => 'Dawid_Wolny.png'],
            ['imie' => 'Kacper', 'nazwisko' => 'Śpiewak', 'pozycja' => 'Napastnik', 'numer' => 90, 'zdjecie' => 'Kacper_Spiewak.png'],
            ['imie' => 'Olaf', 'nazwisko' => 'Nowak', 'pozycja' => 'Napastnik', 'numer' => 99, 'zdjecie' => 'Olaf_Nowak.png'],

            // SZTAB SZKOLENIOWY
            ['imie' => 'Dariusz', 'nazwisko' => 'Kantor', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Dariusz_Kantor.png'],
            ['imie' => 'Stanisław', 'nazwisko' => 'Szpyrka', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Stanislaw_Szpyrka.png'], // w VS Code masz Stanislaw_Szpyrka
            ['imie' => 'Paweł', 'nazwisko' => 'Żmuda', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Paweł_Zmuda.png'], // Żmuda, ale w pliku Zmuda
            ['imie' => 'Przemysław', 'nazwisko' => 'Stelmach', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Przemysław_Stelmach.png'],
            ['imie' => 'Anna', 'nazwisko' => 'Galant', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Anna_Galant.png'],
            ['imie' => 'Adrian', 'nazwikso' => 'Golik', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Adrian_Golik.png'],
            ['imie' => 'Tomasz', 'nazwisko' => 'Wietecha', 'pozycja' => 'Sztab', 'numer' => 0, 'zdjecie' => 'Tomasz_Wietecha.png'],
        ];

        foreach ($ludzie as $czlowiek) {
            DB::table('pilkarze')->insert([
                'imie' => $czlowiek['imie'],
                'nazwisko' => $czlowiek['nazwisko'] ?? $czlowiek['nazwisry'] ?? $czlowiek['nazwikso'] ?? '',
                'pozycja' => $czlowiek['pozycja'],
                'numer' => $czlowiek['numer'],
                'zdjecie' => $czlowiek['zdjecie'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}