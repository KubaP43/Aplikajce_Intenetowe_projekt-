<?php

namespace Database\Seeders;

use App\Models\Uzytkownik;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UzytkownikSeeder extends Seeder
{
    public function run(): void
    {
        Uzytkownik::updateOrCreate(
            ['email' => 'prezes@stal.pl'],
            [
                'imie' => 'Marek',
                'nazwisko' => 'Karabuła',
                'pesel' => '12345678900',
                'data_urodzenia' => '1980-01-01',
                'password' => Hash::make('1938St@lowka'),
                'rola' => 'prezes',
            ]
        );
    }
}
