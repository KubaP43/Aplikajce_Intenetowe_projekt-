<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bilety', function (Blueprint $table) {
            $table->unique(['uzytkownik_id', 'mecz_id'], 'bilety_uzytkownik_mecz_unique');
        });
    }

    public function down(): void
    {
        Schema::table('bilety', function (Blueprint $table) {
            $table->dropUnique('bilety_uzytkownik_mecz_unique');
        });
    }
};
