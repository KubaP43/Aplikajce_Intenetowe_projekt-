<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('druzyny', function (Blueprint $table) {
            $table->id();
            $table->string('nazwa')->unique();
            $table->integer('punkty')->default(0);
            $table->integer('mecze_rozegrane')->default(0);
            $table->integer('bramki_zdobyte')->default(0);
            $table->integer('bramki_stracone')->default(0);
            $table->timestamps();
        });
    }
};