<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('mecze', 'przeciwnik')) {
            Schema::table('mecze', function (Blueprint $table) {
                $table->dropColumn('przeciwnik');
            });
        }

        if (Schema::hasColumn('mecze', 'rywal')) {
            Schema::table('mecze', function (Blueprint $table) {
                $table->dropColumn('rywal');
            });
        }

        Schema::table('mecze', function (Blueprint $table) {
            if (!Schema::hasColumn('mecze', 'czy_domowy')) {
                $table->boolean('czy_domowy')->default(false);
            }
            if (!Schema::hasColumn('mecze', 'druzyna_id')) {
                $table->foreignId('druzyna_id')->constrained('druzyny')->onDelete('cascade');
            }
            if (!Schema::hasColumn('mecze', 'wynik_stal')) {
                $table->integer('wynik_stal')->nullable();
            }
            if (!Schema::hasColumn('mecze', 'wynik_rywal')) {
                $table->integer('wynik_rywal')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('mecze', function (Blueprint $table) {
            $table->dropForeign(['druzyna_id']);
            $table->dropColumn(['druzyna_id', 'czy_domowy', 'wynik_stal', 'wynik_rywal']);
            $table->string('rywal')->nullable();
        });
    }
};