<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('statystyki_pilkarzy', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pilkarz_id')->unique();
            $table->integer('wystepy')->default(0);
            $table->integer('minuty')->default(0);
            $table->integer('gole')->default(0);
            $table->integer('asysty')->default(0);
            $table->integer('czyste_konta')->default(0);
            $table->integer('zolte_kartki')->default(0);
            $table->integer('czerwone_kartki')->default(0);
            $table->timestamps();

            $table->foreign('pilkarz_id')->references('id')->on('pilkarze')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('statystyki_pilkarzy');
    }
};