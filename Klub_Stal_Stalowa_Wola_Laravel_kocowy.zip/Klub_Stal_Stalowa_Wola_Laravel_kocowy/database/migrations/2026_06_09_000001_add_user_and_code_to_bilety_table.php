<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bilety', function (Blueprint $table) {
            if (!Schema::hasColumn('bilety', 'uzytkownik_id')) {
                $table->foreignId('uzytkownik_id')
                    ->nullable()
                    ->after('id')
                    ->constrained('uzytkownicy')
                    ->nullOnDelete();
            }

            if (!Schema::hasColumn('bilety', 'kod_biletu')) {
                $table->string('kod_biletu', 32)->nullable()->unique()->after('uzytkownik_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('bilety', function (Blueprint $table) {
            if (Schema::hasColumn('bilety', 'uzytkownik_id')) {
                $table->dropConstrainedForeignId('uzytkownik_id');
            }

            if (Schema::hasColumn('bilety', 'kod_biletu')) {
                $table->dropColumn('kod_biletu');
            }
        });
    }
};
