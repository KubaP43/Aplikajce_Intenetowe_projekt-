<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::dropIfExists('mecze');

        Schema::create('mecze', function (Blueprint $table) {
            $table->id();
            $table->string('rywal');
            $table->dateTime('data_meczu');
            $table->string('miejsce');
            $table->string('status')->default('Planowany');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mecze');
    }
};