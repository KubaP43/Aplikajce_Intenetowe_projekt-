<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pilkarze', function (Blueprint $table) {
            $table->id();
            $table->string('imie', 50);
            $table->string('nazwisko', 50);
            $table->integer('numer'); // Numer na koszulce
            $table->string('pozycja'); // Bramkarz, Obrona, Pomoc, Napad
            $table->string('zdjecie')->nullable(); // Ścieżka do zdjęcia (opcjonalne)
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pilkarze');
    }
};