<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('uzytkownicy', function (Blueprint $table) {
            $table->id();
            $table->string('imie', 50);
            $table->string('nazwisko', 50);
            
            // PESEL – unikalny strażnik w bazie, maksymalnie 11 znaków
            $table->string('pesel', 11)->unique(); 
            
            // Data urodzenia (pole kalendarza)
            $table->date('data_urodzenia');
            
            // Adres e-mail jako unikalny login do systemu
            $table->string('email')->unique(); 
            
            $table->string('password');      // Zaszyfrowane silne hasło
            $table->string('rola')->default('kibic'); // Rola: 'kibic' lub 'prezes'
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('uzytkownicy');
    }
};