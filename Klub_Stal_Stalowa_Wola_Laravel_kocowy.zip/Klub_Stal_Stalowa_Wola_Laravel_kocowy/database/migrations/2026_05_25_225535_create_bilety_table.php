<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bilety', function (Blueprint $table) {
            $table->id();
            
            $table->unsignedBigInteger('mecz_id');
            $table->foreign('mecz_id')->references('id')->on('mecze')->onDelete('cascade');
            
            $table->string('sektor');
            $table->integer('rzad');
            $table->integer('miejsce');
            $table->string('typ_biletu');
            $table->integer('znizka')->default(0);
            $table->string('imie_nazwisko_kibica');
            $table->string('pesel_kibica', 11);
            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bilety');
    }
};