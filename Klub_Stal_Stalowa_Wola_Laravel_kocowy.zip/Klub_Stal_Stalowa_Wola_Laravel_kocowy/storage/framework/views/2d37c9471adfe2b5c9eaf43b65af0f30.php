

<?php $__env->startSection('tresc'); ?>
    <div class="p-8 max-w-4xl mx-auto">
        
        <div class="mb-6">
            <h2 class="text-2xl font-bold uppercase text-stalCzarny">Kontakt z Klubem</h2>
            <p class="text-gray-500 text-xs">Masz pytania? Skontaktuj się z biurem Stali Stalowa Wola</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div class="bg-white p-6 rounded shadow-sm border-t-4 border-stalZielony space-y-4">
                <div>
                    <h3 class="font-bold text-sm uppercase text-gray-400 mb-1">Adres Siedziby</h3>
                    <p class="text-sm font-medium text-gray-900">Stal Stalowa Wola PSA</p>
                    <p class="text-xs text-gray-600">ul. Hutnicza 15</p>
                    <p class="text-xs text-gray-600">37-450 Stalowa Wola</p>
                </div>

                <div class="border-t pt-3">
                    <h3 class="font-bold text-sm uppercase text-gray-400 mb-1">Sekretariat i Biuro</h3>
                    <p class="text-xs text-gray-600">Telefon: <span class="font-medium text-gray-900">+48 15 842 10 25</span></p>
                    <p class="text-xs text-gray-600">E-mail: <span class="font-medium text-gray-900">klub@stalstalowawola.pl</span></p>
                </div>

                <div class="border-t pt-3">
                    <h3 class="font-bold text-sm uppercase text-gray-400 mb-1">Dział Prasowy / Akredytacje</h3>
                    <p class="text-xs text-gray-600">E-mail: <span class="font-medium text-gray-900">media@stalstalowawola.pl</span></p>
                </div>
            </div>

            <div class="bg-white p-6 rounded shadow-sm border-t-4 border-stalCzarny space-y-4">
                <div>
                    <h3 class="font-bold text-sm uppercase text-gray-400 mb-1">Godziny pracy biura</h3>
                    <p class="text-xs text-gray-600">Poniedziałek - Piątek: <span class="font-medium text-gray-950">8:00 - 15:00</span></p>
                    <p class="text-xs text-gray-500 mt-1">W dni meczowe kasy stadionowe otwierane są na 2 godziny przed pierwszym gwizdkiem.</p>
                </div>

                <div class="border-t pt-3">
                    <h3 class="font-bold text-sm uppercase text-gray-400 mb-1">Lokalizacja</h3>
                    <p class="text-xs text-gray-600 leading-relaxed">
                        Biura klubu oraz oficjalny sklepik z pamiątkami znajdują się w budynku **Podkarpackiego Centrum Piłki Nożnej** (trybuna główna, wejście od ul. Hutniczej).
                    </p>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/kontakt.blade.php ENDPATH**/ ?>