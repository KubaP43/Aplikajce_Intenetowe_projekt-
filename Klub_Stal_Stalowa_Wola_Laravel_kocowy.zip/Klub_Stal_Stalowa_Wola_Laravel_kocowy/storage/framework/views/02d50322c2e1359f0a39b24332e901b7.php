

<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-8">

        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Dodaj do kadry</h1>
                <p class="text-xs text-gray-500 mt-0.5">Panel zarządzania klubem — Rola: Prezes</p>
            </div>
            <a href="<?php echo e(route('kadra.indeks')); ?>" class="text-xs font-bold uppercase tracking-wider bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition duration-200">
                ➔ Powrót
            </a>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <form action="<?php echo e(route('kadra.zapisz')); ?>" method="POST" enctype="multipart/form-data" class="p-8 space-y-6" novalidate>
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Imię</label>
                        <input type="text" name="imie" placeholder="np. Krystian" value="<?php echo e(old('imie')); ?>"
                               class="w-full border <?php $__errorArgs = ['imie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                        <?php $__errorArgs = ['imie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p>
                        <?php else: ?>
                            <p class="text-[10px] text-gray-400 mt-1">Tylko litery (bez cyfr)</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Nazwisko</label>
                        <input type="text" name="nazwisko" placeholder="np. Harciński" value="<?php echo e(old('nazwisko')); ?>"
                               class="w-full border <?php $__errorArgs = ['nazwisko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                        <?php $__errorArgs = ['nazwisko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p>
                        <?php else: ?>
                            <p class="text-[10px] text-gray-400 mt-1">Tylko litery (bez cyfr)</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Formacja / Rola</label>
                        <select name="pozycja" id="pozycja_select" required
                                class="w-full border border-gray-300 p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                            <option value="Bramkarz" <?php echo e(old('pozycja') == 'Bramkarz' ? 'selected' : ''); ?>>Bramkarz</option>
                            <option value="Obrońca" <?php echo e(old('pozycja') == 'Obrońca' ? 'selected' : ''); ?>>Obrońca</option>
                            <option value="Pomocnik" <?php echo e(old('pozycja') == 'Pomocnik' ? 'selected' : ''); ?>>Pomocnik</option>
                            <option value="Napastnik" <?php echo e(old('pozycja') == 'Napastnik' ? 'selected' : ''); ?>>Napastnik</option>
                            <option value="Sztab" <?php echo e(old('pozycja') == 'Sztab' ? 'selected' : ''); ?>>Sztab Szkoleniowy</option>
                        </select>
                    </div>

                    <div id="numer_container">
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Numer koszulki</label>
                        <input type="text" name="numer" id="numer_input" placeholder="np. 12" value="<?php echo e(old('numer')); ?>"
                               class="w-full border <?php $__errorArgs = ['numer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium font-mono">
                        <?php $__errorArgs = ['numer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p>
                        <?php else: ?>
                            <p class="text-[10px] text-gray-400 mt-1">Maksymalnie 2 cyfry (od 0 do 99)</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div id="funkcja_container" class="hidden">
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Funkcja w Sztabie</label>
                        <input type="text" name="funkcja_sztab" id="funkcja_input" placeholder="np. Motoryka" value="<?php echo e(old('funkcja_sztab')); ?>"
                               class="w-full border <?php $__errorArgs = ['funkcja_sztab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                        <?php $__errorArgs = ['funkcja_sztab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p>
                        <?php else: ?>
                            <p class="text-[10px] text-gray-400 mt-1">np. Trener, Asystent, Analityk</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="border-t border-gray-100 pt-6">
                    <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-2">Zdjęcie profilowe</label>
                    <div class="bg-gray-50 border border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center hover:bg-gray-100/50 transition cursor-pointer relative">
                        <input type="file" name="zdjecie" id="zdjecie_input" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer w-full h-full">
                        <span class="text-xs font-bold text-gray-700" id="file_status">Wybierz plik z dysku</span>
                        <span class="text-[10px] text-gray-400 mt-1">Format PNG lub JPG (Maksymalnie 2MB)</span>
                    </div>
                    <?php $__errorArgs = ['zdjecie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="border-t border-gray-100 pt-6 flex justify-end">
                    <button type="submit" class="w-full sm:w-auto bg-stalZielony hover:bg-green-700 text-white font-black px-8 py-3 rounded-lg text-xs uppercase tracking-widest shadow-md transition duration-200">
                        Zapisz i dodaj do bazy
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const pozycjaSelect = document.getElementById('pozycja_select');
        const numerContainer = document.getElementById('numer_container');
        const numerInput = document.getElementById('numer_input');
        const funkcjaContainer = document.getElementById('funkcja_container');
        const funkcjaInput = document.getElementById('funkcja_input');
        const zdjecieInput = document.getElementById('zdjecie_input');
        const fileStatus = document.getElementById('file_status');

        function toggleFields() {
            if (pozycjaSelect.value === 'Sztab') {
                numerContainer.classList.add('hidden');
                numerInput.value = '0';
                funkcjaContainer.classList.remove('hidden');
            } else {
                numerContainer.classList.remove('hidden');
                if(numerInput.value === '0') numerInput.value = '';
                funkcjaContainer.classList.add('hidden');
                funkcjaInput.value = '';
            }
        }

        zdjecieInput.addEventListener('change', function() {
            if(this.files && this.files.length > 0) {
                fileStatus.innerText = "Wybrano plik: " + this.files[0].name;
                fileStatus.classList.add('text-stalZielony');
            }
        });

        pozycjaSelect.addEventListener('change', toggleFields);
        toggleFields();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/kadra/dodaj.blade.php ENDPATH**/ ?>