

<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-7xl mx-auto px-8">

        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-8 gap-4">
            <div>
                <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Kadra Zespołu</h1>
                <p class="text-sm text-gray-500 mt-1">Pierwsza drużyna Stali Stalowa Wola — Sezon 2025/2026</p>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->rola === 'prezes'): ?>
                    <div class="mt-4 md:mt-0">
                        <a href="<?php echo e(route('kadra.dodaj')); ?>" class="inline-flex items-center gap-2 bg-stalZielony text-white font-bold px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider shadow hover:bg-green-700 transition duration-200">
                            Dodaj zawodnika
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6 max-w-3xl mx-auto">
            <form action="<?php echo e(route('kadra.indeks')); ?>" method="GET" class="flex flex-col sm:flex-row gap-4">
                <input type="hidden" name="pozycja" value="<?php echo e(request('pozycja')); ?>">
                <div class="flex-1">
                    <input type="text" name="szukaj" value="<?php echo e(request('szukaj')); ?>" placeholder="Wpisz imię, nazwisko lub numer zawodnika (max 99)..." 
                           class="w-full bg-gray-50 border border-gray-300 rounded-lg px-4 py-3 text-sm font-medium text-gray-800 placeholder-gray-400 focus:outline-none focus:border-stalZielony focus:ring-1 focus:ring-stalZielony transition duration-200">
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="bg-stalZielony hover:bg-green-700 text-white font-black px-8 py-3 rounded-lg text-xs uppercase tracking-widest shadow-md transition duration-200 flex-1 sm:flex-none text-center">
                        Szukaj
                    </button>
                    <?php if(request()->filled('szukaj') || request()->filled('pozycja')): ?>
                        <a href="<?php echo e(route('kadra.indeks')); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-black px-6 py-3 rounded-lg text-xs uppercase tracking-widest transition duration-200 flex-1 sm:flex-none text-center flex items-center justify-center">
                            Wyczyść
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-8">
            <form action="<?php echo e(route('kadra.indeks')); ?>" method="GET" id="filterForm" class="flex flex-col gap-3">
                <input type="hidden" name="szukaj" value="<?php echo e(request('szukaj')); ?>">
                <span class="text-xs font-black text-gray-400 uppercase tracking-widest pl-1">Filtruj formację:</span>
                
                <div class="flex flex-wrap gap-2">
                    <button type="submit" name="pozycja" value="" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == '' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Cała Drużyna
                    </button>

                    <button type="submit" name="pozycja" value="Bramkarz" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == 'Bramkarz' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Bramkarze
                    </button>

                    <button type="submit" name="pozycja" value="Obrońca" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == 'Obrońca' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Obrońcy
                    </button>

                    <button type="submit" name="pozycja" value="Pomocnik" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == 'Pomocnik' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Pomocnicy
                    </button>

                    <button type="submit" name="pozycja" value="Napastnik" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == 'Napastnik' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Napastnicy
                    </button>

                    <button type="submit" name="pozycja" value="Sztab" 
                            class="px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition duration-200 border 
                            <?php echo e(request('pozycja') == 'Sztab' ? 'bg-stalZielony text-white border-stalZielony shadow-md shadow-green-900/10' : 'bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100'); ?>">
                        Sztab Szkoleniowy
                    </button>
                </div>
            </form>
        </div>

        <?php if($pilkarze->isEmpty()): ?>
            <div class="bg-white p-12 rounded-xl shadow-sm text-center border border-gray-200">
                <p class="text-gray-500 font-medium text-sm">Brak zarejestrowanych osób spełniających kryteria wyszukiwania.</p>
            </div>
        <?php else: ?>
            <?php
                $filtrowanie = request('pozycja');
                
                if ($filtrowanie) {
                    if ($filtrowanie === 'Sztab') {
                        $sztabKolekcja = $pilkarze->filter(function($osoba) {
                            return \Illuminate\Support\Str::startsWith($osoba->pozycja, 'Sztab');
                        });
                        $grupy = ['Sztab Szkoleniowy' => $sztabKolekcja];
                    } else {
                        $grupy = [$filtrowanie . 'ze' => $pilkarze->where('pozycja', $filtrowanie)];
                    }
                } else {
                    $grupy = [
                        'Bramkarze' => $pilkarze->where('pozycja', 'Bramkarz'),
                        'Obrońcy' => $pilkarze->where('pozycja', 'Obrońca'),
                        'Pomocnicy' => $pilkarze->where('pozycja', 'Pomocnik'),
                        'Napastnicy' => $pilkarze->where('pozycja', 'Napastnik'),
                        'Sztab Szkoleniowy' => $pilkarze->filter(function($osoba) {
                            return \Illuminate\Support\Str::startsWith($osoba->pozycja, 'Sztab');
                        })
                    ];
                }

                $roleSztabu = [
                    'Kantor' => 'Trener',
                    'Szpyrka' => 'Asystent',
                    'Żmuda' => 'Motoryka',
                    'Stelmach' => 'Analityk',
                    'Galant' => 'Fizjoterapeuta',
                    'Golik' => 'Trener-Analityk',
                    'Wietecha' => 'Tr. Bramkarzy'
                ];
            ?>

            <?php $__currentLoopData = $grupy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nazwaGrupy => $czlonkowie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($czlonkowie->count() > 0): ?>
                    
                    <div class="mb-6 mt-10">
                        <h2 class="text-lg font-black text-stalCzarny uppercase tracking-widest border-l-4 border-stalZielony pl-3">
                            <?php echo e($nazwaGrupy); ?>

                        </h2>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-10 justify-items-center">
                        <?php $__currentLoopData = $czlonkowie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $osoba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-xl hover:border-stalZielony transition duration-300 flex flex-col justify-between relative group w-full max-w-xs">
                                
                                <div class="bg-gradient-to-b from-gray-50 to-gray-200 relative overflow-hidden h-80 w-full flex items-end justify-center">
                                    <?php if($osoba->numer > 0): ?>
                                        <span class="absolute top-4 right-5 font-mono text-3xl font-black text-gray-400/70 group-hover:text-stalZielony transition duration-300 z-20">
                                            #<?php echo e($osoba->numer); ?>

                                        </span>
                                    <?php endif; ?>

                                    <?php if($osoba->zdjecie): ?>
                                        <img src="<?php echo e(asset('images/Zdjecia_pilkarzy/' . $osoba->zdjecie)); ?>" 
                                             alt="<?php echo e($osoba->imie); ?> <?php echo e($osoba->nazwisko); ?>" 
                                             class="w-full h-full object-cover object-top transform group-hover:scale-105 transition duration-500 relative z-10">
                                    <?php else: ?>
                                        <div class="h-full flex items-center justify-center text-gray-300 pb-4">
                                            <svg class="w-36 h-36" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                                            </svg>
                                        </div>
                                    <?php endif; ?>

                                    <div class="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/20 to-transparent z-15"></div>
                                </div>

                                <div class="p-5 text-center bg-white border-t border-gray-100 flex-1 flex flex-col justify-between relative z-20">
                                    <div>
                                        <h3 class="font-bold text-gray-400 uppercase tracking-wider text-[10px]">
                                            <?php echo e($osoba->imie); ?>

                                        </h3>
                                        <h4 class="font-black text-stalCzarny uppercase tracking-wide text-lg -mt-0.5 group-hover:text-stalZielony transition duration-300">
                                            <?php echo e($osoba->nazwisko); ?>

                                        </h4>
                                    </div>
                                    
                                    <div class="mt-2.5">
                                        <span class="inline-block bg-gray-100 text-gray-700 text-[9px] font-black uppercase px-2.5 py-1 rounded-md tracking-wider border border-gray-200/60 group-hover:bg-green-50 group-hover:text-stalZielony group-hover:border-green-200 transition duration-300">
                                            <?php if(\Illuminate\Support\Str::startsWith($osoba->pozycja, 'Sztab')): ?>
                                                <?php if($osoba->pozycja === 'Sztab'): ?>
                                                    Sztab (<?php echo e($roleSztabu[$osoba->nazwisko] ?? 'Członek Sztabu'); ?>)
                                                <?php else: ?>
                                                    <?php echo e($osoba->pozycja); ?>

                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php echo e($osoba->pozycja); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                    <?php if(!\Illuminate\Support\Str::startsWith($osoba->pozycja, 'Sztab')): ?>
                                        <div class="mt-4 pt-3 border-t border-gray-100 grid grid-cols-3 gap-y-2.5 gap-x-1.5 text-center text-gray-600 font-bold">
                                            <div>
                                                <span class="block text-[9px] uppercase text-gray-400 font-black tracking-widest leading-none">Mecze</span>
                                                <span class="text-xs text-stalCzarny font-black block mt-1"><?php echo e($osoba->wystepy ?? 0); ?></span>
                                            </div>
                                            <div>
                                                <span class="block text-[9px] uppercase text-gray-400 font-black tracking-widest leading-none">Minuty</span>
                                                <span class="text-xs text-stalCzarny font-black block mt-1"><?php echo e($osoba->minuty ?? 0); ?></span>
                                            </div>
                                            <div>
                                                <span class="block text-[9px] uppercase text-gray-400 font-black tracking-widest leading-none">Gole</span>
                                                <span class="text-xs text-stalCzarny font-black block mt-1"><?php echo e($osoba->gole ?? 0); ?></span>
                                            </div>
                                            <div>
                                                <span class="block text-[9px] uppercase text-gray-400 font-black tracking-widest leading-none">Asysty</span>
                                                <span class="text-xs text-stalCzarny font-black block mt-1"><?php echo e($osoba->asysty ?? 0); ?></span>
                                            </div>
                                            <div>
                                                <span class="block text-[9px] uppercase text-yellow-600 font-black tracking-widest leading-none">Żółte</span>
                                                <span class="text-xs text-yellow-600 font-black block mt-1"><?php echo e($osoba->zolte_kartki ?? 0); ?></span>
                                            </div>
                                            <div>
                                                <span class="block text-[9px] uppercase text-red-600 font-black tracking-widest leading-none">Czerw</span>
                                                <span class="text-xs text-red-600 font-black block mt-1"><?php echo e($osoba->czerwone_kartki ?? 0); ?></span>
                                            </div>
                                            <?php if($osoba->pozycja === 'Bramkarz'): ?>
                                                <div class="col-span-3 mt-0.5 bg-green-50 border border-green-100/70 py-1 rounded-lg flex justify-between px-3 items-center">
                                                    <span class="text-[9px] uppercase text-stalZielony font-black tracking-widest">Czyste konta:</span>
                                                    <span class="text-xs text-stalZielony font-black"><?php echo e($osoba->czyste_konta ?? 0); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->rola === 'prezes'): ?>
                                        <div class="bg-gray-50 p-2.5 border-t border-gray-100 flex gap-2 relative z-20">
                                            <a href="<?php echo e(route('kadra.edytuj', $osoba->id)); ?>" class="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white text-center font-bold py-1.5 rounded-md text-[10px] uppercase shadow-sm transition duration-150">
                                                Edytuj
                                            </a>
                                            <form action="<?php echo e(route('kadra.usun', $osoba->id)); ?>" method="POST" class="flex-1" onsubmit="return confirm('Czy na pewno chcesz usunąć tę osobę z kadry?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-1.5 rounded-md text-[10px] uppercase shadow-sm transition duration-150">
                                                    Usuń
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/kadra/indeks.blade.php ENDPATH**/ ?>