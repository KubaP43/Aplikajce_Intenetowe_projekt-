<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-8">
        <div class="flex justify-between items-center border-b border-gray-200 pb-6 mb-8">
            <div>
                <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Edytuj Dane Meczu</h1>
                <p class="text-sm text-gray-500 mt-1">Zarzadzanie terminarzem - rola: Prezes</p>
            </div>
            <a href="<?php echo e(route('mecze.indeks')); ?>" class="inline-flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-4 py-2 rounded-lg text-xs uppercase tracking-wider transition">
                Anuluj
            </a>
        </div>

        <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                <ul class="list-disc pl-5 space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <form action="<?php echo e(route('mecze.aktualizuj', $mecz->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-6">
                    <label for="druzyna_id" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Zmien przeciwnika</label>
                    <select name="druzyna_id" id="druzyna_id" class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                        <?php $__currentLoopData = $druzyny; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $druzyna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($druzyna->id); ?>" <?php echo e($mecz->druzyna_id == $druzyna->id ? 'selected' : ''); ?>>
                                <?php echo e($druzyna->nazwa); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div>
                        <label for="data_meczu" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Data i godzina spotkania</label>
                        <input type="datetime-local" name="data_meczu" id="data_meczu" value="<?php echo e(\Carbon\Carbon::parse($mecz->data_meczu)->format('Y-m-d\TH:i')); ?>" class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                    </div>

                    <div>
                        <label for="czy_domowy" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Miejsce rozgrywania</label>
                        <select name="czy_domowy" id="czy_domowy" class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                            <option value="1" <?php echo e($mecz->czy_domowy ? 'selected' : ''); ?>>Mecz domowy</option>
                            <option value="0" <?php echo e(!$mecz->czy_domowy ? 'selected' : ''); ?>>Mecz wyjazdowy</option>
                        </select>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-stalZielony hover:bg-green-700 text-white font-bold px-6 py-3 rounded-lg text-xs uppercase tracking-wider shadow transition">
                        Zapisz zmiany
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/mecze/edytuj.blade.php ENDPATH**/ ?>