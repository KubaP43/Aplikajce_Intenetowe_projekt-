

<?php $__env->startSection('tresc'); ?>
    <div class="p-8">
        
        <div class="mb-6">
            <h2 class="text-2xl font-bold uppercase text-stalCzarny">Sprzedaż Biletów</h2>
            <p class="text-gray-500 text-xs">Kup bilet na najbliższy mecz Stalówki na stadionie PCPN</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            
            <div class="bg-white p-4 rounded shadow-sm">
                <p class="text-xs font-bold uppercase text-gray-400 mb-2">Oficjalny Cennik Wejściówek</p>
                <img src="<?php echo e(asset('images/Kup_Bilet.avif')); ?>" alt="Cennik biletów" class="w-full rounded border">
            </div>

            <div class="bg-white p-6 rounded shadow-sm border-t-4 border-stalZielony">
                <h3 class="font-bold text-lg text-stalCzarny mb-3">Internetowa Kasa Biletowa</h3>
                
                <p class="text-gray-600 text-xs leading-relaxed mb-4">
                    Uniknij kolejek pod stadionem! Kup bilet online szybko i bezpiecznie. Do zakupu potrzebny będzie jedynie Twój numer PESEL. 
                </p>

                <div class="bg-gray-50 p-4 rounded mb-6 text-xs text-gray-500 leading-normal">
                    <span class="font-bold text-stalCzarny block mb-1">ℹ️ Ważne informacje:</span>
                    • Bilet ulgowy przysługuje kobietom, dzieciom oraz emerytom.<br>
                    • Bramy stadionu przy ul. Hutniczej 15 otwieramy na 2 godziny przed meczem.<br>
                    • Zakupiony bilet możesz wydrukować lub pokazać na telefonie.
                </div>

                <div>
                    <a href="<?php echo e(route('bilety.stworz')); ?>" class="bg-stalZielony text-white font-bold p-3 rounded text-xs uppercase block text-center shadow hover:bg-green-800">
                        Przejdź do zakupu biletu ➔
                    </a>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/bilety/indeks.blade.php ENDPATH**/ ?>