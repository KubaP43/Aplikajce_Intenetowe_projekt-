

<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-8">

        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Dodaj do terminarza</h1>
                <p class="text-xs text-gray-500 mt-0.5">Panel zarządzania klubem — Rola: Prezes</p>
            </div>
            <a href="<?php echo e(route('mecze.indeks')); ?>" class="text-xs font-bold uppercase tracking-wider bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition duration-200">
                ➔ Powrót
            </a>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <form action="<?php echo e(route('mecze.zapisz')); ?>" method="POST" class="p-8 space-y-6" novalidate>
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Wybierz przeciwnika</label>
                    <select name="rywal" required
                            class="w-full border <?php $__errorArgs = ['rywal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                        <option value="">-- Wybierz drużynę przeciwną --</option>
                        <option value="Chojniczanka Chojnice">Chojniczanka Chojnice</option>
                        <option value="GKS Jastrzębie">GKS Jastrzębie</option>
                        <option value="Hutnik Kraków">Hutnik Kraków</option>
                        <option value="KKS 1925 Kalisz">KKS 1925 Kalisz</option>
                        <option value="Kotwica Kołobrzeg">Kotwica Kołobrzeg</option>
                        <option value="ŁKS II Łódź">ŁKS II Łódź</option>
                        <option value="Olimpia Elbląg">Olimpia Elbląg</option>
                        <option value="Olimpia Grudziądz">Olimpia Grudziądz</option>
                        <option value="Podhale Nowy Targ">Podhale Nowy Targ</option>
                        <option value="Pogoń Siedlce">Pogoń Siedlce</option>
                        <option value="Polonia Bytom">Polonia Bytom</option>
                        <option value="Radunia Stężyca">Radunia Stężyca</option>
                        <option value="Rekord Bielsko-Biała">Rekord Bielsko-Biała</option>
                        <option value="Sandecja Nowy Sącz">Sandecja Nowy Sącz</option>
                        <option value="Skra Częstochowa">Skra Częstochowa</option>
                        <option value="Stomil Olsztyn">Stomil Olsztyn</option>
                        <option value="Wisła Puławy">Wisła Puławy</option>
                        <option value="Zagłębie II Lubin">Zagłębie II Lubin</option>
                    </select>
                    <?php $__errorArgs = ['rywal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Data i godzina spotkania</label>
                        <input type="datetime-local" name="data_meczu" value="<?php echo e(old('data_meczu')); ?>"
                               class="w-full border <?php $__errorArgs = ['data_meczu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium font-mono">
                        <?php $__errorArgs = ['data_meczu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Miejsce rozgrywania</label>
                        <select name="czy_domowy" required
                                class="w-full border <?php $__errorArgs = ['czy_domowy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php else: ?> border-gray-300 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                            <option value="1" <?php echo e(old('czy_domowy') == '1' ? 'selected' : ''); ?>>Mecz domowy (PCPN Stalowa Wola)</option>
                            <option value="0" <?php echo e(old('czy_domowy') == '0' ? 'selected' : ''); ?>>Mecz wyjazdowy</option>
                        </select>
                        <?php $__errorArgs = ['czy_domowy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs font-bold mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="border-t border-gray-100 pt-6 flex justify-end">
                    <button type="submit" class="w-full sm:w-auto bg-stalZielony hover:bg-green-700 text-white font-black px-8 py-3 rounded-lg text-xs uppercase tracking-widest shadow-md transition duration-200">
                        Zapisz i dodaj do bazy
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/mecze/dodaj.blade.php ENDPATH**/ ?>