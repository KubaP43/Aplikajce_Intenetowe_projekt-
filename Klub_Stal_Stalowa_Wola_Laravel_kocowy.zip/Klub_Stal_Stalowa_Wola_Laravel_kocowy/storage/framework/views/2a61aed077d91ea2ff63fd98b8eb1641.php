<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-8">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-200 pb-6 mb-8">
            <div class="flex items-center gap-4">
                <div class="bg-white p-1.5 rounded-lg shadow-sm border border-gray-200">
                    <img src="<?php echo e(asset('images/drugaLiga.png')); ?>" alt="Betclic 2 Liga" class="h-10 object-contain">
                </div>
                <div>
                    <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Tabela Betclic 2. Ligi</h1>
                    <p class="text-sm text-gray-500 mt-1">Klasyfikacja ligowa - miejsca 1-18</p>
                </div>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->rola === 'prezes'): ?>
                    <a href="<?php echo e(route('tabela.dodaj')); ?>" class="bg-stalZielony text-white px-5 py-3 rounded-lg text-xs font-black uppercase shadow hover:bg-green-700 text-center">
                        Dodaj drużynę
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(session('sukces')): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                <?php echo e(session('sukces')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="grid grid-cols-[56px_1fr_72px_72px_88px] md:grid-cols-[56px_1fr_72px_72px_88px_150px] gap-3 px-5 py-3 bg-stalCzarny text-white text-[10px] font-black uppercase tracking-widest">
                <div>Miejsce</div>
                <div>Druzyna</div>
                <div class="text-center">Mecze</div>
                <div class="text-center">Bramki</div>
                <div class="text-center">Punkty</div>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->rola === 'prezes'): ?>
                        <div class="hidden md:block text-right">Akcje</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="divide-y divide-gray-100">
                <?php $__currentLoopData = $druzyny; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $druzyna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $bilans = $druzyna->bramki_zdobyte - $druzyna->bramki_stracone;
                    ?>
                    <div class="grid grid-cols-[56px_1fr_72px_72px_88px] md:grid-cols-[56px_1fr_72px_72px_88px_150px] gap-3 px-5 py-4 items-center hover:bg-gray-50 transition <?php echo e($druzyna->nazwa === 'Stal Stalowa Wola' ? 'bg-green-50/60' : ''); ?>">
                        <div class="font-mono text-sm font-black text-gray-500"><?php echo e($loop->iteration); ?></div>
                        <div class="font-black uppercase tracking-wide text-sm text-stalCzarny">
                            <?php echo e($druzyna->nazwa); ?>

                        </div>
                        <div class="text-center text-sm font-bold text-gray-600"><?php echo e($druzyna->mecze_rozegrane); ?></div>
                        <div class="text-center text-sm font-bold text-gray-600">
                            <?php echo e($druzyna->bramki_zdobyte); ?>:<?php echo e($druzyna->bramki_stracone); ?>

                            <span class="block text-[10px] text-gray-400"><?php echo e($bilans >= 0 ? '+' : ''); ?><?php echo e($bilans); ?></span>
                        </div>
                        <div class="text-center">
                            <span class="inline-flex items-center justify-center min-w-10 rounded-lg bg-stalZielony text-white font-black px-3 py-1">
                                <?php echo e($druzyna->punkty); ?>

                            </span>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->rola === 'prezes'): ?>
                                <div class="col-span-5 md:col-span-1 flex md:justify-end gap-2">
                                    <a href="<?php echo e(route('tabela.edytuj', $druzyna->id)); ?>" class="bg-yellow-500 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Edytuj</a>
                                    <form action="<?php echo e(route('tabela.usun', $druzyna->id)); ?>" method="POST" onsubmit="return confirm('Usunąć tę drużynę z tabeli?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="bg-red-600 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Usuń</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/tabela/indeks.blade.php ENDPATH**/ ?>