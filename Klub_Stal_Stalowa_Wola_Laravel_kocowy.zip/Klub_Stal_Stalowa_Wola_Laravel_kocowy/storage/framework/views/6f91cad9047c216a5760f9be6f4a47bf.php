<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Logowanie - Stal Stalowa Wola</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { stalZielony: '#2e6922', stalCzarny: '#161719' } } } }
        
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
            } else {
                input.type = 'password';
            }
        }
    </script>
</head>
<body class="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat relative px-4" style="background-image: url('<?php echo e(asset('images/stadion.jpg')); ?>');">
    
    <div class="absolute inset-0 bg-black/40"></div>

    <div class="bg-white w-full max-w-md p-8 rounded shadow-2xl relative z-10 border-t-8 border-stalZielony">
        
        <div class="mb-4 text-left">
            <a href="<?php echo e(route('strona.glowna')); ?>" class="text-xs text-gray-400 hover:text-stalZielony transition">➔ Powrót do strony głównej</a>
        </div>

        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold uppercase text-stalCzarny">Logowanie do systemu</h2>
            <p class="text-gray-500 text-xs mt-1">Podaj swoje dane, aby uzyskać dostęp</p>
        </div>

        <?php if(session('sukces')): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-3 mb-4 text-left rounded shadow-sm">
                <p class="text-xs text-green-700 font-bold"><?php echo e(session('sukces')); ?></p>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-50 border-l-4 border-red-600 p-3 mb-4 rounded">
                <ul class="text-xs text-red-700 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('zaloguj')); ?>" method="POST" autocomplete="off" class="space-y-4">
            <input type="hidden" name="_method" value="POST">
            <?php echo csrf_field(); ?>

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Adres e-mail:</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="off" class="w-full border p-2.5 rounded text-sm focus:outline-none focus:ring-2 focus:ring-stalZielony" required>
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Hasło:</label>
                <div class="relative">
                    <input type="password" id="log-haslo" name="password" autocomplete="new-password" class="w-full border p-2.5 rounded text-sm focus:outline-none focus:ring-2 focus:ring-stalZielony pr-10" required>
                    <button type="button" onclick="togglePassword('log-haslo')" class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-stalZielony">
                        👁️
                    </button>
                </div>
            </div>

            <button type="submit" class="w-full bg-stalZielony text-white font-bold p-3 rounded text-xs uppercase shadow hover:bg-green-800 transition tracking-wider">
                Zaloguj się
            </button>
        </form>

        <div class="text-center mt-6 pt-4 border-t text-xs text-gray-500">
            Nie masz jeszcze konta? <a href="<?php echo e(route('rejestracja')); ?>" class="text-stalZielony font-bold hover:underline ml-1">Zarejestruj się</a>
        </div>

    </div>
</body>
</html>
<?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/auth/logowanie.blade.php ENDPATH**/ ?>