<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-8">
        <div class="mb-8">
            <h1 class="text-3xl font-black uppercase text-stalCzarny tracking-wide">Sprzedaz biletow</h1>
            <p class="text-gray-500 text-sm mt-1">Prosta rezerwacja biletu na domowy mecz Stalowki.</p>
        </div>

        <?php if(session('sukces')): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                <?php echo e(session('sukces')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                <p class="text-xs font-bold uppercase text-gray-400 mb-2">Oficjalny cennik wejsciowek</p>
                <img src="<?php echo e(asset('images/Kup_Bilet.avif')); ?>" alt="Cennik biletow" class="w-full rounded-lg border border-gray-200">
            </div>

            <div class="bg-white p-8 rounded-xl shadow-sm border-t-4 border-stalZielony">
                <h2 class="font-black text-xl text-stalCzarny mb-3">Internetowa Kasa Biletowa</h2>
                <p class="text-gray-600 text-sm leading-relaxed mb-5">
                    Wybierz mecz, trybune i typ biletu. System sam przypisze kod rezerwacji oraz zapisze dane kibica z konta.
                </p>

                <?php if(auth()->guard()->guest()): ?>
                    <div class="bg-gray-50 p-5 rounded-lg border border-gray-200 mb-6">
                        <h3 class="font-black text-stalCzarny uppercase text-sm mb-2">Zakup tylko dla zalogowanych kibicow</h3>
                        <p class="text-sm text-gray-600 leading-relaxed">
                            Zaloguj sie albo utworz konto, zeby zarezerwowac bilet. To pozwala zapisac bilet na Twoje dane i pokazac go pozniej w systemie.
                        </p>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <a href="<?php echo e(route('logowanie')); ?>" class="bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase text-center shadow hover:bg-green-800">
                            Zaloguj sie
                        </a>
                        <a href="<?php echo e(route('rejestracja')); ?>" class="bg-stalCzarny text-white font-bold p-3 rounded-lg text-xs uppercase text-center shadow hover:bg-gray-800">
                            Zarejestruj
                        </a>
                    </div>
                <?php else: ?>
                    <div class="bg-gray-50 p-4 rounded-lg mb-6 text-xs text-gray-600 leading-normal">
                        <span class="font-bold text-stalCzarny block mb-1">Wazne informacje:</span>
                        Bilet ulgowy ma znizke 20%. Bramy stadionu przy ul. Hutniczej 15 otwieramy na 2 godziny przed meczem.
                    </div>

                    <a href="<?php echo e(route('bilety.stworz')); ?>" class="bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase block text-center shadow hover:bg-green-800">
                        Przejdz do zakupu biletu
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if(auth()->guard()->check()): ?>
            <div class="mt-10 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                    <div>
                        <h2 class="text-lg font-black uppercase text-stalCzarny">
                            <?php echo e(Auth::user()->rola === 'prezes' ? 'Wszystkie rezerwacje' : 'Moje bilety'); ?>

                        </h2>
                        <p class="text-xs text-gray-500">
                            <?php echo e(Auth::user()->rola === 'prezes' ? 'Prezes widzi pelne dane kibicow.' : 'Tu zobaczysz swoje kody biletow.'); ?>

                        </p>
                    </div>
                </div>

                <form action="<?php echo e(route('bilety.indeks')); ?>" method="GET" class="px-6 py-4 border-b border-gray-100 grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <select name="sektor" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="">Wszystkie trybuny</option>
                        <?php $__currentLoopData = ['Trybuna Glowna', 'Sektor A - Mlyn', 'Sektor B - Rodzinny']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sektor); ?>" <?php echo e(request('sektor') === $sektor ? 'selected' : ''); ?>><?php echo e($sektor); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="typ_biletu" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="">Wszystkie typy</option>
                        <option value="normalny" <?php echo e(request('typ_biletu') === 'normalny' ? 'selected' : ''); ?>>Normalny</option>
                        <option value="ulgowy" <?php echo e(request('typ_biletu') === 'ulgowy' ? 'selected' : ''); ?>>Ulgowy</option>
                    </select>
                    <select name="sortuj" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="najnowsze" <?php echo e(request('sortuj', 'najnowsze') === 'najnowsze' ? 'selected' : ''); ?>>Najnowsze</option>
                        <option value="najstarsze" <?php echo e(request('sortuj') === 'najstarsze' ? 'selected' : ''); ?>>Najstarsze</option>
                        <option value="typ" <?php echo e(request('sortuj') === 'typ' ? 'selected' : ''); ?>>Typ biletu</option>
                        <option value="trybuna" <?php echo e(request('sortuj') === 'trybuna' ? 'selected' : ''); ?>>Trybuna</option>
                    </select>
                    <div class="flex gap-2">
                        <button type="submit" class="flex-1 bg-stalZielony text-white rounded-lg text-xs font-bold uppercase px-4 py-2">Filtruj</button>
                        <a href="<?php echo e(route('bilety.indeks')); ?>" class="flex-1 bg-gray-200 text-gray-700 rounded-lg text-xs font-bold uppercase px-4 py-2 text-center">Wyczyść</a>
                    </div>
                </form>

                <?php if($bilety->isEmpty()): ?>
                    <div class="p-8 text-center text-sm text-gray-500">Brak zarezerwowanych biletow.</div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-gray-50 text-gray-500 text-[10px] uppercase tracking-widest">
                                <tr>
                                    <th class="text-left p-4">Kod</th>
                                    <th class="text-left p-4">Mecz</th>
                                    <th class="text-left p-4">Trybuna</th>
                                    <th class="text-left p-4">Typ</th>
                                    <?php if(Auth::user()->rola === 'prezes'): ?>
                                        <th class="text-left p-4">Kibic</th>
                                        <th class="text-left p-4">PESEL</th>
                                    <?php endif; ?>
                                    <th class="text-right p-4">Akcje</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php $__currentLoopData = $bilety; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bilet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="p-4 font-mono font-black text-stalZielony"><?php echo e($bilet->kod_biletu); ?></td>
                                        <td class="p-4">
                                            <span class="font-bold">
                                                Stal Stalowa Wola - <?php echo e($bilet->mecz->druzyna->nazwa ?? 'Nieznany rywal'); ?>

                                            </span>
                                            <span class="block text-xs text-gray-400">
                                                <?php echo e(optional($bilet->mecz)->data_meczu ? \Carbon\Carbon::parse($bilet->mecz->data_meczu)->format('d.m.Y H:i') : ''); ?>

                                            </span>
                                        </td>
                                        <td class="p-4"><?php echo e($bilet->sektor); ?></td>
                                        <td class="p-4 uppercase text-xs font-bold"><?php echo e($bilet->typ_biletu); ?></td>
                                        <?php if(Auth::user()->rola === 'prezes'): ?>
                                            <td class="p-4"><?php echo e($bilet->imie_nazwisko_kibica); ?></td>
                                            <td class="p-4 font-mono"><?php echo e($bilet->pesel_kibica); ?></td>
                                        <?php endif; ?>
                                        <td class="p-4 text-right">
                                            <div class="inline-flex gap-2">
                                                <?php if(Auth::user()->rola === 'prezes'): ?>
                                                    <a href="<?php echo e(route('bilety.edytuj', $bilet->id)); ?>" class="bg-yellow-500 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Edytuj</a>
                                                <?php endif; ?>
                                                <form action="<?php echo e(route('bilety.usun', $bilet->id)); ?>" method="POST" onsubmit="return confirm('Anulowac ten bilet?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="bg-red-600 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Anuluj</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/bilety/indeks.blade.php ENDPATH**/ ?>