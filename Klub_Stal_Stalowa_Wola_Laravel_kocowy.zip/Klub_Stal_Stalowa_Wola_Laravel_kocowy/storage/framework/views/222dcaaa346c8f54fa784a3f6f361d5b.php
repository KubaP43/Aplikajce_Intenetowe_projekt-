

<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-8">

        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-8 gap-4">
            <div class="flex items-center gap-4">
                <div class="bg-white p-1.5 rounded-lg shadow-sm border border-gray-200">
                    <img src="<?php echo e(asset('images/drugaLiga.png')); ?>" alt="Betclic 2 Liga" class="h-10 object-contain" 
                         onerror="this.onerror=null; this.src='<?php echo e(asset('images/drugaLiga.jpg')); ?>'; this.removeAttribute('onerror');">
                </div>
                <div>
                    <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Terminarz Rozgrywek</h1>
                    <p class="text-sm text-gray-500 mt-1">Mecze Stali Stalowa Wola — Sezon 2025/2026</p>
                </div>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->rola === 'prezes'): ?>
                    <div class="mt-4 md:mt-0">
                        <a href="<?php echo e(route('mecze.dodaj')); ?>" class="inline-flex items-center gap-2 bg-stalZielony text-white font-bold px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider shadow hover:bg-green-700 transition duration-200">
                            Dodaj mecz
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(session('sukces')): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                <?php echo e(session('sukces')); ?>

            </div>
        <?php endif; ?>

        <?php if($mecze->isEmpty()): ?>
            <div class="bg-white p-12 rounded-xl shadow-sm text-center border border-gray-200">
                <p class="text-gray-500 font-medium text-sm">Brak zaplanowanych meczów w tym momencie.</p>
            </div>
        <?php endif; ?>

        <?php if(!$mecze->isEmpty()): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $mecze; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mecz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-6 flex flex-col sm:flex-row justify-between items-center gap-4 hover:bg-gray-50 transition">
                            <div class="flex items-center gap-4">
                                <div class="bg-gray-100 px-3 py-1.5 rounded-lg text-center font-mono text-xs font-bold text-gray-600">
                                    <?php echo e(\Carbon\Carbon::parse($mecz->data_meczu)->format('d.m.Y - H:i')); ?>

                                </div>
                                <div>
                                    <span class="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded <?php echo e($mecz->typ_meczu === 'Dom' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-orange-50 text-orange-700 border border-orange-100'); ?>">
                                        <?php echo e($mecz->typ_meczu); ?>

                                    </span>
                                </div>
                            </div>

                            <div class="flex-1 text-center sm:text-left sm:pl-4">
                                <h3 class="text-base font-black text-stalCzarny uppercase tracking-wide">
                                    <?php if($mecz->typ_meczu === 'Dom'): ?>
                                        Stal Stalowa Wola — <?php echo e($mecz->druzyna->nazwa ?? 'Nieznany rywal'); ?>

                                    <?php else: ?>
                                        <?php echo e($mecz->druzyna->nazwa ?? 'Nieznany rywal'); ?> — Stal Stalowa Wola
                                    <?php endif; ?>
                                </h3>
                            </div>

                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->rola === 'prezes'): ?>
                                    <div class="flex items-center gap-2">
                                        <a href="<?php echo e(route('mecze.edytuj', $mecz->id)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold px-4 py-2 rounded-lg text-[10px] uppercase tracking-wider shadow-sm transition">
                                            Edytuj
                                        </a>
                                        <form action="<?php echo e(route('mecze.usun', $mecz->id)); ?>" method="POST" onsubmit="return confirm('Czy na pewno chcesz usunąć ten mecz ze struktur terminarza?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-lg text-[10px] uppercase tracking-wider shadow-sm transition">
                                                Usuń
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/mecze/indeks.blade.php ENDPATH**/ ?>