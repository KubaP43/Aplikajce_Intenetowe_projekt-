<?php $__env->startSection('tresc'); ?>
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-6">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Dodaj drużynę</h1>
                <p class="text-sm text-gray-500">Nowy zespół w tabeli ligowej</p>
            </div>
            <a href="<?php echo e(route('tabela.indeks')); ?>" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-xs font-bold uppercase">Powrót</a>
        </div>

        <?php echo $__env->make('tabela.formularz', ['action' => route('tabela.zapisz'), 'method' => 'POST', 'druzyna' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.szkielet', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola_Laravel\resources\views/tabela/dodaj.blade.php ENDPATH**/ ?>