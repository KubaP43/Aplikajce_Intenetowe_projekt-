<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stal Stalowa Wola - System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        stalZielony: '#2e6922', 
                        stalCzarny: '#161719', 
                        stalSzary: '#f4f5f7'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-stalSzary min-h-screen flex flex-col text-gray-900">

    <nav class="bg-stalCzarny text-white p-4 border-b-2 border-stalZielony shadow-lg">
        <div class="flex justify-between items-center px-8">
            
            <a href="<?php echo e(route('strona.glowna')); ?>" class="flex items-center gap-3 font-bold text-lg group">
                <img src="<?php echo e(asset('images/herb1.jpg')); ?>" 
                    alt="Herb Stal Stalowa Wola" 
                    class="h-10 w-auto object-contain rounded-full group-hover:scale-105 transition duration-200">
                <span class="tracking-wide group-hover:text-stalZielony transition duration-200">
                    Stal Stalowa Wola
                </span>
            </a>
            
            <div class="flex space-x-1 text-sm font-medium items-center">
                <a href="<?php echo e(route('strona.glowna')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('strona.glowna') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Strona Główna
                </a>
                
                <a href="<?php echo e(route('mecze.indeks')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('mecze.*') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Terminarz
                </a>
                
                <a href="<?php echo e(route('kadra.indeks')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('kadra.*') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Kadra
                </a>
                
                <a href="<?php echo e(route('bilety.indeks')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('bilety.*') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Bilety
                </a>
                
                <a href="<?php echo e(route('strona.historia')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('strona.historia') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Historia
                </a>
                
                <a href="<?php echo e(route('strona.kontakt')); ?>" 
                   class="px-3 py-2 rounded transition duration-200 <?php echo e(request()->routeIs('strona.kontakt') ? 'text-stalZielony font-bold border-b-2 border-stalZielony rounded-none' : 'md:hover:bg-stalZielony/10 hover:text-stalZielony'); ?>">
                   Kontakt
                </a>
            </div>

            <div class="flex items-center gap-4">
                <?php if(Auth::check()): ?>
                    <div class="text-right">
                        <span class="text-xs text-gray-300 block font-medium">Witaj,</span>
                        <span class="text-sm font-bold text-white block uppercase tracking-wide">
                            <?php echo e(Auth::user()->imie); ?>

                            <?php if(Auth::user()->rola === 'prezes'): ?> 
                                <span class="text-[10px] text-yellow-400 font-bold block normal-case font-sans">(Prezes Klubu)</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <form action="<?php echo e(route('wyloguj')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-red-600 text-white px-3 py-2 rounded text-xs font-bold uppercase shadow hover:bg-red-700 transition">
                            Wyloguj X
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('logowanie')); ?>" class="bg-stalZielony text-white px-4 py-2 rounded text-xs font-bold uppercase shadow hover:bg-green-800 transition">
                        Zaloguj
                    </a>
                    <div class="text-left">
                        <a href="<?php echo e(route('rejestracja')); ?>" class="bg-stalZielony text-white px-4 py-2 rounded text-xs font-bold uppercase shadow hover:bg-green-800 transition inline-block">
                            Zarejestruj <span class="text-[9px] font-normal lowercase block text-gray-300">(jeśli jesteś pierwszy raz)</span>
                        </a>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </nav>

    <main class="flex-grow">
        <?php echo $__env->yieldContent('tresc'); ?>
    </main>

    <footer class="bg-stalCzarny text-gray-400 p-4 text-xs text-center">
        <p>Podkarpackie Centrum Piłki Nożnej — ul. Hutnicza 15, Stalowa Wola</p>
        <p class="text-gray-600 mt-1">&copy; 2026 Stal Stalowa Wola.</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\Kuba\Desktop\Klub_Stal_Stalowa_Wola\resources\views/layouts/szkielet.blade.php ENDPATH**/ ?>