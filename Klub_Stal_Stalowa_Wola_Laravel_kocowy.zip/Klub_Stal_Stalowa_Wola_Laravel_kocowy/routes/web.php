<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MeczController;
use App\Http\Controllers\BiletController;
use App\Http\Controllers\PilkarzController;
use App\Http\Controllers\KibicController;
use App\Http\Controllers\TabelaController;
use App\Models\Mecz;
use App\Models\Druzyna;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    $najblizszyMecz = Mecz::with('druzyna')
        ->where('data_meczu', '>=', Carbon::now())
        ->orderBy('data_meczu', 'asc')
        ->first();

    $najblizszeMecze = Mecz::with('druzyna')
        ->where('data_meczu', '>=', Carbon::now())
        ->orderBy('data_meczu', 'asc')
        ->limit(3)
        ->get();

    $czolowkaTabeli = Druzyna::query()
        ->orderByDesc('punkty')
        ->orderByRaw('(bramki_zdobyte - bramki_stracone) desc')
        ->orderByDesc('bramki_zdobyte')
        ->limit(3)
        ->get();

    return view('strona_glowna', compact('najblizszyMecz', 'najblizszeMecze', 'czolowkaTabeli'));
})->name('strona.glowna');

Route::get('/kadra', [PilkarzController::class, 'indeks'])->name('kadra.indeks');

Route::get('/mecze', [MeczController::class, 'indeks'])->name('mecze.indeks');
Route::get('/tabela', [TabelaController::class, 'indeks'])->name('tabela.indeks');

Route::get('/bilety', [BiletController::class, 'indeks'])->name('bilety.indeks');
Route::get('/bilety/stworz', [BiletController::class, 'stworz'])->name('bilety.stworz');
Route::post('/bilety', [BiletController::class, 'zapisz'])->name('bilety.zapisz');
Route::get('/bilety/{id}/edytuj', [BiletController::class, 'edytuj'])->name('bilety.edytuj');
Route::put('/bilety/{id}', [BiletController::class, 'aktualizuj'])->name('bilety.aktualizuj');
Route::delete('/bilety/{id}', [BiletController::class, 'usun'])->name('bilety.usun');

Route::get('/kibice', [KibicController::class, 'indeks'])->name('kibice.indeks');
Route::get('/kibice/stworz', [KibicController::class, 'stworz'])->name('kibice.stworz');
Route::post('/kibice', [KibicController::class, 'zapisz'])->name('kibice.zapisz');
Route::get('/kibice/{id}/edytuj', [KibicController::class, 'edytuj'])->name('kibice.edytuj');
Route::put('/kibice/{id}', [KibicController::class, 'aktualizuj'])->name('kibice.aktualizuj');
Route::delete('/kibice/{id}', [KibicController::class, 'usun'])->name('kibice.usun');

Route::get('/historia', function () {
    return view('kibice.indeks');
})->name('strona.historia');

Route::get('/kontakt', function () {
    return view('kontakt');
})->name('strona.kontakt');

Route::get('/logowanie', function () {
    if (Auth::check()) {
        return redirect()->route('strona.glowna');
    }

    return response()
        ->view('auth.logowanie')
        ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        ->header('Pragma', 'no-cache');
})->name('logowanie');

Route::get('/rejestracja', function () {
    if (Auth::check()) {
        return redirect()->route('strona.glowna');
    }

    return response()
        ->view('auth.rejestracja')
        ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        ->header('Pragma', 'no-cache');
})->name('rejestracja');

Route::post('/logowanie', [KibicController::class, 'zaloguj'])->name('zaloguj');
Route::post('/wyloguj', [KibicController::class, 'wyloguj'])->name('wyloguj');

Route::get('/radar', function () {
    return response()->json([
        'czy_zalogowany' => Auth::check(),
        'uzytkownik' => Auth::user(),
        'dane_z_sesji' => session()->all()
    ]);
});

Route::middleware(['auth'])->group(function () {
    Route::get('/kadra/dodaj', [PilkarzController::class, 'dodaj'])->name('kadra.dodaj');
    Route::post('/kadra/zapisz', [PilkarzController::class, 'zapisz'])->name('kadra.zapisz');
    Route::get('/kadra/{id}/edytuj', [PilkarzController::class, 'edytuj'])->name('kadra.edytuj');
    Route::put('/kadra/{id}/aktualizuj', [PilkarzController::class, 'aktualizuj'])->name('kadra.aktualizuj');
    Route::delete('/kadra/{id}/usun', [PilkarzController::class, 'usun'])->name('kadra.usun');

    Route::get('/mecze/dodaj', [MeczController::class, 'dodaj'])->name('mecze.dodaj');
    Route::post('/mecze/zapisz', [MeczController::class, 'zapisz'])->name('mecze.zapisz');
    Route::get('/mecze/{id}/edytuj', [MeczController::class, 'edytuj'])->name('mecze.edytuj');
    Route::put('/mecze/{id}/aktualizuj', [MeczController::class, 'aktualizuj'])->name('mecze.aktualizuj');
    Route::delete('/mecze/{id}/usun', [MeczController::class, 'usun'])->name('mecze.usun');

    Route::get('/tabela/dodaj', [TabelaController::class, 'dodaj'])->name('tabela.dodaj');
    Route::post('/tabela/zapisz', [TabelaController::class, 'zapisz'])->name('tabela.zapisz');
    Route::get('/tabela/{id}/edytuj', [TabelaController::class, 'edytuj'])->name('tabela.edytuj');
    Route::put('/tabela/{id}/aktualizuj', [TabelaController::class, 'aktualizuj'])->name('tabela.aktualizuj');
    Route::delete('/tabela/{id}/usun', [TabelaController::class, 'usun'])->name('tabela.usun');
});
