<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Uzytkownik extends Authenticatable
{
    use Notifiable;

    protected $table = 'uzytkownicy';

    protected $fillable = [
        'imie',
        'nazwisko',
        'pesel',
        'data_urodzenia',
        'email',
        'password',
        'rola',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function getAuthPassword()
    {
        return $this->password;
    }

    public function bilety()
    {
        return $this->hasMany(Bilet::class, 'uzytkownik_id');
    }
}
