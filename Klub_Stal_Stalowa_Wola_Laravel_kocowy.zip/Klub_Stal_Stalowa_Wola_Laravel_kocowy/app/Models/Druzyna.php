<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Druzyna extends Model
{
    protected $table = 'druzyny';

    protected $fillable = [
        'nazwa',
        'punkty',
        'mecze_rozegrane',
        'bramki_zdobyte',
        'bramki_stracone'
    ];

    public function mecze(): HasMany
    {
        return $this->hasMany(Mecz::class, 'druzyna_id');
    }
}