<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Mecz extends Model
{
    protected $table = 'mecze';

    protected $fillable = [
        'data_meczu',
        'czy_domowy',
        'wynik_stal',
        'wynik_rywal',
        'druzyna_id',
        'miejsce'
    ];

    public function druzyna(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Druzyna::class, 'druzyna_id');
    }
}