<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pilkarz extends Model
{
    protected $table = 'pilkarze';

    protected $fillable = ['imie', 'nazwisko', 'pozycja', 'wiek', 'od_kiedy_w_klubie', 'rozegrane_mecze'];
}