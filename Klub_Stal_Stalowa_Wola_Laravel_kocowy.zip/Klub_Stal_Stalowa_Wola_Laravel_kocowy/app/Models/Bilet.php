<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Bilet extends Model
{
    protected $table = 'bilety';

    protected $fillable = [
        'uzytkownik_id',
        'kod_biletu',
        'mecz_id',
        'sektor',
        'rzad',
        'miejsce',
        'typ_biletu',
        'znizka',
        'imie_nazwisko_kibica',
        'pesel_kibica',
    ];

    public function mecz(): BelongsTo
    {
        return $this->belongsTo(Mecz::class, 'mecz_id');
    }

    public function uzytkownik(): BelongsTo
    {
        return $this->belongsTo(Uzytkownik::class, 'uzytkownik_id');
    }
}
