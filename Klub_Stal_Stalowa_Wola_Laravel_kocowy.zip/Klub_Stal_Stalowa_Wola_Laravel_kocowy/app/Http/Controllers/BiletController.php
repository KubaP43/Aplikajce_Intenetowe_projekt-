<?php

namespace App\Http\Controllers;

use App\Models\Bilet;
use App\Models\Mecz;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class BiletController extends Controller
{
    public function indeks(Request $request)
    {
        $bilety = collect();

        if (Auth::check()) {
            $zapytanie = Bilet::with(['mecz.druzyna', 'uzytkownik']);

            if (Auth::user()->rola !== 'prezes') {
                $zapytanie->where('uzytkownik_id', Auth::id());
            }

            if ($request->filled('sektor')) {
                $zapytanie->where('sektor', $request->sektor);
            }

            if ($request->filled('typ_biletu')) {
                $zapytanie->where('typ_biletu', $request->typ_biletu);
            }

            match ($request->input('sortuj', 'najnowsze')) {
                'najstarsze' => $zapytanie->orderBy('created_at', 'asc'),
                'typ' => $zapytanie->orderBy('typ_biletu')->orderBy('created_at', 'desc'),
                'trybuna' => $zapytanie->orderBy('sektor')->orderBy('created_at', 'desc'),
                default => $zapytanie->orderBy('created_at', 'desc'),
            };

            $bilety = $zapytanie->get();
        }

        return view('bilety.indeks', compact('bilety'));
    }

    public function stworz()
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $mecze = Mecz::with('druzyna')
            ->where('czy_domowy', true)
            ->where('data_meczu', '>=', now())
            ->orderBy('data_meczu', 'asc')
            ->get();

        return view('bilety.stworz', compact('mecze'));
    }

    public function zapisz(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $validated = $request->validate([
            'mecz_id' => 'required|exists:mecze,id',
            'sektor' => 'required|string|max:80',
            'typ_biletu' => 'required|in:normalny,ulgowy',
        ], [
            'mecz_id.required' => 'Wybierz mecz.',
            'sektor.required' => 'Wybierz trybune.',
            'typ_biletu.required' => 'Wybierz typ biletu.',
        ]);

        $uzytkownik = Auth::user();

        $istniejacyBilet = Bilet::where('uzytkownik_id', $uzytkownik->id)
            ->where('mecz_id', $validated['mecz_id'])
            ->exists();

        if ($istniejacyBilet) {
            return redirect()->route('bilety.indeks')
                ->withErrors(['mecz_id' => 'Masz już bilet na ten mecz. Jeden kibic może zarezerwować maksymalnie jeden bilet na jedno spotkanie.']);
        }

        Bilet::create([
            'uzytkownik_id' => $uzytkownik->id,
            'kod_biletu' => $this->wygenerujKodBiletu(),
            'mecz_id' => $validated['mecz_id'],
            'sektor' => $validated['sektor'],
            'rzad' => random_int(1, 20),
            'miejsce' => random_int(1, 120),
            'typ_biletu' => $validated['typ_biletu'],
            'znizka' => $validated['typ_biletu'] === 'ulgowy' ? 20 : 0,
            'imie_nazwisko_kibica' => trim($uzytkownik->imie . ' ' . $uzytkownik->nazwisko),
            'pesel_kibica' => $uzytkownik->pesel,
        ]);

        return redirect()->route('bilety.indeks')->with('sukces', 'Bilet zostal zarezerwowany i zapisany w bazie.');
    }

    public function edytuj($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Tylko prezes moze edytowac bilety.']);
        }

        $bilet = Bilet::with('mecz.druzyna')->findOrFail($id);
        $mecze = Mecz::with('druzyna')->where('czy_domowy', true)->orderBy('data_meczu')->get();

        return view('bilety.edytuj', compact('bilet', 'mecze'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Tylko prezes moze edytowac bilety.']);
        }

        $validated = $request->validate([
            'mecz_id' => 'required|exists:mecze,id',
            'sektor' => 'required|string|max:80',
            'typ_biletu' => 'required|in:normalny,ulgowy',
        ]);

        $bilet = Bilet::findOrFail($id);
        $bilet->update([
            'mecz_id' => $validated['mecz_id'],
            'sektor' => $validated['sektor'],
            'typ_biletu' => $validated['typ_biletu'],
            'znizka' => $validated['typ_biletu'] === 'ulgowy' ? 20 : 0,
        ]);

        return redirect()->route('bilety.indeks')->with('sukces', 'Dane biletu zostaly zaktualizowane.');
    }

    public function usun($id)
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $bilet = Bilet::findOrFail($id);

        if (Auth::user()->rola !== 'prezes' && $bilet->uzytkownik_id !== Auth::id()) {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Mozesz anulowac tylko swoj bilet.']);
        }

        $bilet->delete();

        return redirect()->route('bilety.indeks')->with('sukces', 'Bilet zostal anulowany.');
    }

    private function wygenerujKodBiletu(): string
    {
        do {
            $kod = 'STAL-' . random_int(1000, 9999) . '-' . Str::upper(Str::random(3));
        } while (Bilet::where('kod_biletu', $kod)->exists());

        return $kod;
    }
}
