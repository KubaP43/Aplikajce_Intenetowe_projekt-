<?php

namespace App\Http\Controllers;

use App\Models\Druzyna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class TabelaController extends Controller
{
    public function indeks()
    {
        $druzyny = Druzyna::query()
            ->orderByDesc('punkty')
            ->orderByRaw('(bramki_zdobyte - bramki_stracone) desc')
            ->orderByDesc('bramki_zdobyte')
            ->orderBy('nazwa')
            ->limit(18)
            ->get();

        return view('tabela.indeks', compact('druzyny'));
    }

    public function dodaj()
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        return view('tabela.dodaj');
    }

    public function zapisz(Request $request)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        Druzyna::create($this->walidujDruzyne($request));

        return redirect()->route('tabela.indeks')->with('sukces', 'Drużyna została dodana do tabeli.');
    }

    public function edytuj($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);

        return view('tabela.edytuj', compact('druzyna'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);
        $druzyna->update($this->walidujDruzyne($request, $druzyna->id));

        return redirect()->route('tabela.indeks')->with('sukces', 'Dane drużyny zostały zaktualizowane.');
    }

    public function usun($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);

        if ($druzyna->mecze()->exists()) {
            return redirect()->route('tabela.indeks')
                ->withErrors(['druzyna' => 'Nie można usunąć drużyny, która ma przypisane mecze w terminarzu.']);
        }

        $druzyna->delete();

        return redirect()->route('tabela.indeks')->with('sukces', 'Drużyna została usunięta.');
    }

    private function walidujDruzyne(Request $request, ?int $ignorujId = null): array
    {
        return $request->validate([
            'nazwa' => [
                'required',
                'string',
                'max:100',
                'regex:/^[\pL0-9\s\.\-]+$/u',
                Rule::unique('druzyny', 'nazwa')->ignore($ignorujId),
            ],
            'punkty' => ['required', 'integer', 'min:0', 'max:150'],
            'mecze_rozegrane' => ['required', 'integer', 'min:0', 'max:80'],
            'bramki_zdobyte' => ['required', 'integer', 'min:0', 'max:300'],
            'bramki_stracone' => ['required', 'integer', 'min:0', 'max:300'],
        ], [
            'nazwa.regex' => 'Nazwa drużyny może zawierać litery, cyfry, spacje, kropki i myślniki.',
            'nazwa.unique' => 'Taka drużyna już istnieje w bazie.',
        ]);
    }

    private function czyPrezes(): bool
    {
        return Auth::check() && Auth::user()->rola === 'prezes';
    }
}
