<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KadraController extends Controller
{
    /**
     * Wyświetla formularz dodawania
     */
    public function dodaj()
    {
        return view('kadra.dodaj'); // Odnosi się do resources/views/kadra/dodaj.blade.php
    }

    /**
     * Zapisuje nowego zawodnika
     */
    public function zapisz(Request $request)
    {
        // 1. Walidacja danych wejściowych
        $request->validate([
            'imie' => 'required|string|max:50',
            'nazwisko' => 'required|string|max:50',
            'pozycja' => 'required|string',
            'numer' => 'required|integer|min:0|max:99',
            'zdjecie' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $nazwaPliku = null;

        // 2. Obsługa uploadu zdjęcia
        if ($request->hasFile('zdjecie')) {
            $file = $request->file('zdjecie');
            
            $cleanImie = iconv('UTF-8', 'ASCII//TRANSLIT', $request->imie);
            $cleanNazwisko = iconv('UTF-8', 'ASCII//TRANSLIT', $request->nazwisko);
            
            $cleanImie = preg_replace('/[^A-Za-z0-9\-]/', '', $cleanImie);
            $cleanNazwisko = preg_replace('/[^A-Za-z0-9\-]/', '', $cleanNazwisko);
            
            $nazwaPliku = $cleanImie . '_' . $cleanNazwisko . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('images/Zdjecia_pilkarzy'), $nazwaPliku);
        }

        // 3. Wrzucenie rekordu do bazy
        DB::table('pilkarze')->insert([
            'imie' => $request->imie,
            'nazwisko' => $request->nazwisko,
            'pozycja' => $request->pozycja,
            'numer' => $request->numer,
            'zdjecie' => $nazwaPliku,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // 4. Powrót na stronę kadry
        return redirect()->route('kadra.indeks')->with('sukces', 'Pomyślnie dodano nowego członka kadry!');
    }
}