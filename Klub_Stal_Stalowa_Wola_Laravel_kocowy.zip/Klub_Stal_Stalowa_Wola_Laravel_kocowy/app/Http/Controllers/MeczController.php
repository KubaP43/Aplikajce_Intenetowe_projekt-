<?php

namespace App\Http\Controllers;

use App\Models\Mecz;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MeczController extends Controller
{
    public function indeks()
    {
        $mecze = Mecz::with('druzyna')->orderBy('data_meczu', 'asc')->get();

        return view('mecze.indeks', compact('mecze'));
    }

    public function dodaj()
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $druzyny = DB::table('druzyny')
            ->where('nazwa', '!=', 'Stal Stalowa Wola')
            ->orderBy('nazwa', 'asc')
            ->get();

        return view('mecze.dodaj', compact('druzyny'));
    }

    public function zapisz(Request $request)
    {
        $validated = $request->validate([
            'druzyna_id' => 'required|exists:druzyny,id',
            'data_meczu' => 'required|date',
            'czy_domowy' => 'required|boolean',
        ], [
            'druzyna_id.required' => 'Musisz wybrac druzyne przeciwnika z listy.',
            'druzyna_id.exists' => 'Wybrana druzyna nie istnieje w bazie danych.',
            'data_meczu.required' => 'Wskaz date oraz godzine rozgrywania meczu.',
            'data_meczu.date' => 'Wprowadzona wartosc musi byc poprawna data.',
            'czy_domowy.required' => 'Wybierz miejsce spotkania.',
        ]);

        $dataMeczu = Carbon::parse($validated['data_meczu']);
        $rokWstecz = Carbon::now()->subYear();
        $rokWPrzod = Carbon::now()->addYear();

        if ($dataMeczu->lt($rokWstecz) || $dataMeczu->gt($rokWPrzod)) {
            return redirect()->back()
                ->withErrors(['data_meczu' => 'Data meczu musi miescic sie w zakresie od roku wstecz do roku w przod.'])
                ->withInput();
        }

        $meczTegoSamegoDnia = Mecz::whereDate('data_meczu', $dataMeczu->toDateString())->exists();

        if ($meczTegoSamegoDnia) {
            return redirect()->back()
                ->withErrors(['data_meczu' => 'Tego dnia Stal Stalowa Wola rozgrywa juz inne spotkanie.'])
                ->withInput();
        }

        Mecz::create([
            'druzyna_id' => $validated['druzyna_id'],
            'data_meczu' => $validated['data_meczu'],
            'czy_domowy' => (bool) $validated['czy_domowy'],
            'miejsce' => $validated['czy_domowy'] ? 'PCPN Stalowa Wola' : 'Stadion wyjazdowy',
            'status' => 'Planowany',
        ]);

        return redirect()->route('mecze.indeks')->with('sukces', 'Mecz zostal dodany do terminarza.');
    }

    public function edytuj($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $mecz = Mecz::findOrFail($id);
        $druzyny = DB::table('druzyny')
            ->where('nazwa', '!=', 'Stal Stalowa Wola')
            ->orderBy('nazwa', 'asc')
            ->get();

        return view('mecze.edytuj', compact('mecz', 'druzyny'));
    }

    public function aktualizuj(Request $request, $id)
    {
        $validated = $request->validate([
            'druzyna_id' => 'required|exists:druzyny,id',
            'data_meczu' => 'required|date',
            'czy_domowy' => 'required|boolean',
        ], [
            'druzyna_id.required' => 'Musisz wybrac druzyne przeciwnika z listy.',
            'druzyna_id.exists' => 'Wybrana druzyna nie istnieje w bazie danych.',
            'data_meczu.required' => 'Wskaz date oraz godzine rozgrywania meczu.',
            'data_meczu.date' => 'Wprowadzona wartosc musi byc poprawna data.',
            'czy_domowy.required' => 'Wybierz miejsce spotkania.',
        ]);

        $dataMeczu = Carbon::parse($validated['data_meczu']);
        $rokWstecz = Carbon::now()->subYear();
        $rokWPrzod = Carbon::now()->addYear();

        if ($dataMeczu->lt($rokWstecz) || $dataMeczu->gt($rokWPrzod)) {
            return redirect()->back()
                ->withErrors(['data_meczu' => 'Data meczu musi miescic sie w zakresie od roku wstecz do roku w przod.'])
                ->withInput();
        }

        $meczTegoSamegoDnia = Mecz::whereDate('data_meczu', $dataMeczu->toDateString())
            ->where('id', '!=', $id)
            ->exists();

        if ($meczTegoSamegoDnia) {
            return redirect()->back()
                ->withErrors(['data_meczu' => 'Tego dnia Stal Stalowa Wola rozgrywa juz inne spotkanie.'])
                ->withInput();
        }

        $mecz = Mecz::findOrFail($id);
        $mecz->update([
            'druzyna_id' => $validated['druzyna_id'],
            'data_meczu' => $validated['data_meczu'],
            'czy_domowy' => (bool) $validated['czy_domowy'],
            'miejsce' => $validated['czy_domowy'] ? 'PCPN Stalowa Wola' : 'Stadion wyjazdowy',
        ]);

        return redirect()->route('mecze.indeks')->with('sukces', 'Dane meczu zostaly zaktualizowane.');
    }

    public function usun($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        Mecz::findOrFail($id)->delete();

        return redirect()->route('mecze.indeks')->with('sukces', 'Mecz zostal usuniety.');
    }
}
