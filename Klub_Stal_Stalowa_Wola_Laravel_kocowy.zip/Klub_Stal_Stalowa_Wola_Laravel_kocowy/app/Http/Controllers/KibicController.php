<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Uzytkownik;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;

class KibicController extends Controller
{
    // 1. WYŚWIETLANIE FORMULARZA REJESTRACJI
    public function stworz()
    {
        return view('auth.rejestracja');
    }

    // 2. ZAPIS NOWEGO KIBICA
    public function zapisz(Request $request)
    {
        $request->validate([
            'imie' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\-]+$/u'],
            'nazwisko' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\-]+$/u'],
            'pesel' => 'required|digits:11|unique:uzytkownicy,pesel',
            'data_urodzenia' => 'required|date|before:today',
            'email' => 'required|string|email|max:255|unique:uzytkownicy,email',
            'password' => [
                'required',
                Password::min(8)->letters()->mixedCase()->numbers()->symbols()
            ],
        ], [
            // POLSKIE KOMUNIKATY BŁĘDÓW
            'imie.required' => 'Pole Imię jest wymagane.',
            'imie.regex' => 'Imię może zawierać tylko litery, spacje i myślnik.',
            'nazwisko.required' => 'Pole Nazwisko jest wymagane.',
            'nazwisko.regex' => 'Nazwisko może zawierać tylko litery, spacje i myślnik.',
            'pesel.required' => 'Musisz podać numer PESEL.',
            'pesel.digits' => 'Numer PESEL musi składać się z dokładnie 11 cyfr.',
            'pesel.unique' => 'Konto z tym numerem PESEL już istnieje.',
            'data_urodzenia.required' => 'Data urodzenia jest wymagana.',
            'data_urodzenia.before' => 'Data urodzenia musi być datą z przeszłości.',
            'email.required' => 'Adres e-mail jest wymagany.',
            'email.email' => 'Podaj poprawny format adresu e-mail.',
            'email.unique' => 'Ten adres e-mail jest już zajęty.',
            'password.required' => 'Musisz podać hasło.',
            'password' => 'Hasło musi mieć min. 8 znaków, duże i małe litery, cyfrę oraz znak specjalny.'
        ]);

        Uzytkownik::create([
            'imie' => $request->imie,
            'nazwisko' => $request->nazwisko,
            'pesel' => $request->pesel,
            'data_urodzenia' => $request->data_urodzenia,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('logowanie')->with('sukces', 'Zarejestrowano poprawnie! Zaloguj się swoimi danymi.');
    }

    // 3. OFICJALNA METODA LOGOWANIA
    public function zaloguj(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');

        if (empty($email) || empty($password)) {
            return back()->withErrors(['email' => 'Oba pola są wymagane.'])->withInput();
        }

        $uzytkownik = Uzytkownik::where('email', $email)->first();

        if (!$uzytkownik) {
            return back()->withErrors(['email' => 'Błędny adres e-mail lub hasło.'])->withInput();
        }

        if (Hash::check($password, $uzytkownik->password)) {
            // Logujemy użytkownika w systemie
            Auth::login($uzytkownik);
            
            // Wymuszamy zapis sesji w przeglądarce
            $request->session()->regenerate();
            
            // Przekierowanie na stronę główną z komunikatem sukcesu
            return redirect()->route('strona.glowna')->with('sukces', 'Zalogowano pomyślnie do systemu!');
        }

        return back()->withErrors(['email' => 'Błędny adres e-mail lub hasło.'])->withInput();
    }

    // 4. LOGIKA WYLOGOWANIA
    public function wyloguj(Request $request)
    {
        Auth::logout(); // Wylogowanie z systemu

        $request->session()->invalidate(); // Unieważnienie sesji
        $request->session()->regenerateToken(); // Regeneracja tokenu CSRF

        return redirect()->route('strona.glowna')->with('sukces', 'Wylogowano pomyślnie z systemu.');
    }
}
