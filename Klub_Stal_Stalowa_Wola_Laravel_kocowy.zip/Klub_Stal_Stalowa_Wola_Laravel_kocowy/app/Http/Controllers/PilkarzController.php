<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class PilkarzController extends Controller
{
    private const POZYCJE = ['Bramkarz', 'Obrońca', 'Pomocnik', 'Napastnik', 'Sztab'];
    private const TEKST_REGEX = '/^[\pL\s\-]+$/u';

    public function indeks(Request $request)
    {
        $request->validate([
            'pozycja' => ['nullable', Rule::in(self::POZYCJE)],
            'szukaj' => ['nullable', 'string', 'max:50'],
            'sortuj' => ['nullable', Rule::in(['numer', 'nazwisko', 'gole', 'wystepy'])],
        ]);

        $query = DB::table('pilkarze')
            ->leftJoin('statystyki_pilkarzy', 'pilkarze.id', '=', 'statystyki_pilkarzy.pilkarz_id')
            ->select(
                'pilkarze.*',
                'statystyki_pilkarzy.wystepy',
                'statystyki_pilkarzy.minuty',
                'statystyki_pilkarzy.gole',
                'statystyki_pilkarzy.asysty',
                'statystyki_pilkarzy.czyste_konta',
                'statystyki_pilkarzy.zolte_kartki',
                'statystyki_pilkarzy.czerwone_kartki'
            );

        if ($request->filled('pozycja')) {
            if ($request->pozycja === 'Sztab') {
                $query->where('pilkarze.pozycja', 'LIKE', 'Sztab%');
            } else {
                $query->where('pilkarze.pozycja', $request->pozycja);
            }
        }

        if ($request->filled('szukaj')) {
            $szukaj = trim($request->input('szukaj'));

            if (ctype_digit($szukaj)) {
                ((int) $szukaj < 100)
                    ? $query->where('pilkarze.numer', (int) $szukaj)
                    : $query->where('pilkarze.id', 0);
            } else {
                $query->where(function ($q) use ($szukaj) {
                    $q->where('pilkarze.nazwisko', 'ILIKE', '%' . $szukaj . '%')
                        ->orWhere('pilkarze.imie', 'ILIKE', '%' . $szukaj . '%');
                });
            }
        }

        match ($request->input('sortuj', 'numer')) {
            'nazwisko' => $query->orderBy('pilkarze.nazwisko')->orderBy('pilkarze.imie'),
            'gole' => $query->orderByRaw('COALESCE(statystyki_pilkarzy.gole, 0) DESC')->orderBy('pilkarze.nazwisko'),
            'wystepy' => $query->orderByRaw('COALESCE(statystyki_pilkarzy.wystepy, 0) DESC')->orderBy('pilkarze.nazwisko'),
            default => $query->orderBy('pilkarze.numer', 'asc')->orderBy('pilkarze.nazwisko'),
        };

        $pilkarze = $query->get();

        return view('kadra.indeks', compact('pilkarze'));
    }

    public function dodaj()
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('kadra.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        return view('kadra.dodaj');
    }

    public function zapisz(Request $request)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('kadra.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $validated = $this->walidujKadre($request);

        if (($validated['numer'] ?? 0) !== 0 && DB::table('pilkarze')->where('numer', $validated['numer'])->exists()) {
            return redirect()->back()
                ->withErrors(['numer' => 'Numer ' . $validated['numer'] . ' jest już zajęty przez innego zawodnika.'])
                ->withInput();
        }

        try {
            $nazwaPliku = $this->zapiszZdjecie($request);
            $pozycja = $this->pozycjaDoZapisu($validated);

            $idNowego = DB::table('pilkarze')->insertGetId([
                'imie' => $validated['imie'],
                'nazwisko' => $validated['nazwisko'],
                'pozycja' => $pozycja,
                'numer' => $validated['pozycja'] === 'Sztab' ? 0 : $validated['numer'],
                'zdjecie' => $nazwaPliku,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            if ($validated['pozycja'] !== 'Sztab') {
                $this->zapiszStatystyki($idNowego, []);
            }

            return redirect()->route('kadra.indeks')->with('sukces', 'Dodano osobę do kadry.');
        } catch (\Throwable $e) {
            return redirect()->back()->withErrors(['blad' => 'Wystąpił błąd podczas zapisu do bazy danych.'])->withInput();
        }
    }

    public function edytuj($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('kadra.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $osoba = DB::table('pilkarze')->where('id', $id)->first();

        if (!$osoba) {
            return redirect()->route('kadra.indeks');
        }

        $statystyki = DB::table('statystyki_pilkarzy')->where('pilkarz_id', $id)->first();

        return view('kadra.edytuj', compact('osoba', 'statystyki'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('kadra.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $osoba = DB::table('pilkarze')->where('id', $id)->first();

        if (!$osoba) {
            return redirect()->route('kadra.indeks');
        }

        $validated = $this->walidujKadre($request, true);

        if (($validated['numer'] ?? 0) !== 0) {
            $zajety = DB::table('pilkarze')
                ->where('numer', $validated['numer'])
                ->where('id', '!=', $id)
                ->exists();

            if ($zajety) {
                return redirect()->back()
                    ->withErrors(['numer' => 'Numer ' . $validated['numer'] . ' jest już zajęty.'])
                    ->withInput();
            }
        }

        try {
            $nazwaPliku = $osoba->zdjecie;

            if ($request->hasFile('zdjecie')) {
                $this->usunZdjecie($osoba->zdjecie);
                $nazwaPliku = $this->zapiszZdjecie($request);
            }

            DB::table('pilkarze')->where('id', $id)->update([
                'imie' => $validated['imie'],
                'nazwisko' => $validated['nazwisko'],
                'pozycja' => $this->pozycjaDoZapisu($validated),
                'numer' => $validated['pozycja'] === 'Sztab' ? 0 : $validated['numer'],
                'zdjecie' => $nazwaPliku,
                'updated_at' => now(),
            ]);

            if ($validated['pozycja'] === 'Sztab') {
                DB::table('statystyki_pilkarzy')->where('pilkarz_id', $id)->delete();
            } else {
                $this->zapiszStatystyki($id, $validated);
            }

            return redirect()->route('kadra.indeks')->with('sukces', 'Zaktualizowano dane kadry.');
        } catch (\Throwable $e) {
            return redirect()->back()->withErrors(['blad' => 'Błąd aktualizacji bazy danych.'])->withInput();
        }
    }

    public function usun($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('kadra.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        try {
            $osoba = DB::table('pilkarze')->where('id', $id)->first();

            if ($osoba) {
                $this->usunZdjecie($osoba->zdjecie);
                DB::table('pilkarze')->where('id', $id)->delete();
            }

            return redirect()->route('kadra.indeks')->with('sukces', 'Usunięto członka kadry.');
        } catch (\Throwable $e) {
            return redirect()->route('kadra.indeks')->withErrors(['blad' => 'Błąd podczas usuwania z bazy.']);
        }
    }

    private function walidujKadre(Request $request, bool $zeStatystykami = false): array
    {
        if ($request->input('pozycja') === 'Sztab') {
            $request->merge(['numer' => 0]);
        }

        $rules = [
            'imie' => ['required', 'string', 'max:50', 'regex:' . self::TEKST_REGEX],
            'nazwisko' => ['required', 'string', 'max:50', 'regex:' . self::TEKST_REGEX],
            'pozycja' => ['required', Rule::in(self::POZYCJE)],
            'numer' => ['required', 'integer', 'min:0', 'max:99'],
            'funkcja_sztab' => ['nullable', 'required_if:pozycja,Sztab', 'string', 'max:50', 'regex:' . self::TEKST_REGEX],
            'zdjecie' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
        ];

        if ($zeStatystykami) {
            $rules = array_merge($rules, [
                'wystepy' => ['nullable', 'integer', 'min:0', 'max:100'],
                'minuty' => ['nullable', 'integer', 'min:0', 'max:10000'],
                'gole' => ['nullable', 'integer', 'min:0', 'max:100'],
                'asysty' => ['nullable', 'integer', 'min:0', 'max:100'],
                'czyste_konta' => ['nullable', 'integer', 'min:0', 'max:100'],
                'zolte_kartki' => ['nullable', 'integer', 'min:0', 'max:100'],
                'czerwone_kartki' => ['nullable', 'integer', 'min:0', 'max:100'],
            ]);
        }

        return $request->validate($rules, [
            'imie.required' => 'Musisz podać imię.',
            'imie.regex' => 'Imię może zawierać tylko litery, spacje i myślnik.',
            'nazwisko.required' => 'Musisz podać nazwisko.',
            'nazwisko.regex' => 'Nazwisko może zawierać tylko litery, spacje i myślnik.',
            'pozycja.in' => 'Wybierz poprawną pozycję z listy.',
            'numer.integer' => 'Numer koszulki musi być liczbą całkowitą.',
            'numer.min' => 'Numer nie może być ujemny.',
            'numer.max' => 'Numer nie może być większy niż 99.',
            'funkcja_sztab.required_if' => 'Podaj funkcję dla członka sztabu.',
            'funkcja_sztab.regex' => 'Funkcja może zawierać tylko litery, spacje i myślnik.',
            'zdjecie.image' => 'Przesłany plik musi być zdjęciem.',
            'zdjecie.max' => 'Zdjęcie nie może być większe niż 2 MB.',
        ]);
    }

    private function pozycjaDoZapisu(array $validated): string
    {
        if ($validated['pozycja'] === 'Sztab' && !empty($validated['funkcja_sztab'])) {
            return 'Sztab (' . ucfirst(mb_strtolower($validated['funkcja_sztab'])) . ')';
        }

        return $validated['pozycja'];
    }

    private function zapiszStatystyki(int $pilkarzId, array $dane): void
    {
        DB::table('statystyki_pilkarzy')->updateOrInsert(
            ['pilkarz_id' => $pilkarzId],
            [
                'wystepy' => $dane['wystepy'] ?? 0,
                'minuty' => $dane['minuty'] ?? 0,
                'gole' => $dane['gole'] ?? 0,
                'asysty' => $dane['asysty'] ?? 0,
                'czyste_konta' => $dane['czyste_konta'] ?? 0,
                'zolte_kartki' => $dane['zolte_kartki'] ?? 0,
                'czerwone_kartki' => $dane['czerwone_kartki'] ?? 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }

    private function zapiszZdjecie(Request $request): ?string
    {
        if (!$request->hasFile('zdjecie')) {
            return null;
        }

        $file = $request->file('zdjecie');
        $cleanImie = preg_replace('/[^A-Za-z0-9\-]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $request->imie));
        $cleanNazwisko = preg_replace('/[^A-Za-z0-9\-]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $request->nazwisko));
        $nazwaPliku = $cleanImie . '_' . $cleanNazwisko . '_' . time() . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('images/Zdjecia_pilkarzy'), $nazwaPliku);

        return $nazwaPliku;
    }

    private function usunZdjecie(?string $nazwaPliku): void
    {
        if (!$nazwaPliku) {
            return;
        }

        $sciezka = public_path('images/Zdjecia_pilkarzy/' . $nazwaPliku);

        if (file_exists($sciezka)) {
            @unlink($sciezka);
        }
    }

    private function czyPrezes(): bool
    {
        return Auth::check() && Auth::user()->rola === 'prezes';
    }
}
