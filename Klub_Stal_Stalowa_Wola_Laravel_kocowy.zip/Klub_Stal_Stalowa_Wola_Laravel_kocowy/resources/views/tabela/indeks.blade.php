@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-8">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-200 pb-6 mb-8">
            <div class="flex items-center gap-4">
                <div class="bg-white p-1.5 rounded-lg shadow-sm border border-gray-200">
                    <img src="{{ asset('images/drugaLiga.png') }}" alt="Betclic 2 Liga" class="h-10 object-contain">
                </div>
                <div>
                    <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Tabela Betclic 2. Ligi</h1>
                    <p class="text-sm text-gray-500 mt-1">Klasyfikacja ligowa - miejsca 1-18</p>
                </div>
            </div>

            @auth
                @if(Auth::user()->rola === 'prezes')
                    <a href="{{ route('tabela.dodaj') }}" class="bg-stalZielony text-white px-5 py-3 rounded-lg text-xs font-black uppercase shadow hover:bg-green-700 text-center">
                        Dodaj drużynę
                    </a>
                @endif
            @endauth
        </div>

        @if(session('sukces'))
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ session('sukces') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ $errors->first() }}
            </div>
        @endif

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="grid grid-cols-[56px_1fr_72px_72px_88px] md:grid-cols-[56px_1fr_72px_72px_88px_150px] gap-3 px-5 py-3 bg-stalCzarny text-white text-[10px] font-black uppercase tracking-widest">
                <div>Miejsce</div>
                <div>Druzyna</div>
                <div class="text-center">Mecze</div>
                <div class="text-center">Bramki</div>
                <div class="text-center">Punkty</div>
                @auth
                    @if(Auth::user()->rola === 'prezes')
                        <div class="hidden md:block text-right">Akcje</div>
                    @endif
                @endauth
            </div>

            <div class="divide-y divide-gray-100">
                @foreach($druzyny as $druzyna)
                    @php
                        $bilans = $druzyna->bramki_zdobyte - $druzyna->bramki_stracone;
                    @endphp
                    <div class="grid grid-cols-[56px_1fr_72px_72px_88px] md:grid-cols-[56px_1fr_72px_72px_88px_150px] gap-3 px-5 py-4 items-center hover:bg-gray-50 transition {{ $druzyna->nazwa === 'Stal Stalowa Wola' ? 'bg-green-50/60' : '' }}">
                        <div class="font-mono text-sm font-black text-gray-500">{{ $loop->iteration }}</div>
                        <div class="font-black uppercase tracking-wide text-sm text-stalCzarny">
                            {{ $druzyna->nazwa }}
                        </div>
                        <div class="text-center text-sm font-bold text-gray-600">{{ $druzyna->mecze_rozegrane }}</div>
                        <div class="text-center text-sm font-bold text-gray-600">
                            {{ $druzyna->bramki_zdobyte }}:{{ $druzyna->bramki_stracone }}
                            <span class="block text-[10px] text-gray-400">{{ $bilans >= 0 ? '+' : '' }}{{ $bilans }}</span>
                        </div>
                        <div class="text-center">
                            <span class="inline-flex items-center justify-center min-w-10 rounded-lg bg-stalZielony text-white font-black px-3 py-1">
                                {{ $druzyna->punkty }}
                            </span>
                        </div>
                        @auth
                            @if(Auth::user()->rola === 'prezes')
                                <div class="col-span-5 md:col-span-1 flex md:justify-end gap-2">
                                    <a href="{{ route('tabela.edytuj', $druzyna->id) }}" class="bg-yellow-500 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Edytuj</a>
                                    <form action="{{ route('tabela.usun', $druzyna->id) }}" method="POST" onsubmit="return confirm('Usunąć tę drużynę z tabeli?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="bg-red-600 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Usuń</button>
                                    </form>
                                </div>
                            @endif
                        @endauth
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
