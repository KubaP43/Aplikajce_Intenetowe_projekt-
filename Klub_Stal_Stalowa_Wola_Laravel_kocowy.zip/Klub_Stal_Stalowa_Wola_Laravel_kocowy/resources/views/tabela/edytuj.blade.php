@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-6">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Edytuj drużynę</h1>
                <p class="text-sm text-gray-500">{{ $druzyna->nazwa }}</p>
            </div>
            <a href="{{ route('tabela.indeks') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-xs font-bold uppercase">Powrót</a>
        </div>

        @include('tabela.formularz', ['action' => route('tabela.aktualizuj', $druzyna->id), 'method' => 'PUT', 'druzyna' => $druzyna])
    </div>
</div>
@endsection
