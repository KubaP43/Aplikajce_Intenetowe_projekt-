@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-8">

        <div class="text-center border-b border-gray-200 pb-6 mb-8">
            <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Historia i Tradycja</h1>
            <p class="text-sm text-gray-500 mt-1">Poznaj dzieje Hutniczego Grodu od 1938 roku</p>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-8">
            <img src="{{ asset('images/oStadionie.jpg') }}" alt="PCPN z lotu ptaka" class="w-full h-[360px] object-cover" 
                 onerror="this.onerror=null; this.src='{{ asset('images/stadion.png') }}';">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center hover:border-stalZielony transition duration-300">
                <span class="block text-2xl font-black text-stalCzarny mb-1">1938</span>
                <h3 class="text-xs font-black text-gray-400 uppercase tracking-wider mb-2">Rok Założenia</h3>
                <p class="text-gray-600 text-xs font-medium leading-relaxed">
                    Początki klubu sięgają okresu budowy Centralnego Okręgu Przemysłowego.
                </p>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center hover:border-stalZielony transition duration-300">
                <div class="flex justify-center gap-1.5 mb-2">
                    <span class="w-5 h-5 rounded-full bg-green-600 border border-green-700 block"></span>
                    <span class="w-5 h-5 rounded-full bg-black border border-gray-900 block"></span>
                </div>
                <h3 class="text-xs font-black text-gray-400 uppercase tracking-wider mb-2">Barwy Klubowe</h3>
                <p class="text-gray-600 text-xs font-medium leading-relaxed">
                    Zielony i czarny — barwy symbolizujące ciężką pracę, hutnictwo i charakter.
                </p>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 text-center hover:border-stalZielony transition duration-300">
                <span class="block text-sm font-black text-stalZielony uppercase tracking-widest mb-1">PCPN</span>
                <h3 class="text-xs font-black text-gray-400 uppercase tracking-wider mb-2">Nasza Twierdza</h3>
                <p class="text-gray-600 text-xs font-medium leading-relaxed">
                    Mecze rozgrywamy na nowoczesnym stadionie PCPN przy ul. Hutniczej.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8 items-start">
            
            <div class="lg:col-span-2 space-y-6">
                <div class="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
                    <h2 class="text-base font-black text-stalCzarny uppercase tracking-wide border-b border-gray-100 pb-3 mb-4">
                        Duma Hutniczego Grodu
                    </h2>
                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed font-medium text-justify">
                        Klub Stal Stalowa Wola powstał w 1938 roku jako Klub Sportowy Stalowa Wola. Od samego początku istnienia był mocno związany z Zakładami Południowymi (późniejszą Hutą Stalowa Wola). Największe sukcesy klubu to wieloletnie występy na poziomie dzisiejszej I ligi oraz historyczne awanse do Ekstraklasy (dawnej I ligi państwowej) w latach 90. Stalówka zawsze słynęła z niesamowitego charakteru, waleczności oraz oddanych kibiców, którzy wspierają swój zespół bez względu na ligę, w której aktualnie gra.
                    </p>
                </div>

                <div class="bg-white p-8 rounded-xl shadow-sm border border-gray-200 space-y-4">
                    <h2 class="text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100 pb-2">
                        Kronika Historyczna Spółki Akcyjnej
                    </h2>
                    
                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed text-justify font-medium">
                        Przybyły ze Śląska Feliks Olszak – dyrektor Zakładu Hutniczego, utworzył w 1938 r. Klub Sportowy “Stalowa Wola”. Klub dysponował boiskiem piłkarskim bez bieżni i trybun oraz czterema kortami tenisowymi. Zawodnicy byli amatorami, trenowali po godzinach pracy, a mecze rozgrywali w niedzielę. Pierwszym trenerem piłkarzy był zawodnik Cracovii Karol Walkowski. W święto św. Floriana, patrona hutników 4 maja 1939 r. odbył się pierwszy mecz junaków budujących miasta i drużyną KS “Stalowa Wola”, zakończony remisem 1:1.
                    </p>

                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed text-justify font-medium">
                        Po wojnie prezesem klubu został Kazimierz Radźwicki. Na mecze piłkarskie przychodziły tłumy fanów. Sprowadzony z Krakowa trener Stanisław Malczyk utworzył bardzo dobrą drużynę z młodych zawodników, a jej trzon tworzyli: Rudolf Patkolo, Jerzy Famulski, Zdzisław Nowak, Zbigniew Opoka, Józef Będkowski, Ryszard Kozerski i Józef Hawryło. Piłkarze weszli po raz pierwszy do II ligi w 1973 r., a twórcą historycznego awansu był trener Jerzy Kopa. W zespole grali: Zbigniew Hnatio, Józef Leś, Stanisław Karaś, Zdzisław Napieracz, Kazimierz Goleń, Bogusław Szczerbiński, Krystian Muskała, Edward Osadnik, Zbigniew Żelichowski, Józef Jachym, Eugeniusz Miler, Jerzy Gierak, Andrzej Demko.
                    </p>

                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed text-justify font-medium">
                        W II lidze “Stalówka” występowała do 1987 r. i po raz pierwszy piłkarze awansowali do I ligi pokonując w barażach Górnik Knurów. Autorami awansu byli trenerzy Władysław Szaryński i Krystian Muskała i piłkarze Jerzy Rogoziński, Jacek Lis, Wojciech Niemiec, Janusz Weselak, Zygmunt Tworek, Krzysztof Bzdyra, Dariusz Sajdak, Artur Kopeć, Antoni Fijarczyk, Mirosław Mścisz, Janusz Mulawka, Wiesław Pędlowski, Wojciech Nieradka, Krzysztof Strzelec, Paweł Rybak, Stanisław Trawiński, Bogdan Tereszkiewicz, Artur Śmietana, Dariusz Liśkiewicz i Krzysztof Sęk.
                    </p>

                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed text-justify font-medium">
                        W I lidze piłkarze grali przez jeden sezon, a ponownie powrócili w 1990 r. Ta przygoda z ekstraklasą trwała rok, a na 2 lata futboliści zagościli w niej znów, dzięki duetowi trenerskiemu: Włodzimierz Gąsior i Piotr Brzeziński. Kolejne lata to zmagania piłkarzy “Stali” o awanse i powroty do II ligi. Po wielu latach funkcjonowania jako stowarzyszenie, w maju 2010 roku do życia została powołana spółka akcyjna. „Stal” Stalowa Wola Piłkarska Spółka Akcyjna jest prawnym następcą i kontynuatorem ZKS „Stal” Stalowa Wola. W lipcu 2018 roku pakiet większościowy spółki przejęło Miasto Stalowa Wola.
                    </p>
                </div>
            </div>

            <div class="lg:col-span-1 space-y-6">
                <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 class="text-sm font-black text-stalCzarny uppercase tracking-wide border-b border-gray-100 pb-2 mb-4">
                        Profil Stadionu PCPN
                    </h3>
                    
                    <div class="space-y-4 text-xs font-bold text-gray-700">
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Pojemność całkowita:</span>
                            <span class="font-mono text-sm">3764 miejsc</span>
                        </div>
                        
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Trybuna wschodnia:</span>
                            <span class="font-mono text-sm">1430 miejsc</span>
                        </div>
                        
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Trybuna zachodnia:</span>
                            <span class="font-mono text-sm">2076 miejsc</span>
                        </div>
                        
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Sektor gości:</span>
                            <span class="font-mono text-sm">258 miejsc</span>
                        </div>
                        
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Sztuczne oświetlenie:</span>
                            <span class="text-stalZielony text-xs font-black uppercase">Tak</span>
                        </div>
                        
                        <div>
                            <span class="text-gray-400 font-medium block mb-0.5">Podgrzewana murawa:</span>
                            <span class="text-stalZielony text-xs font-black uppercase">Tak</span>
                        </div>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 class="text-xs font-black text-gray-400 uppercase tracking-widest mb-3 border-b border-gray-100 pb-2">
                        Adres Klubu
                    </h3>
                    <p class="text-xs font-bold text-gray-700 leading-relaxed font-mono">
                        ul. Hutnicza 10a,<br>
                        37-450 Stalowa Wola
                    </p>
                </div>
            </div>

        </div>

    </div>
</div>
@endsection