@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-5xl mx-auto px-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-8 gap-4">
            <div class="flex items-center gap-4">
                <div class="bg-white p-1.5 rounded-lg shadow-sm border border-gray-200">
                    <img src="{{ asset('images/drugaLiga.png') }}" alt="Betclic 2 Liga" class="h-10 object-contain">
                </div>
                <div>
                    <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Terminarz Rozgrywek</h1>
                    <p class="text-sm text-gray-500 mt-1">Mecze Stali Stalowa Wola - sezon 2025/2026</p>
                </div>
            </div>

            @auth
                @if(Auth::user()->rola === 'prezes')
                    <a href="{{ route('mecze.dodaj') }}" class="inline-flex items-center gap-2 bg-stalZielony text-white font-bold px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider shadow hover:bg-green-700 transition">
                        Dodaj mecz
                    </a>
                @endif
            @endauth
        </div>

        @if(session('sukces'))
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ session('sukces') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ $errors->first() }}
            </div>
        @endif

        @if($mecze->isEmpty())
            <div class="bg-white p-12 rounded-xl shadow-sm text-center border border-gray-200">
                <p class="text-gray-500 font-medium text-sm">Brak zaplanowanych meczow w tym momencie.</p>
            </div>
        @else
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="divide-y divide-gray-100">
                    @foreach($mecze as $mecz)
                        <div class="p-6 flex flex-col sm:flex-row justify-between items-center gap-4 hover:bg-gray-50 transition">
                            <div class="flex items-center gap-4">
                                <div class="bg-gray-100 px-3 py-1.5 rounded-lg text-center font-mono text-xs font-bold text-gray-600">
                                    {{ \Carbon\Carbon::parse($mecz->data_meczu)->format('d.m.Y - H:i') }}
                                </div>
                                <span class="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded {{ $mecz->czy_domowy ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-orange-50 text-orange-700 border border-orange-100' }}">
                                    {{ $mecz->czy_domowy ? 'Dom' : 'Wyjazd' }}
                                </span>
                            </div>

                            <div class="flex-1 text-center sm:text-left sm:pl-4">
                                <h3 class="text-base font-black text-stalCzarny uppercase tracking-wide">
                                    @if($mecz->czy_domowy)
                                        Stal Stalowa Wola - {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }}
                                    @else
                                        {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }} - Stal Stalowa Wola
                                    @endif
                                </h3>
                                <p class="text-xs text-gray-400 mt-1">{{ $mecz->miejsce }}</p>
                            </div>

                            @auth
                                @if(Auth::user()->rola === 'prezes')
                                    <div class="flex items-center gap-2">
                                        <a href="{{ route('mecze.edytuj', $mecz->id) }}" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold px-4 py-2 rounded-lg text-[10px] uppercase tracking-wider shadow-sm transition">
                                            Edytuj
                                        </a>
                                        <form action="{{ route('mecze.usun', $mecz->id) }}" method="POST" onsubmit="return confirm('Czy na pewno chcesz usunac ten mecz?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-lg text-[10px] uppercase tracking-wider shadow-sm transition">
                                                Usun
                                            </button>
                                        </form>
                                    </div>
                                @endif
                            @endauth
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
