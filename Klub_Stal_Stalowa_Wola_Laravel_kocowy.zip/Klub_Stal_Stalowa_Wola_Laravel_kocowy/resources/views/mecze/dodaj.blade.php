@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-8">
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Dodaj do terminarza</h1>
                <p class="text-xs text-gray-500 mt-0.5">Panel zarzadzania klubem - rola: Prezes</p>
            </div>
            <a href="{{ route('mecze.indeks') }}" class="text-xs font-bold uppercase tracking-wider bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition">
                Powrot
            </a>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <form action="{{ route('mecze.zapisz') }}" method="POST" class="p-8 space-y-6" novalidate>
                @csrf

                @if ($errors->any())
                    <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium space-y-1">
                        @foreach ($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif

                <div>
                    <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Wybierz przeciwnika</label>
                    <select name="druzyna_id" required class="w-full border @error('druzyna_id') border-red-500 @else border-gray-300 @enderror p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                        <option value="">-- Wybierz druzyne przeciwna --</option>
                        @foreach($druzyny as $druzyna)
                            <option value="{{ $druzyna->id }}" {{ old('druzyna_id') == $druzyna->id ? 'selected' : '' }}>
                                {{ $druzyna->nazwa }}
                            </option>
                        @endforeach
                    </select>
                    @error('druzyna_id') <p class="text-red-600 text-xs font-bold mt-1">{{ $message }}</p> @enderror
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Data i godzina spotkania</label>
                        <input type="datetime-local" name="data_meczu" value="{{ old('data_meczu') }}" class="w-full border @error('data_meczu') border-red-500 @else border-gray-300 @enderror p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium font-mono">
                        @error('data_meczu') <p class="text-red-600 text-xs font-bold mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Miejsce rozgrywania</label>
                        <select name="czy_domowy" required class="w-full border @error('czy_domowy') border-red-500 @else border-gray-300 @enderror p-3 rounded-lg text-sm focus:ring-2 focus:ring-stalZielony focus:border-stalZielony focus:outline-none bg-gray-50 font-medium">
                            <option value="1" {{ old('czy_domowy') == '1' ? 'selected' : '' }}>Mecz domowy (PCPN Stalowa Wola)</option>
                            <option value="0" {{ old('czy_domowy') == '0' ? 'selected' : '' }}>Mecz wyjazdowy</option>
                        </select>
                        @error('czy_domowy') <p class="text-red-600 text-xs font-bold mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>

                <div class="border-t border-gray-100 pt-6 flex justify-end">
                    <button type="submit" class="w-full sm:w-auto bg-stalZielony hover:bg-green-700 text-white font-black px-8 py-3 rounded-lg text-xs uppercase tracking-widest shadow-md transition">
                        Zapisz i dodaj do bazy
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
