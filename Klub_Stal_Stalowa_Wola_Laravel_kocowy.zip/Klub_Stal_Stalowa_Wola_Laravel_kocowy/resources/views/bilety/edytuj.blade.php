@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="p-8 max-w-2xl mx-auto">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-black uppercase text-stalCzarny tracking-wide">Edycja biletu</h1>
                <p class="text-gray-500 text-sm mt-1">Kod: {{ $bilet->kod_biletu }}</p>
            </div>
            <a href="{{ route('bilety.indeks') }}" class="text-xs font-bold uppercase tracking-wider bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">
                Powrot
            </a>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-stalZielony">
            @if($errors->any())
                <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                    @foreach($errors->all() as $error)
                        <p>{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            <form action="{{ route('bilety.aktualizuj', $bilet->id) }}" method="POST" class="space-y-5">
                @csrf
                @method('PUT')

                <div>
                    <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Mecz</label>
                    <select name="mecz_id" class="w-full border border-gray-300 p-3 rounded-lg text-sm bg-white" required>
                        @foreach($mecze as $mecz)
                            <option value="{{ $mecz->id }}" {{ $bilet->mecz_id == $mecz->id ? 'selected' : '' }}>
                                {{ \Carbon\Carbon::parse($mecz->data_meczu)->format('d.m.Y H:i') }} - Stal Stalowa Wola vs {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Trybuna</label>
                    <select name="sektor" class="w-full border border-gray-300 p-3 rounded-lg text-sm bg-white" required>
                        @foreach(['Trybuna Glowna', 'Sektor A - Mlyn', 'Sektor B - Rodzinny'] as $sektor)
                            <option value="{{ $sektor }}" {{ $bilet->sektor === $sektor ? 'selected' : '' }}>{{ $sektor }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Typ biletu</label>
                    <select name="typ_biletu" class="w-full border border-gray-300 p-3 rounded-lg text-sm bg-white" required>
                        <option value="normalny" {{ $bilet->typ_biletu === 'normalny' ? 'selected' : '' }}>Normalny</option>
                        <option value="ulgowy" {{ $bilet->typ_biletu === 'ulgowy' ? 'selected' : '' }}>Ulgowy</option>
                    </select>
                </div>

                <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-xs text-gray-600">
                    Kibic: <strong>{{ $bilet->imie_nazwisko_kibica }}</strong>, PESEL: <strong>{{ $bilet->pesel_kibica }}</strong>
                </div>

                <button type="submit" class="w-full bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase shadow hover:bg-green-800">
                    Zapisz zmiany
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
