@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="p-8 max-w-2xl mx-auto">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-black uppercase text-stalCzarny tracking-wide">Rezerwacja biletu</h1>
                <p class="text-gray-500 text-sm mt-1">Wybierz mecz, trybune i typ biletu.</p>
            </div>
            <a href="{{ route('bilety.indeks') }}" class="text-xs font-bold uppercase tracking-wider bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">
                Powrot
            </a>
        </div>

        <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-stalZielony">
            @if($errors->any())
                <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                    @foreach($errors->all() as $error)
                        <p>{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            @if($mecze->isEmpty())
                <div class="bg-gray-50 border border-gray-200 p-6 rounded-lg text-center">
                    <p class="text-sm text-gray-600">Brak domowych meczow dostepnych do rezerwacji.</p>
                </div>
            @else
                <form action="{{ route('bilety.zapisz') }}" method="POST" class="space-y-5">
                    @csrf

                    <div>
                        <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Mecz</label>
                        <select name="mecz_id" class="w-full border border-gray-300 p-3 rounded-lg text-sm bg-white" required>
                            <option value="">-- Wybierz mecz --</option>
                            @foreach($mecze as $mecz)
                                <option value="{{ $mecz->id }}" {{ old('mecz_id') == $mecz->id ? 'selected' : '' }}>
                                    {{ \Carbon\Carbon::parse($mecz->data_meczu)->format('d.m.Y H:i') }} - Stal Stalowa Wola vs {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Trybuna</label>
                        <select name="sektor" class="w-full border border-gray-300 p-3 rounded-lg text-sm bg-white" required>
                            <option value="Trybuna Glowna" {{ old('sektor') === 'Trybuna Glowna' ? 'selected' : '' }}>Trybuna Glowna</option>
                            <option value="Sektor A - Mlyn" {{ old('sektor') === 'Sektor A - Mlyn' ? 'selected' : '' }}>Sektor A - Mlyn</option>
                            <option value="Sektor B - Rodzinny" {{ old('sektor') === 'Sektor B - Rodzinny' ? 'selected' : '' }}>Sektor B - Rodzinny</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-black text-gray-600 uppercase tracking-wider mb-1">Typ biletu</label>
                        <div class="grid grid-cols-2 gap-3">
                            <label class="border border-gray-300 rounded-lg p-4 cursor-pointer hover:border-stalZielony">
                                <input type="radio" name="typ_biletu" value="normalny" class="mr-2" {{ old('typ_biletu', 'normalny') === 'normalny' ? 'checked' : '' }}>
                                <span class="font-bold text-sm">Normalny</span>
                            </label>
                            <label class="border border-gray-300 rounded-lg p-4 cursor-pointer hover:border-stalZielony">
                                <input type="radio" name="typ_biletu" value="ulgowy" class="mr-2" {{ old('typ_biletu') === 'ulgowy' ? 'checked' : '' }}>
                                <span class="font-bold text-sm">Ulgowy</span>
                            </label>
                        </div>
                    </div>

                    <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-xs text-gray-600">
                        Bilet zostanie zapisany na dane z Twojego konta: <strong>{{ Auth::user()->imie }} {{ Auth::user()->nazwisko }}</strong>.
                    </div>

                    <button type="submit" class="w-full bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase shadow hover:bg-green-800">
                        Potwierdzam rezerwacje
                    </button>
                </form>
            @endif
        </div>
    </div>
</div>
@endsection
