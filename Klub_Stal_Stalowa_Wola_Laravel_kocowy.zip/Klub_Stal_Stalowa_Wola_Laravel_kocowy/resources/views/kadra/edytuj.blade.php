@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-6">
        
        <div class="mb-6">
            <a href="{{ route('kadra.indeks') }}" class="text-xs font-black text-gray-500 uppercase tracking-widest hover:text-stalCzarny transition">
                &larr; Powrót do kadry
            </a>
            <h1 class="text-2xl font-black text-stalCzarny uppercase tracking-wide mt-2">Edycja Członka Kadry</h1>
        </div>

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-bold uppercase tracking-wider mb-6">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('kadra.aktualizuj', $osoba->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            @method('PUT')

            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-4">
                <h2 class="text-sm font-black text-stalCzarny uppercase tracking-wider border-b border-gray-100 pb-2">Dane podstawowe</h2>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Imię</label>
                        <input type="text" name="imie" value="{{ old('imie', $osoba->imie) }}" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Nazwisko</label>
                        <input type="text" name="nazwisko" value="{{ old('nazwisko', $osoba->nazwisko) }}" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Pozycja</label>
                        <select name="pozycja" id="pozycjaSelect" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-stalZielony">
                            <option value="Bramkarz" {{ old('pozycja', $osoba->pozycja) == 'Bramkarz' ? 'selected' : '' }}>Bramkarz</option>
                            <option value="Obrońca" {{ old('pozycja', $osoba->pozycja) == 'Obrońca' ? 'selected' : '' }}>Obrońca</option>
                            <option value="Pomocnik" {{ old('pozycja', $osoba->pozycja) == 'Pomocnik' ? 'selected' : '' }}>Pomocnik</option>
                            <option value="Napastnik" {{ old('pozycja', $osoba->pozycja) == 'Napastnik' ? 'selected' : '' }}>Napastnik</option>
                            <option value="Sztab" {{ \Illuminate\Support\Str::startsWith($osoba->pozycja, 'Sztab') ? 'selected' : '' }}>Sztab Szkoleniowy</option>
                        </select>
                    </div>
                    <div id="numerContainer">
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Numer na koszulce</label>
                        <input type="number" name="numer" value="{{ old('numer', $osoba->numer) }}" min="1" max="99" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2.5 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Zdjęcie zawodnika</label>
                    <input type="file" name="zdjecie" class="w-full text-xs font-bold text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-black file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200">
                </div>
            </div>

            <div id="statystykiSection" class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-4">
                <h2 class="text-sm font-black text-stalCzarny uppercase tracking-wider border-b border-gray-100 pb-2">Statystyki meczowe</h2>
                
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Występy</label>
                        <input type="number" name="wystepy" value="{{ old('wystepy', $statystyki->wystepy ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Rozegrane minuty</label>
                        <input type="number" name="minuty" value="{{ old('minuty', $statystyki->minuty ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Bramki</label>
                        <input type="number" name="gole" value="{{ old('gole', $statystyki->gole ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Asysty</label>
                        <input type="number" name="asysty" value="{{ old('asysty', $statystyki->asysty ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div id="czysteKontaContainer">
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Czyste konta</label>
                        <input type="number" name="czyste_konta" value="{{ old('czyste_konta', $statystyki->czyste_konta ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Żółte kartki</label>
                        <input type="number" name="zolte_kartki" value="{{ old('zolte_kartki', $statystyki->zolte_kartki ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Czerwone kartki</label>
                        <input type="number" name="czerwone_kartki" value="{{ old('czerwone_kartki', $statystyki->czerwone_kartki ?? 0) }}" min="0" class="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-stalZielony">
                    </div>
                </div>
            </div>

            <div class="flex gap-3">
                <button type="submit" class="flex-1 bg-stalZielony hover:bg-green-700 text-white font-black py-3 rounded-xl text-xs uppercase tracking-wider shadow transition">
                    Zapisz zmiany zawodnika
                </button>
                <a href="{{ route('kadra.indeks') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-black px-6 py-3 rounded-xl text-xs uppercase tracking-wider transition flex items-center justify-center">
                    Anuluj
                </a>
            </div>
        </form>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const pozycjaSelect = document.getElementById('pozycjaSelect');
        const numerContainer = document.getElementById('numerContainer');
        const statystykiSection = document.getElementById('statystykiSection');
        const czysteKontaContainer = document.getElementById('czysteKontaContainer');

        function przelaczWidoki() {
            const val = pozycjaSelect.value;
            if(val === 'Sztab') {
                numerContainer.style.display = 'none';
                statystykiSection.style.display = 'none';
            } else {
                numerContainer.style.display = 'block';
                statystykiSection.style.display = 'block';
                if(val === 'Bramkarz') {
                    czysteKontaContainer.style.display = 'block';
                } else {
                    czysteKontaContainer.style.display = 'none';
                }
            }
        }

        pozycjaSelect.addEventListener('change', przelaczWidoki);
        przelaczWidoki();
    });
</script>
@endsection