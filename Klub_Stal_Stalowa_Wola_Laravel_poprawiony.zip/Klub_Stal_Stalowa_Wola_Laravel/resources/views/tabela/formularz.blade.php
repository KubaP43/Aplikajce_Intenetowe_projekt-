<form action="{{ $action }}" method="POST" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 space-y-5">
    @csrf
    @if($method !== 'POST')
        @method($method)
    @endif

    @if($errors->any())
        <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <div>
        <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Nazwa drużyny</label>
        <input type="text" name="nazwa" value="{{ old('nazwa', $druzyna->nazwa ?? '') }}" minlength="3" maxlength="100" pattern=".*[A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż].*" class="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:border-stalZielony" required>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
            <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Punkty</label>
            <input type="number" name="punkty" min="0" max="150" value="{{ old('punkty', $druzyna->punkty ?? 0) }}" class="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:border-stalZielony" required>
        </div>
        <div>
            <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Mecze rozegrane</label>
            <input type="number" name="mecze_rozegrane" min="0" max="80" value="{{ old('mecze_rozegrane', $druzyna->mecze_rozegrane ?? 0) }}" class="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:border-stalZielony" required>
        </div>
        <div>
            <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Bramki zdobyte</label>
            <input type="number" name="bramki_zdobyte" min="0" max="300" value="{{ old('bramki_zdobyte', $druzyna->bramki_zdobyte ?? 0) }}" class="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:border-stalZielony" required>
        </div>
        <div>
            <label class="block text-xs font-black text-gray-500 uppercase tracking-wider mb-1">Bramki stracone</label>
            <input type="number" name="bramki_stracone" min="0" max="300" value="{{ old('bramki_stracone', $druzyna->bramki_stracone ?? 0) }}" class="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-gray-50 focus:outline-none focus:border-stalZielony" required>
        </div>
    </div>

    <button type="submit" class="w-full bg-stalZielony text-white rounded-lg px-5 py-3 text-xs font-black uppercase shadow hover:bg-green-700">
        Zapisz drużynę
    </button>
</form>
