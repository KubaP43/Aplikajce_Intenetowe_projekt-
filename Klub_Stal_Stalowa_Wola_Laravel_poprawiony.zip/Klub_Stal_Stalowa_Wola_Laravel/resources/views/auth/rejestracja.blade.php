<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Rejestracja - Stal Stalowa Wola</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { stalZielony: '#2e6922', stalCzarny: '#161719' } } } }
        
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
            } else {
                input.type = 'password';
            }
        }
    </script>
</head>
<body class="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat relative px-4 py-8" style="background-image: url('{{ asset('images/stadion.jpg') }}');">
    
    <!-- Rozjaśnione tło (40% czerni zamiast 70%) -->
    <div class="absolute inset-0 bg-black/40"></div>

    <div class="bg-white w-full max-w-lg p-8 rounded shadow-2xl relative z-10 border-t-8 border-stalZielony my-8">
        <div class="mb-4 text-left">
            <a href="{{ route('strona.glowna') }}" class="text-xs text-gray-400 hover:text-stalZielony transition">➔ Powrót do strony głównej</a>
        </div>

        <div class="text-center mb-6">
            <h2 class="text-2xl font-bold uppercase text-stalCzarny">Rejestracja Kibica</h2>
            <p class="text-gray-500 text-xs mt-1">Załóż konto, aby kupować bilety na mecze</p>
        </div>

        @if ($errors->any())
            <div class="bg-red-50 border-l-4 border-red-600 p-4 mb-6 rounded">
                <ul class="text-xs text-red-700 list-disc list-inside space-y-1">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <!-- Wypełnianie zablokowane: autocomplete="off" -->
        <form action="{{ route('kibice.zapisz') }}" method="POST" autocomplete="off" class="space-y-4">
            @csrf

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Imię:</label>
                    <input type="text" name="imie" value="{{ old('imie') }}" autocomplete="off" required maxlength="50" pattern="[A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż\s-]+" class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Nazwisko:</label>
                    <input type="text" name="nazwisko" value="{{ old('nazwisko') }}" autocomplete="off" required maxlength="50" pattern="[A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż\s-]+" class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Numer PESEL:</label>
                <input type="text" name="pesel" value="{{ old('pesel') }}" maxlength="11" pattern="[0-9]{11}" inputmode="numeric" autocomplete="off" class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony" placeholder="11 cyfr" required>
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Data Urodzenia:</label>
                <input type="date" name="data_urodzenia" value="{{ old('data_urodzenia') }}" max="{{ now()->subDay()->format('Y-m-d') }}" required class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony">
            </div>

            <hr class="my-4">

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Adres E-mail (Twój Login):</label>
                <input type="email" name="email" value="{{ old('email') }}" autocomplete="off" class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony" placeholder="przyklad@domena.pl" required>
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Hasło:</label>
                <div class="relative">
                    <input type="password" id="reg-haslo" name="password" autocomplete="new-password" minlength="8" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}" class="w-full border p-2.5 rounded text-sm focus:ring-2 focus:ring-stalZielony pr-10" placeholder="Min. 8 znaków, cyfra, duża litera, znak specjalny" required>
                    <button type="button" onclick="togglePassword('reg-haslo')" class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-stalZielony">
                        👁️
                    </button>
                </div>
            </div>

            <button type="submit" class="w-full bg-stalZielony text-white font-bold p-3 mt-4 rounded text-xs uppercase shadow hover:bg-green-800 transition tracking-wider">
                Utwórz konto kibica
            </button>
        </form>

        <div class="text-center mt-6 pt-4 border-t text-xs text-gray-500">
            Masz już konto? <a href="{{ route('logowanie') }}" class="text-stalZielony font-bold hover:underline ml-1">Zaloguj się</a>
        </div>
    </div>
</body>
</html>
