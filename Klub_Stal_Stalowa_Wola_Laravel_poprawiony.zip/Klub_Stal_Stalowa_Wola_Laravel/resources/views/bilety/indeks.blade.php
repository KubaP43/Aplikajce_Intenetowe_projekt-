@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-6xl mx-auto px-8">
        <div class="mb-8">
            <h1 class="text-3xl font-black uppercase text-stalCzarny tracking-wide">Sprzedaz biletow</h1>
            <p class="text-gray-500 text-sm mt-1">Prosta rezerwacja biletu na domowy mecz Stalowki.</p>
        </div>

        @if(session('sukces'))
            <div class="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ session('sukces') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                {{ $errors->first() }}
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                <p class="text-xs font-bold uppercase text-gray-400 mb-2">Oficjalny cennik wejsciowek</p>
                <img src="{{ asset('images/Kup_Bilet.avif') }}" alt="Cennik biletow" class="w-full rounded-lg border border-gray-200">
            </div>

            <div class="bg-white p-8 rounded-xl shadow-sm border-t-4 border-stalZielony">
                <h2 class="font-black text-xl text-stalCzarny mb-3">Internetowa Kasa Biletowa</h2>
                <p class="text-gray-600 text-sm leading-relaxed mb-5">
                    Wybierz mecz, trybune i typ biletu. System sam przypisze kod rezerwacji oraz zapisze dane kibica z konta.
                </p>

                @guest
                    <div class="bg-gray-50 p-5 rounded-lg border border-gray-200 mb-6">
                        <h3 class="font-black text-stalCzarny uppercase text-sm mb-2">Zakup tylko dla zalogowanych kibicow</h3>
                        <p class="text-sm text-gray-600 leading-relaxed">
                            Zaloguj sie albo utworz konto, zeby zarezerwowac bilet. To pozwala zapisac bilet na Twoje dane i pokazac go pozniej w systemie.
                        </p>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <a href="{{ route('logowanie') }}" class="bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase text-center shadow hover:bg-green-800">
                            Zaloguj sie
                        </a>
                        <a href="{{ route('rejestracja') }}" class="bg-stalCzarny text-white font-bold p-3 rounded-lg text-xs uppercase text-center shadow hover:bg-gray-800">
                            Zarejestruj
                        </a>
                    </div>
                @else
                    <div class="bg-gray-50 p-4 rounded-lg mb-6 text-xs text-gray-600 leading-normal">
                        <span class="font-bold text-stalCzarny block mb-1">Wazne informacje:</span>
                        Bilet ulgowy ma znizke 20%. Bramy stadionu przy ul. Hutniczej 15 otwieramy na 2 godziny przed meczem.
                    </div>

                    <a href="{{ route('bilety.stworz') }}" class="bg-stalZielony text-white font-bold p-3 rounded-lg text-xs uppercase block text-center shadow hover:bg-green-800">
                        Przejdz do zakupu biletu
                    </a>
                @endguest
            </div>
        </div>

        @auth
            <div class="mt-10 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                    <div>
                        <h2 class="text-lg font-black uppercase text-stalCzarny">
                            {{ Auth::user()->rola === 'prezes' ? 'Wszystkie rezerwacje' : 'Moje bilety' }}
                        </h2>
                        <p class="text-xs text-gray-500">
                            {{ Auth::user()->rola === 'prezes' ? 'Prezes widzi pelne dane kibicow.' : 'Tu zobaczysz swoje kody biletow.' }}
                        </p>
                    </div>
                </div>

                <form action="{{ route('bilety.indeks') }}" method="GET" class="px-6 py-4 border-b border-gray-100 grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <select name="sektor" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="">Wszystkie trybuny</option>
                        @foreach(['Trybuna Glowna', 'Sektor A - Mlyn', 'Sektor B - Rodzinny'] as $sektor)
                            <option value="{{ $sektor }}" {{ request('sektor') === $sektor ? 'selected' : '' }}>{{ $sektor }}</option>
                        @endforeach
                    </select>
                    <select name="typ_biletu" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="">Wszystkie typy</option>
                        <option value="normalny" {{ request('typ_biletu') === 'normalny' ? 'selected' : '' }}>Normalny</option>
                        <option value="ulgowy" {{ request('typ_biletu') === 'ulgowy' ? 'selected' : '' }}>Ulgowy</option>
                    </select>
                    <select name="sortuj" class="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                        <option value="najnowsze" {{ request('sortuj', 'najnowsze') === 'najnowsze' ? 'selected' : '' }}>Najblizszy mecz</option>
                        <option value="najstarsze" {{ request('sortuj') === 'najstarsze' ? 'selected' : '' }}>Najdalszy mecz</option>
                        <option value="typ" {{ request('sortuj') === 'typ' ? 'selected' : '' }}>Typ biletu</option>
                        <option value="trybuna" {{ request('sortuj') === 'trybuna' ? 'selected' : '' }}>Trybuna</option>
                    </select>
                    <div class="flex gap-2">
                        <button type="submit" class="flex-1 bg-stalZielony text-white rounded-lg text-xs font-bold uppercase px-4 py-2">Filtruj</button>
                        <a href="{{ route('bilety.indeks') }}" class="flex-1 bg-gray-200 text-gray-700 rounded-lg text-xs font-bold uppercase px-4 py-2 text-center">Wyczyść</a>
                    </div>
                </form>

                @if($bilety->isEmpty())
                    <div class="p-8 text-center text-sm text-gray-500">Brak zarezerwowanych biletow.</div>
                @else
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-gray-50 text-gray-500 text-[10px] uppercase tracking-widest">
                                <tr>
                                    <th class="text-left p-4">Kod</th>
                                    <th class="text-left p-4">Mecz</th>
                                    <th class="text-left p-4">Trybuna</th>
                                    <th class="text-left p-4">Typ</th>
                                    @if(Auth::user()->rola === 'prezes')
                                        <th class="text-left p-4">Kibic</th>
                                        <th class="text-left p-4">PESEL</th>
                                    @endif
                                    <th class="text-right p-4">Akcje</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                @foreach($bilety as $bilet)
                                    <tr>
                                        <td class="p-4 font-mono font-black text-stalZielony">{{ $bilet->kod_biletu }}</td>
                                        <td class="p-4">
                                            <span class="font-bold">
                                                Stal Stalowa Wola - {{ $bilet->mecz->druzyna->nazwa ?? 'Nieznany rywal' }}
                                            </span>
                                            <span class="block text-xs text-gray-400">
                                                {{ optional($bilet->mecz)->data_meczu ? \Carbon\Carbon::parse($bilet->mecz->data_meczu)->format('d.m.Y H:i') : '' }}
                                            </span>
                                        </td>
                                        <td class="p-4">{{ $bilet->sektor }}</td>
                                        <td class="p-4 uppercase text-xs font-bold">{{ $bilet->typ_biletu }}</td>
                                        @if(Auth::user()->rola === 'prezes')
                                            <td class="p-4">{{ $bilet->imie_nazwisko_kibica }}</td>
                                            <td class="p-4 font-mono">{{ $bilet->pesel_kibica }}</td>
                                        @endif
                                        <td class="p-4 text-right">
                                            <div class="inline-flex gap-2">
                                                @if(Auth::user()->rola === 'prezes')
                                                    <a href="{{ route('bilety.edytuj', $bilet->id) }}" class="bg-yellow-500 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Edytuj</a>
                                                @endif
                                                <form action="{{ route('bilety.usun', $bilet->id) }}" method="POST" onsubmit="return confirm('Anulowac ten bilet?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="bg-red-600 text-white px-3 py-2 rounded-lg text-[10px] font-bold uppercase">Anuluj</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        @endauth
    </div>
</div>
@endsection

