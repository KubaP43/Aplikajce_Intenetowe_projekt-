@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen py-10">
    <div class="max-w-3xl mx-auto px-8">
        <div class="flex justify-between items-center border-b border-gray-200 pb-6 mb-8">
            <div>
                <h1 class="text-3xl font-extrabold text-stalCzarny uppercase tracking-wide">Edytuj Dane Meczu</h1>
                <p class="text-sm text-gray-500 mt-1">Zarzadzanie terminarzem - rola: Prezes</p>
            </div>
            <a href="{{ route('mecze.indeks') }}" class="inline-flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-4 py-2 rounded-lg text-xs uppercase tracking-wider transition">
                Anuluj
            </a>
        </div>

        @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-xs font-medium mb-6">
                <ul class="list-disc pl-5 space-y-1">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <form action="{{ route('mecze.aktualizuj', $mecz->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-6">
                    <label for="druzyna_id" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Zmien przeciwnika</label>
                    <select name="druzyna_id" id="druzyna_id" required class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                        @foreach($druzyny as $druzyna)
                            <option value="{{ $druzyna->id }}" {{ $mecz->druzyna_id == $druzyna->id ? 'selected' : '' }}>
                                {{ $druzyna->nazwa }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div>
                        <label for="data_meczu" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Data i godzina spotkania</label>
                        <input type="datetime-local" name="data_meczu" id="data_meczu" value="{{ \Carbon\Carbon::parse($mecz->data_meczu)->format('Y-m-d\TH:i') }}" min="{{ now()->format('Y-m-d\TH:i') }}" max="{{ now()->addYear()->format('Y-m-d\TH:i') }}" required class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                    </div>

                    <div>
                        <label for="czy_domowy" class="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">Miejsce rozgrywania</label>
                        <select name="czy_domowy" id="czy_domowy" required class="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-stalZielony font-medium text-gray-800">
                            <option value="1" {{ $mecz->czy_domowy ? 'selected' : '' }}>Mecz domowy</option>
                            <option value="0" {{ !$mecz->czy_domowy ? 'selected' : '' }}>Mecz wyjazdowy</option>
                        </select>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="bg-stalZielony hover:bg-green-700 text-white font-bold px-6 py-3 rounded-lg text-xs uppercase tracking-wider shadow transition">
                        Zapisz zmiany
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

