@extends('layouts.szkielet')

@section('tresc')
<div class="bg-gray-100 min-h-screen">

    <div class="relative min-h-[500px] bg-cover bg-center flex items-center py-12 md:py-0" style="background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url('{{ asset('images/stadionNoca.jpg') }}');">
        <div class="max-w-7xl mx-auto w-full px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div class="text-center lg:text-left">
                <h1 class="text-4xl md:text-5xl font-black text-white uppercase tracking-wider leading-tight">
                    Witaj na <span class="text-stalZielony">Stalówce!</span>
                </h1>
                <p class="text-gray-200 mt-4 text-sm md:text-base font-medium leading-relaxed max-w-xl mx-auto lg:mx-0">
                    Oficjalny system obsługi kibiców i zarządzania klubem Stal Stalowa Wola. Sprawdź najbliższe wydarzenia i wspieraj swoją drużynę.
                </p>
                <div class="mt-8">
                    <a href="{{ route('bilety.indeks') }}" class="inline-block bg-stalZielony hover:bg-green-700 text-white font-black px-8 py-3.5 rounded-lg text-xs uppercase tracking-widest shadow-lg transition duration-300 transform hover:-translate-y-0.5">
                        Kup bilet na mecz
                    </a>
                </div>
            </div>

            @if($najblizszyMecz)
                <div class="flex justify-center lg:justify-end">
                    <div class="bg-stalCzarny/95 border border-gray-800 backdrop-blur-sm rounded-xl p-6 w-full max-w-sm shadow-2xl">
                        <div class="flex justify-between items-center border-b border-gray-800 pb-3 mb-4">
                            <span class="text-[10px] font-black text-stalZielony uppercase tracking-widest">Najbliższy mecz</span>
                            <span class="text-[10px] font-bold text-gray-400 font-mono">
                                {{ \Carbon\Carbon::parse($najblizszyMecz->data_meczu)->format('d.m.Y - H:i') }}
                            </span>
                        </div>

                        <div class="py-4 flex flex-col items-center justify-center text-center">
                            @if($najblizszyMecz->czy_domowy)
                                <div class="text-sm font-black text-white uppercase tracking-wide">Stal Stalowa Wola</div>
                                <div class="text-[10px] font-bold text-stalZielony uppercase my-2 tracking-widest">vs</div>
                                <div class="text-sm font-black text-gray-300 uppercase tracking-wide">{{ $najblizszyMecz->druzyna->nazwa ?? 'Nieznany rywal' }}</div>
                            @else
                                <div class="text-sm font-black text-gray-300 uppercase tracking-wide">{{ $najblizszyMecz->druzyna->nazwa ?? 'Nieznany rywal' }}</div>
                                <div class="text-[10px] font-bold text-stalZielony uppercase my-2 tracking-widest">vs</div>
                                <div class="text-sm font-black text-white uppercase tracking-wide">Stal Stalowa Wola</div>
                            @endif
                        </div>

                        <div class="mt-4 pt-3 border-t border-gray-800 text-center">
                            <span class="text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded bg-gray-900 border border-gray-800 text-gray-400">
                                {{ $najblizszyMecz->czy_domowy ? 'Stadion: PCPN Stalowa Wola' : 'Mecz wyjazdowy' }}
                            </span>
                        </div>
                    </div>
                </div>
            @endif

        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-12">
            <div class="grid grid-cols-1 lg:grid-cols-[1fr_320px]">
                <div class="p-6 sm:p-8">
                    @guest
                        <p class="text-xs font-black text-stalZielony uppercase tracking-widest mb-2">Panel gościa</p>
                        <h2 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Zobacz klub przed logowaniem</h2>
                        <p class="text-sm text-gray-600 mt-3 leading-relaxed">
                            Jako gość możesz sprawdzić terminarz, tabelę ligową, kadrę i podstawowe informacje o klubie. Konto kibica jest potrzebne dopiero do rezerwacji biletu.
                        </p>
                        <div class="mt-5 flex flex-wrap gap-3">
                            <a href="{{ route('rejestracja') }}" class="bg-stalZielony text-white px-5 py-3 rounded-lg text-xs font-black uppercase">Załóż konto kibica</a>
                            <a href="{{ route('tabela.indeks') }}" class="bg-gray-100 text-gray-800 px-5 py-3 rounded-lg text-xs font-black uppercase">Sprawdź tabelę</a>
                        </div>
                    @else
                        @if(Auth::user()->rola === 'prezes')
                            <p class="text-xs font-black text-stalZielony uppercase tracking-widest mb-2">Panel prezesa</p>
                            <h2 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Szybkie zarządzanie klubem</h2>
                            <p class="text-sm text-gray-600 mt-3 leading-relaxed">
                                Masz dostęp do edycji terminarza, kadry oraz pełnej listy rezerwacji biletów z danymi kibiców.
                            </p>
                            <div class="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <a href="{{ route('mecze.dodaj') }}" class="bg-stalZielony text-white px-5 py-3 rounded-lg text-xs font-black uppercase text-center">Dodaj mecz</a>
                                <a href="{{ route('kadra.dodaj') }}" class="bg-stalCzarny text-white px-5 py-3 rounded-lg text-xs font-black uppercase text-center">Dodaj do kadry</a>
                                <a href="{{ route('bilety.indeks') }}" class="bg-gray-100 text-gray-800 px-5 py-3 rounded-lg text-xs font-black uppercase text-center">Bilety</a>
                            </div>
                        @else
                            <p class="text-xs font-black text-stalZielony uppercase tracking-widest mb-2">Panel kibica</p>
                            <h2 class="text-2xl font-black text-stalCzarny uppercase tracking-wide">Witaj, {{ Auth::user()->imie }}</h2>
                            <p class="text-sm text-gray-600 mt-3 leading-relaxed">
                                Możesz rezerwować bilety, sprawdzać swoje kody oraz śledzić terminarz i tabelę ligową.
                            </p>
                            <div class="mt-5 flex flex-wrap gap-3">
                                <a href="{{ route('bilety.stworz') }}" class="bg-stalZielony text-white px-5 py-3 rounded-lg text-xs font-black uppercase">Kup bilet</a>
                                <a href="{{ route('bilety.indeks') }}" class="bg-gray-100 text-gray-800 px-5 py-3 rounded-lg text-xs font-black uppercase">Moje bilety</a>
                            </div>
                        @endif
                    @endguest
                </div>
                <div class="min-h-[220px] bg-cover bg-center" style="background-image: url('{{ asset('images/mecz2.jpg') }}');"></div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
            <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-6 border-b border-gray-100">
                    <h2 class="text-xs font-black text-gray-400 uppercase tracking-widest">Dane z bazy: najbliższe mecze</h2>
                </div>
                <div class="divide-y divide-gray-100">
                    @forelse($najblizszeMecze as $mecz)
                        <div class="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div>
                                <p class="text-sm font-black text-stalCzarny uppercase tracking-wide">
                                    @if($mecz->czy_domowy)
                                        Stal Stalowa Wola - {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }}
                                    @else
                                        {{ $mecz->druzyna->nazwa ?? 'Nieznany rywal' }} - Stal Stalowa Wola
                                    @endif
                                </p>
                                <p class="text-xs text-gray-500 mt-1">{{ $mecz->miejsce }}</p>
                            </div>
                            <span class="font-mono text-xs font-black text-gray-600 bg-gray-100 rounded-lg px-3 py-2">
                                {{ \Carbon\Carbon::parse($mecz->data_meczu)->format('d.m.Y H:i') }}
                            </span>
                        </div>
                    @empty
                        <div class="p-6 text-sm text-gray-500">Brak zaplanowanych meczów w bazie.</div>
                    @endforelse
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-6 border-b border-gray-100">
                    <h2 class="text-xs font-black text-gray-400 uppercase tracking-widest">Dane z bazy: czołówka tabeli</h2>
                </div>
                <div class="divide-y divide-gray-100">
                    @forelse($czolowkaTabeli as $druzyna)
                        <div class="p-5 flex items-center justify-between gap-4">
                            <div>
                                <p class="text-sm font-black text-stalCzarny uppercase">{{ $loop->iteration }}. {{ $druzyna->nazwa }}</p>
                                <p class="text-xs text-gray-500">{{ $druzyna->bramki_zdobyte }}:{{ $druzyna->bramki_stracone }} w bramkach</p>
                            </div>
                            <span class="bg-stalZielony text-white font-black rounded-lg px-3 py-1">{{ $druzyna->punkty }}</span>
                        </div>
                    @empty
                        <div class="p-6 text-sm text-gray-500">Brak danych tabeli w bazie.</div>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div class="bg-white p-8 rounded-xl shadow-sm border border-gray-200 flex flex-col justify-between hover:border-stalZielony transition duration-300">
                <div>
                    <h3 class="text-sm font-black text-stalCzarny uppercase tracking-wider border-b border-gray-100 pb-3 mb-4">
                        Nowoczesny Stadion
                    </h3>
                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed font-medium">
                        Podkarpackie Centrum Piłki Nożnej to duma naszego regionu. Posiada zadaszone trybuny, podgrzewaną murawę oraz pełne zaplecze treningowe spełniające najwyższe standardy ligowe.
                    </p>
                </div>
            </div>

            <div class="bg-white p-8 rounded-xl shadow-sm border border-gray-200 flex flex-col justify-between hover:border-stalZielony transition duration-300">
                <div>
                    <h3 class="text-sm font-black text-stalCzarny uppercase tracking-wider border-b border-gray-100 pb-3 mb-4">
                        Tradycja od 1938 roku
                    </h3>
                    <p class="text-gray-600 text-xs md:text-sm leading-relaxed font-medium">
                        Nasz klub powstał przed II Wojną Światową jako duma Hutniczego Grodu. Zielono-czarne barwy to symbol śląskiej i podkarpackiej tożsamości, pasji oraz niezłomnego charakteru.
                    </p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-16">
            <div class="p-8 border-b border-gray-100">
                <h2 class="text-xs font-black text-gray-400 uppercase tracking-widest">Galeria z życia klubu</h2>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-1 p-1 bg-gray-100">
                <div class="h-64 overflow-hidden relative group">
                    <img src="{{ asset('images/mecz.jpg') }}" alt="Mecz Stali" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-500">
                </div>
                <div class="h-64 overflow-hidden relative group">
                    <img src="{{ asset('images/mecz2.jpg') }}" alt="Rozgrywki" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-500">
                </div>
                <div class="h-64 overflow-hidden relative group">
                    <img src="{{ asset('images/flagi.jpg') }}" alt="Kibice i Flagi" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-500">
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
            
            <div class="lg:col-span-2 bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center flex flex-col justify-between">
                <div>
                    <h2 class="text-xl font-black text-stalCzarny uppercase tracking-widest">Hymn Stali Stalowa Wola</h2>
                    <p class="text-xs text-gray-400 mt-2 mb-6 uppercase tracking-wider">
                        Posłuchaj oficjalnego utworu Hutniczego Grodu i poczuj klimat panujący na trybunach
                    </p>
                </div>
                
                <div class="w-full rounded-xl overflow-hidden shadow-md border border-gray-200 bg-black">
                    <iframe src="https://www.youtube.com/embed/OCMpYFQXK0U?si=zqQmbJ4TEso5iXQP" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen class="w-full h-[360px]"></iframe>
                </div>
            </div>

            <div class="lg:col-span-1 flex flex-col gap-6 justify-between">
                
                <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:border-stalZielony transition duration-300 text-center flex flex-col justify-center items-center flex-1">
                    <h3 class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 border-b border-gray-100 pb-1.5 w-full">
                        Wspieraj Akademię
                    </h3>
                    <img src="{{ asset('images/przekaz_1Procent.png') }}" alt="Przekaż 1.5% podatku" class="max-h-[150px] w-auto rounded-lg shadow-sm object-contain"
                         onerror="this.onerror=null; this.src='{{ asset('images/przekaz_1Procent.png') }}';">
                </div>

                <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:border-stalZielony transition duration-300 flex flex-col justify-between flex-1">
                    <h3 class="text-[10px] font-black text-gray-400 text-center uppercase tracking-widest border-b border-gray-100 pb-1.5 w-full">
                        Strategiczny Partner Finansowy
                    </h3>
                    
                    <div class="flex flex-row items-center gap-5 py-2 h-full">
                        <div class="w-24 flex-shrink-0 text-center">
                            <img src="{{ asset('images/Herb_Stalowej_Woli.png') }}" alt="Miasto Stalowa Wola" class="w-full h-auto max-h-[110px] object-contain mx-auto">
                            <span class="text-[9px] font-black uppercase text-gray-700 block mt-1.5 leading-none tracking-wide">Stalowa Wola</span>
                        </div>
                        
                        <div class="flex-1">
                            <p class="text-[9px] font-medium text-gray-500 leading-relaxed text-justify">
                                Stal Stalowa Wola P.S.A. na podstawie umowy nr PKS-524.18.2024.RR zawartej z Gminą Stalowa Wola realizuje zadanie publiczne z zakresu sportu pod tytułem "Organizacja lub udział w zgrupowaniach sportowych przygotowujących do rozgrywek ligowych, organizacja i udział w zawodach lub rozgrywkach sportowych - sport seniorów".
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>
@endsection

