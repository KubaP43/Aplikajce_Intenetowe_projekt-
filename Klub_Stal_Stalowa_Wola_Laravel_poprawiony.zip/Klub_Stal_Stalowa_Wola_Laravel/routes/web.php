<?php

use App\Http\Controllers\BiletController;
use App\Http\Controllers\KibicController;
use App\Http\Controllers\MeczController;
use App\Http\Controllers\PilkarzController;
use App\Http\Controllers\StronaController;
use App\Http\Controllers\TabelaController;
use Illuminate\Support\Facades\Route;

Route::pattern('id', '[0-9]+');

// Strony publiczne
Route::get('/', [StronaController::class, 'glowna'])->name('strona.glowna');
Route::get('/historia', [StronaController::class, 'historia'])->name('strona.historia');
Route::get('/kontakt', [StronaController::class, 'kontakt'])->name('strona.kontakt');

Route::get('/mecze', [MeczController::class, 'indeks'])->name('mecze.indeks');
Route::get('/tabela', [TabelaController::class, 'indeks'])->name('tabela.indeks');
Route::get('/kadra', [PilkarzController::class, 'indeks'])->name('kadra.indeks');
Route::get('/bilety', [BiletController::class, 'indeks'])->name('bilety.indeks');

// Logowanie i rejestracja
Route::get('/logowanie', [StronaController::class, 'logowanie'])->name('logowanie');
Route::post('/logowanie', [KibicController::class, 'zaloguj'])->name('zaloguj');
Route::get('/rejestracja', [StronaController::class, 'rejestracja'])->name('rejestracja');
Route::post('/kibice', [KibicController::class, 'zapisz'])->name('kibice.zapisz');
Route::post('/wyloguj', [KibicController::class, 'wyloguj'])->middleware('auth')->name('wyloguj');

// Operacje zalogowanego kibica
Route::middleware('auth')->group(function () {
    Route::get('/bilety/stworz', [BiletController::class, 'stworz'])->name('bilety.stworz');
    Route::post('/bilety', [BiletController::class, 'zapisz'])->name('bilety.zapisz');
    Route::delete('/bilety/{id}', [BiletController::class, 'usun'])->name('bilety.usun');
});

// Panel prezesa
Route::middleware(['auth', 'prezes'])->group(function () {
    Route::get('/bilety/{id}/edytuj', [BiletController::class, 'edytuj'])->name('bilety.edytuj');
    Route::put('/bilety/{id}', [BiletController::class, 'aktualizuj'])->name('bilety.aktualizuj');

    Route::get('/kadra/dodaj', [PilkarzController::class, 'dodaj'])->name('kadra.dodaj');
    Route::post('/kadra/zapisz', [PilkarzController::class, 'zapisz'])->name('kadra.zapisz');
    Route::get('/kadra/{id}/edytuj', [PilkarzController::class, 'edytuj'])->name('kadra.edytuj');
    Route::put('/kadra/{id}/aktualizuj', [PilkarzController::class, 'aktualizuj'])->name('kadra.aktualizuj');
    Route::delete('/kadra/{id}/usun', [PilkarzController::class, 'usun'])->name('kadra.usun');

    Route::get('/mecze/dodaj', [MeczController::class, 'dodaj'])->name('mecze.dodaj');
    Route::post('/mecze/zapisz', [MeczController::class, 'zapisz'])->name('mecze.zapisz');
    Route::get('/mecze/{id}/edytuj', [MeczController::class, 'edytuj'])->name('mecze.edytuj');
    Route::put('/mecze/{id}/aktualizuj', [MeczController::class, 'aktualizuj'])->name('mecze.aktualizuj');
    Route::delete('/mecze/{id}/usun', [MeczController::class, 'usun'])->name('mecze.usun');

    Route::get('/tabela/dodaj', [TabelaController::class, 'dodaj'])->name('tabela.dodaj');
    Route::post('/tabela/zapisz', [TabelaController::class, 'zapisz'])->name('tabela.zapisz');
    Route::get('/tabela/{id}/edytuj', [TabelaController::class, 'edytuj'])->name('tabela.edytuj');
    Route::put('/tabela/{id}/aktualizuj', [TabelaController::class, 'aktualizuj'])->name('tabela.aktualizuj');
    Route::delete('/tabela/{id}/usun', [TabelaController::class, 'usun'])->name('tabela.usun');
});

