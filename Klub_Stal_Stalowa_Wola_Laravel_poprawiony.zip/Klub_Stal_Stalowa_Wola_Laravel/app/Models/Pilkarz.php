<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Pilkarz extends Model
{
    protected $table = 'pilkarze';

    protected $fillable = [
        'imie',
        'nazwisko',
        'pozycja',
        'numer',
        'zdjecie',
        'wiek',
        'od_kiedy_w_klubie',
        'rozegrane_mecze',
    ];

    public function statystyki(): HasOne
    {
        return $this->hasOne(StatystykiPilkarza::class, 'pilkarz_id');
    }
}
