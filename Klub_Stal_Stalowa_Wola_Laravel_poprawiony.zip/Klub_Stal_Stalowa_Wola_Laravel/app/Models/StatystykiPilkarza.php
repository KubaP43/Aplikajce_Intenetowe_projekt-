<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StatystykiPilkarza extends Model
{
    protected $table = 'statystyki_pilkarzy';

    protected $fillable = [
        'pilkarz_id',
        'wystepy',
        'minuty',
        'gole',
        'asysty',
        'czyste_konta',
        'zolte_kartki',
        'czerwone_kartki',
    ];

    public function pilkarz(): BelongsTo
    {
        return $this->belongsTo(Pilkarz::class, 'pilkarz_id');
    }
}
