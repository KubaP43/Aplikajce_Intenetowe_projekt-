<?php

namespace App\Http\Controllers;

use App\Models\Druzyna;
use App\Models\Mecz;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class StronaController extends Controller
{
    public function glowna()
    {
        $najblizszyMecz = Mecz::with('druzyna')
            ->where('data_meczu', '>=', Carbon::now())
            ->orderBy('data_meczu', 'asc')
            ->first();

        $najblizszeMecze = Mecz::with('druzyna')
            ->where('data_meczu', '>=', Carbon::now())
            ->orderBy('data_meczu', 'asc')
            ->limit(3)
            ->get();

        $czolowkaTabeli = $this->posortowaneDruzyny()->take(3)->values();

        return view('strona_glowna', compact('najblizszyMecz', 'najblizszeMecze', 'czolowkaTabeli'));
    }

    public function historia()
    {
        return view('historia');
    }

    public function kontakt()
    {
        return view('kontakt');
    }

    public function logowanie()
    {
        if (Auth::check()) {
            return redirect()->route('strona.glowna');
        }

        return response()
            ->view('auth.logowanie')
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    public function rejestracja()
    {
        if (Auth::check()) {
            return redirect()->route('strona.glowna');
        }

        return response()
            ->view('auth.rejestracja')
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    private function posortowaneDruzyny()
    {
        return Druzyna::all()->sort(function (Druzyna $pierwsza, Druzyna $druga): int {
            $porownanie = $druga->punkty <=> $pierwsza->punkty;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            $bilansPierwszej = $pierwsza->bramki_zdobyte - $pierwsza->bramki_stracone;
            $bilansDrugiej = $druga->bramki_zdobyte - $druga->bramki_stracone;
            $porownanie = $bilansDrugiej <=> $bilansPierwszej;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            $porownanie = $druga->bramki_zdobyte <=> $pierwsza->bramki_zdobyte;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            return strnatcasecmp($pierwsza->nazwa, $druga->nazwa);
        });
    }
}
