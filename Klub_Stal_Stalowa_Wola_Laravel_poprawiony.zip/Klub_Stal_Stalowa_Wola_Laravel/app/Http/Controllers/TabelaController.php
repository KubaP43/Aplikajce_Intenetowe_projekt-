<?php

namespace App\Http\Controllers;

use App\Models\Druzyna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class TabelaController extends Controller
{
    public function indeks()
    {
        $druzyny = $this->posortowaneDruzyny()->take(18)->values();

        return view('tabela.indeks', compact('druzyny'));
    }

    public function dodaj()
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        return view('tabela.dodaj');
    }

    public function zapisz(Request $request)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        Druzyna::create($this->walidujDruzyne($request));

        return redirect()->route('tabela.indeks')->with('sukces', 'Drużyna została dodana do tabeli.');
    }

    public function edytuj($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);

        return view('tabela.edytuj', compact('druzyna'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);
        $druzyna->update($this->walidujDruzyne($request, $druzyna->id));

        return redirect()->route('tabela.indeks')->with('sukces', 'Dane drużyny zostały zaktualizowane.');
    }

    public function usun($id)
    {
        if (!$this->czyPrezes()) {
            return redirect()->route('tabela.indeks')->withErrors(['access' => 'Brak uprawnień.']);
        }

        $druzyna = Druzyna::findOrFail($id);

        if ($druzyna->mecze()->exists()) {
            return redirect()->route('tabela.indeks')
                ->withErrors(['druzyna' => 'Nie można usunąć drużyny, która ma przypisane mecze w terminarzu.']);
        }

        $druzyna->delete();

        return redirect()->route('tabela.indeks')->with('sukces', 'Drużyna została usunięta.');
    }

    private function walidujDruzyne(Request $request, ?int $ignorujId = null): array
    {
        return $request->validate([
            'nazwa' => [
                'required',
                'string',
                'min:3',
                'max:100',
                'regex:/^[\pL0-9\s\.\-]+$/u',
                'not_regex:/^[0-9\s]+$/',
                Rule::unique('druzyny', 'nazwa')->ignore($ignorujId),
            ],
            'punkty' => ['required', 'integer', 'min:0', 'max:150'],
            'mecze_rozegrane' => ['required', 'integer', 'min:0', 'max:80'],
            'bramki_zdobyte' => ['required', 'integer', 'min:0', 'max:300'],
            'bramki_stracone' => ['required', 'integer', 'min:0', 'max:300'],
        ], [
            'nazwa.required' => 'Podaj nazwę drużyny.',
            'nazwa.min' => 'Nazwa drużyny musi mieć co najmniej 3 znaki.',
            'nazwa.regex' => 'Nazwa drużyny może zawierać litery, cyfry, spacje, kropki i myślniki.',
            'nazwa.not_regex' => 'Nazwa drużyny nie może składać się wyłącznie z cyfr.',
            'nazwa.unique' => 'Taka drużyna już istnieje w bazie.',
            'punkty.integer' => 'Punkty muszą być liczbą całkowitą.',
            'mecze_rozegrane.integer' => 'Liczba meczów musi być liczbą całkowitą.',
            'bramki_zdobyte.integer' => 'Bramki zdobyte muszą być liczbą całkowitą.',
            'bramki_stracone.integer' => 'Bramki stracone muszą być liczbą całkowitą.',
        ]);
    }

    private function posortowaneDruzyny()
    {
        return Druzyna::all()->sort(function (Druzyna $pierwsza, Druzyna $druga): int {
            $porownanie = $druga->punkty <=> $pierwsza->punkty;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            $bilansPierwszej = $pierwsza->bramki_zdobyte - $pierwsza->bramki_stracone;
            $bilansDrugiej = $druga->bramki_zdobyte - $druga->bramki_stracone;
            $porownanie = $bilansDrugiej <=> $bilansPierwszej;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            $porownanie = $druga->bramki_zdobyte <=> $pierwsza->bramki_zdobyte;

            if ($porownanie !== 0) {
                return $porownanie;
            }

            return strnatcasecmp($pierwsza->nazwa, $druga->nazwa);
        });
    }

    private function czyPrezes(): bool
    {
        return Auth::check() && Auth::user()->rola === 'prezes';
    }
}
