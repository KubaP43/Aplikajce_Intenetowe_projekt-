<?php

namespace App\Http\Controllers;

use App\Models\Bilet;
use App\Models\Mecz;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class BiletController extends Controller
{
    private const SEKTORY = ['Trybuna Glowna', 'Sektor A - Mlyn', 'Sektor B - Rodzinny'];
    private const TYPY_BILETOW = ['normalny', 'ulgowy'];
    private const SORTOWANIE = ['najnowsze', 'najstarsze', 'typ', 'trybuna'];

    public function indeks(Request $request)
    {
        $validated = $request->validate([
            'sektor' => ['nullable', Rule::in(self::SEKTORY)],
            'typ_biletu' => ['nullable', Rule::in(self::TYPY_BILETOW)],
            'sortuj' => ['nullable', Rule::in(self::SORTOWANIE)],
        ]);

        $bilety = collect();

        if (Auth::check()) {
            $zapytanie = Bilet::with(['mecz.druzyna', 'uzytkownik']);

            if (Auth::user()->rola !== 'prezes') {
                $zapytanie->where('uzytkownik_id', Auth::id());
            }

            if (!empty($validated['sektor'])) {
                $zapytanie->where('sektor', $validated['sektor']);
            }

            if (!empty($validated['typ_biletu'])) {
                $zapytanie->where('typ_biletu', $validated['typ_biletu']);
            }

            $sortuj = $validated['sortuj'] ?? 'najnowsze';
            $bilety = $zapytanie->get();

            $bilety = (match ($sortuj) {
                'najstarsze' => $bilety->sortByDesc(fn (Bilet $bilet) => $this->dataMeczuDoSortowania($bilet)),
                'typ' => $bilety->sort(fn (Bilet $pierwszy, Bilet $drugi) => [
                    $pierwszy->typ_biletu,
                    $this->dataMeczuDoSortowania($pierwszy),
                ] <=> [
                    $drugi->typ_biletu,
                    $this->dataMeczuDoSortowania($drugi),
                ]),
                'trybuna' => $bilety->sort(fn (Bilet $pierwszy, Bilet $drugi) => [
                    $pierwszy->sektor,
                    $this->dataMeczuDoSortowania($pierwszy),
                ] <=> [
                    $drugi->sektor,
                    $this->dataMeczuDoSortowania($drugi),
                ]),
                default => $bilety->sortBy(fn (Bilet $bilet) => $this->dataMeczuDoSortowania($bilet)),
            })->values();
        }

        return view('bilety.indeks', compact('bilety'));
    }

    public function stworz()
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $mecze = Mecz::with('druzyna')
            ->where('czy_domowy', true)
            ->where('data_meczu', '>=', now())
            ->orderBy('data_meczu', 'asc')
            ->get();

        return view('bilety.stworz', compact('mecze'));
    }

    public function zapisz(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $validated = $this->walidujBilet($request);
        $uzytkownik = Auth::user();

        if ($this->uzytkownikMaBiletNaMecz($uzytkownik->id, (int) $validated['mecz_id'])) {
            throw ValidationException::withMessages([
                'mecz_id' => 'Masz już bilet na ten mecz. Jeden kibic może zarezerwować maksymalnie jeden bilet na jedno spotkanie.',
            ]);
        }

        Bilet::create([
            'uzytkownik_id' => $uzytkownik->id,
            'kod_biletu' => $this->wygenerujKodBiletu(),
            'mecz_id' => $validated['mecz_id'],
            'sektor' => $validated['sektor'],
            'rzad' => random_int(1, 20),
            'miejsce' => random_int(1, 120),
            'typ_biletu' => $validated['typ_biletu'],
            'znizka' => $validated['typ_biletu'] === 'ulgowy' ? 20 : 0,
            'imie_nazwisko_kibica' => trim($uzytkownik->imie . ' ' . $uzytkownik->nazwisko),
            'pesel_kibica' => $uzytkownik->pesel,
        ]);

        return redirect()->route('bilety.indeks')->with('sukces', 'Bilet zostal zarezerwowany i zapisany w bazie.');
    }

    public function edytuj($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Tylko prezes moze edytowac bilety.']);
        }

        $bilet = Bilet::with('mecz.druzyna')->findOrFail($id);
        $mecze = Mecz::with('druzyna')
            ->where('czy_domowy', true)
            ->where(function ($query) use ($bilet) {
                $query->where('data_meczu', '>=', now())
                    ->orWhere('id', $bilet->mecz_id);
            })
            ->orderBy('data_meczu')
            ->get();

        return view('bilety.edytuj', compact('bilet', 'mecze'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Tylko prezes moze edytowac bilety.']);
        }

        $bilet = Bilet::findOrFail($id);
        $validated = $this->walidujBilet($request);

        if ($this->uzytkownikMaBiletNaMecz($bilet->uzytkownik_id, (int) $validated['mecz_id'], $bilet->id)) {
            throw ValidationException::withMessages([
                'mecz_id' => 'Ten kibic ma już bilet na wybrany mecz.',
            ]);
        }

        $bilet->update([
            'mecz_id' => $validated['mecz_id'],
            'sektor' => $validated['sektor'],
            'typ_biletu' => $validated['typ_biletu'],
            'znizka' => $validated['typ_biletu'] === 'ulgowy' ? 20 : 0,
        ]);

        return redirect()->route('bilety.indeks')->with('sukces', 'Dane biletu zostaly zaktualizowane.');
    }

    public function usun($id)
    {
        if (!Auth::check()) {
            return redirect()->route('bilety.indeks')->with('wymagane_logowanie', true);
        }

        $bilet = Bilet::findOrFail($id);

        if (Auth::user()->rola !== 'prezes' && $bilet->uzytkownik_id !== Auth::id()) {
            return redirect()->route('bilety.indeks')->withErrors(['access' => 'Mozesz anulowac tylko swoj bilet.']);
        }

        $bilet->delete();

        return redirect()->route('bilety.indeks')->with('sukces', 'Bilet zostal anulowany.');
    }

    private function dataMeczuDoSortowania(Bilet $bilet): string
    {
        return optional($bilet->mecz)->data_meczu ?? '9999-12-31 23:59:59';
    }

    private function walidujBilet(Request $request, bool $tylkoPrzyszleMecze = true): array
    {
        $validated = $request->validate([
            'mecz_id' => ['required', 'integer', 'exists:mecze,id'],
            'sektor' => ['required', Rule::in(self::SEKTORY)],
            'typ_biletu' => ['required', Rule::in(self::TYPY_BILETOW)],
        ], [
            'mecz_id.required' => 'Wybierz mecz.',
            'mecz_id.exists' => 'Wybrany mecz nie istnieje w bazie.',
            'sektor.required' => 'Wybierz trybune.',
            'sektor.in' => 'Wybierz trybune z listy.',
            'typ_biletu.required' => 'Wybierz typ biletu.',
            'typ_biletu.in' => 'Wybierz poprawny typ biletu.',
        ]);

        $meczQuery = Mecz::whereKey($validated['mecz_id'])
            ->where('czy_domowy', true);

        if ($tylkoPrzyszleMecze) {
            $meczQuery->where('data_meczu', '>=', now());
        }

        if (!$meczQuery->exists()) {
            $komunikat = $tylkoPrzyszleMecze
                ? 'Bilet można zarezerwować tylko na przyszły mecz domowy.'
                : 'Bilet może być przypisany tylko do meczu domowego.';

            throw ValidationException::withMessages([
                'mecz_id' => $komunikat,
            ]);
        }

        return $validated;
    }

    private function uzytkownikMaBiletNaMecz(int $uzytkownikId, int $meczId, ?int $ignorujBiletId = null): bool
    {
        $query = Bilet::where('uzytkownik_id', $uzytkownikId)
            ->where('mecz_id', $meczId);

        if ($ignorujBiletId !== null) {
            $query->where('id', '!=', $ignorujBiletId);
        }

        return $query->exists();
    }

    private function wygenerujKodBiletu(): string
    {
        do {
            $kod = 'STAL-' . random_int(1000, 9999) . '-' . Str::upper(Str::random(3));
        } while (Bilet::where('kod_biletu', $kod)->exists());

        return $kod;
    }
}




