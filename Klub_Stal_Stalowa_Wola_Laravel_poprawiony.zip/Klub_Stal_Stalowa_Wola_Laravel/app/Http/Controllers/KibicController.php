<?php

namespace App\Http\Controllers;

use App\Models\Uzytkownik;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class KibicController extends Controller
{
    public function stworz()
    {
        return view('auth.rejestracja');
    }

    public function zapisz(Request $request)
    {
        $validated = $request->validate([
            'imie' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\-]+$/u'],
            'nazwisko' => ['required', 'string', 'max:50', 'regex:/^[\pL\s\-]+$/u'],
            'pesel' => [
                'required',
                'digits:11',
                'unique:uzytkownicy,pesel',
                function (string $attribute, mixed $value, \Closure $fail): void {
                    if (!$this->peselMaPoprawnaSumeKontrolna((string) $value)) {
                        $fail('Podaj poprawny numer PESEL.');
                    }
                },
            ],
            'data_urodzenia' => ['required', 'date', 'before:today'],
            'email' => ['required', 'string', 'email:rfc,dns', 'max:255', 'unique:uzytkownicy,email'],
            'password' => ['required', Password::min(8)->letters()->mixedCase()->numbers()->symbols()],
        ], [
            'imie.required' => 'Pole Imię jest wymagane.',
            'imie.regex' => 'Imię może zawierać tylko litery, spacje i myślnik.',
            'nazwisko.required' => 'Pole Nazwisko jest wymagane.',
            'nazwisko.regex' => 'Nazwisko może zawierać tylko litery, spacje i myślnik.',
            'pesel.required' => 'Musisz podać numer PESEL.',
            'pesel.digits' => 'Numer PESEL musi składać się z dokładnie 11 cyfr.',
            'pesel.unique' => 'Konto z tym numerem PESEL już istnieje.',
            'data_urodzenia.required' => 'Data urodzenia jest wymagana.',
            'data_urodzenia.before' => 'Data urodzenia musi być datą z przeszłości.',
            'email.required' => 'Adres e-mail jest wymagany.',
            'email.email' => 'Podaj poprawny format adresu e-mail.',
            'email.unique' => 'Ten adres e-mail jest już zajęty.',
            'password.required' => 'Musisz podać hasło.',
            'password' => 'Hasło musi mieć min. 8 znaków, duże i małe litery, cyfrę oraz znak specjalny.',
        ]);

        Uzytkownik::create([
            'imie' => $validated['imie'],
            'nazwisko' => $validated['nazwisko'],
            'pesel' => $validated['pesel'],
            'data_urodzenia' => $validated['data_urodzenia'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
        ]);

        return redirect()->route('logowanie')->with('sukces', 'Zarejestrowano poprawnie! Zaloguj się swoimi danymi.');
    }

    public function zaloguj(Request $request)
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'Podaj adres e-mail.',
            'email.email' => 'Podaj poprawny adres e-mail.',
            'password.required' => 'Podaj hasło.',
        ]);

        $uzytkownik = Uzytkownik::where('email', $validated['email'])->first();

        if ($uzytkownik && Hash::check($validated['password'], $uzytkownik->password)) {
            Auth::login($uzytkownik);
            $request->session()->regenerate();

            return redirect()->route('strona.glowna')->with('sukces', 'Zalogowano pomyślnie do systemu!');
        }

        return back()->withErrors(['email' => 'Błędny adres e-mail lub hasło.'])->withInput();
    }

    public function wyloguj(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('strona.glowna')->with('sukces', 'Wylogowano pomyślnie z systemu.');
    }

    private function peselMaPoprawnaSumeKontrolna(string $pesel): bool
    {
        if (!preg_match('/^[0-9]{11}$/', $pesel)) {
            return false;
        }

        $wagi = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3];
        $suma = 0;

        for ($i = 0; $i < 10; $i++) {
            $suma += ((int) $pesel[$i]) * $wagi[$i];
        }

        $cyfraKontrolna = (10 - ($suma % 10)) % 10;

        return $cyfraKontrolna === (int) $pesel[10];
    }
}
