<?php

namespace App\Http\Controllers;

class KadraController extends PilkarzController
{
    // Starsza nazwa kontrolera zostaje tylko jako zgodność z wcześniejszą wersją projektu.
    // Cała aktualna logika kadry i walidacja są w PilkarzController.
}
