<?php

namespace App\Http\Controllers;

use App\Models\Druzyna;
use App\Models\Mecz;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class MeczController extends Controller
{
    private const NAZWA_STALI = 'Stal Stalowa Wola';

    public function indeks()
    {
        $mecze = Mecz::with('druzyna')->orderBy('data_meczu', 'asc')->get();

        return view('mecze.indeks', compact('mecze'));
    }

    public function dodaj()
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $druzyny = $this->druzynyDoWyboru();

        return view('mecze.dodaj', compact('druzyny'));
    }

    public function zapisz(Request $request)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $validated = $this->walidujMecz($request);

        Mecz::create([
            'druzyna_id' => $validated['druzyna_id'],
            'data_meczu' => $validated['data_meczu'],
            'czy_domowy' => (bool) $validated['czy_domowy'],
            'miejsce' => $validated['czy_domowy'] ? 'PCPN Stalowa Wola' : 'Stadion wyjazdowy',
            'status' => 'Planowany',
        ]);

        return redirect()->route('mecze.indeks')->with('sukces', 'Mecz zostal dodany do terminarza.');
    }

    public function edytuj($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $mecz = Mecz::findOrFail($id);
        $druzyny = $this->druzynyDoWyboru();

        return view('mecze.edytuj', compact('mecz', 'druzyny'));
    }

    public function aktualizuj(Request $request, $id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        $validated = $this->walidujMecz($request, (int) $id);
        $mecz = Mecz::findOrFail($id);

        $mecz->update([
            'druzyna_id' => $validated['druzyna_id'],
            'data_meczu' => $validated['data_meczu'],
            'czy_domowy' => (bool) $validated['czy_domowy'],
            'miejsce' => $validated['czy_domowy'] ? 'PCPN Stalowa Wola' : 'Stadion wyjazdowy',
        ]);

        return redirect()->route('mecze.indeks')->with('sukces', 'Dane meczu zostaly zaktualizowane.');
    }

    public function usun($id)
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()->route('mecze.indeks')->withErrors(['access' => 'Brak uprawnien.']);
        }

        Mecz::findOrFail($id)->delete();

        return redirect()->route('mecze.indeks')->with('sukces', 'Mecz zostal usuniety.');
    }

    private function walidujMecz(Request $request, ?int $ignorujMeczId = null): array
    {
        $validated = $request->validate([
            'druzyna_id' => ['required', 'integer', 'exists:druzyny,id'],
            'data_meczu' => ['required', 'date'],
            'czy_domowy' => ['required', 'boolean'],
        ], [
            'druzyna_id.required' => 'Musisz wybrac druzyne przeciwnika z listy.',
            'druzyna_id.exists' => 'Wybrana druzyna nie istnieje w bazie danych.',
            'data_meczu.required' => 'Wskaz date oraz godzine rozgrywania meczu.',
            'data_meczu.date' => 'Wprowadzona wartosc musi byc poprawna data.',
            'czy_domowy.required' => 'Wybierz miejsce spotkania.',
            'czy_domowy.boolean' => 'Wybierz poprawne miejsce spotkania.',
        ]);

        $druzynaDozwolona = Druzyna::whereKey($validated['druzyna_id'])
            ->where('nazwa', '!=', self::NAZWA_STALI)
            ->exists();

        if (!$druzynaDozwolona) {
            throw ValidationException::withMessages([
                'druzyna_id' => 'Jako przeciwnika trzeba wybrać inną drużynę niż Stal Stalowa Wola.',
            ]);
        }

        $dataMeczu = Carbon::parse($validated['data_meczu']);
        $najwczesniejszaData = Carbon::now();
        $najpozniejszaData = Carbon::now()->addYear();

        if ($dataMeczu->lt($najwczesniejszaData) || $dataMeczu->gt($najpozniejszaData)) {
            throw ValidationException::withMessages([
                'data_meczu' => 'Data meczu nie moze byc z przeszlosci ani pozniej niz rok do przodu.',
            ]);
        }

        $meczTegoSamegoDnia = Mecz::whereDate('data_meczu', $dataMeczu->toDateString());

        if ($ignorujMeczId !== null) {
            $meczTegoSamegoDnia->where('id', '!=', $ignorujMeczId);
        }

        if ($meczTegoSamegoDnia->exists()) {
            throw ValidationException::withMessages([
                'data_meczu' => 'Tego dnia Stal Stalowa Wola rozgrywa juz inne spotkanie.',
            ]);
        }

        return $validated;
    }

    private function druzynyDoWyboru()
    {
        return Druzyna::where('nazwa', '!=', self::NAZWA_STALI)
            ->orderBy('nazwa', 'asc')
            ->get();
    }
}

