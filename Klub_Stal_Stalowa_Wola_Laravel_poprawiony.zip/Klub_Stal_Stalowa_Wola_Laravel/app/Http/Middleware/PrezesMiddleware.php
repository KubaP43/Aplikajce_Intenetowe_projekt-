<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class PrezesMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check() || Auth::user()->rola !== 'prezes') {
            return redirect()
                ->route('strona.glowna')
                ->withErrors(['access' => 'Brak uprawnien do panelu prezesa.']);
        }

        return $next($request);
    }
}