<?php

namespace Database\Seeders;

use App\Models\Uzytkownik;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UzytkownikSeeder extends Seeder
{
    public function run(): void
    {
        $uzytkownicy = [
            [
                'imie' => 'Marek',
                'nazwisko' => 'Karabuła',
                'pesel' => '12345678900',
                'data_urodzenia' => '1980-01-01',
                'email' => 'prezes@stal.pl',
                'password' => '1938St@lowka',
                'rola' => 'prezes',
            ],
            [
                'imie' => 'Jan',
                'nazwisko' => 'Kowalski',
                'pesel' => '00210112340',
                'data_urodzenia' => '2000-01-01',
                'email' => 'test@test.pl',
                'password' => 'Test@123456',
                'rola' => 'kibic',
            ],
            [
                'imie' => 'Adam',
                'nazwisko' => 'Nowak',
                'pesel' => '01220356786',
                'data_urodzenia' => '2001-02-03',
                'email' => 'kibic@stal.pl',
                'password' => 'Stalow@123',
                'rola' => 'kibic',
            ],
        ];

        foreach ($uzytkownicy as $dane) {
            Uzytkownik::updateOrCreate(
                ['email' => $dane['email']],
                [
                    'imie' => $dane['imie'],
                    'nazwisko' => $dane['nazwisko'],
                    'pesel' => $dane['pesel'],
                    'data_urodzenia' => $dane['data_urodzenia'],
                    'password' => Hash::make($dane['password']),
                    'rola' => $dane['rola'],
                ]
            );
        }
    }
}
