<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Druzyna;

class DruzynySeeder extends Seeder
{
    public function run(): void
    {
        $druzyny = [
            ['nazwa' => 'Hutnik Kraków', 'punkty' => 11, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 11, 'bramki_stracone' => 3],
            ['nazwa' => 'GKS Tychy', 'punkty' => 11, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 9, 'bramki_stracone' => 4],
            ['nazwa' => 'Znicz Pruszków', 'punkty' => 10, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 8, 'bramki_stracone' => 4],
            ['nazwa' => 'Zawisza Bydgoszcz', 'punkty' => 10, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 8, 'bramki_stracone' => 6],
            ['nazwa' => 'Avia Świdnik', 'punkty' => 9, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 9, 'bramki_stracone' => 9],
            ['nazwa' => 'Sandecja Nowy Sącz', 'punkty' => 8, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 5, 'bramki_stracone' => 4],
            ['nazwa' => 'Olimpia Grudziądz', 'punkty' => 8, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 7, 'bramki_stracone' => 8],
            ['nazwa' => 'Górnik Łęczna', 'punkty' => 7, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 9, 'bramki_stracone' => 8],
            ['nazwa' => 'Rekord Bielsko-Biała', 'punkty' => 7, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 8, 'bramki_stracone' => 7],
            ['nazwa' => 'Legia II Warszawa', 'punkty' => 6, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 12, 'bramki_stracone' => 7],
            ['nazwa' => 'Lechia Zielona Góra', 'punkty' => 6, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 11, 'bramki_stracone' => 7],
            ['nazwa' => 'Stal Stalowa Wola', 'punkty' => 6, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 8, 'bramki_stracone' => 7],
            ['nazwa' => 'Śląsk II Wrocław', 'punkty' => 6, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 9, 'bramki_stracone' => 9],
            ['nazwa' => 'Chojniczanka Chojnice', 'punkty' => 6, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 5, 'bramki_stracone' => 9],
            ['nazwa' => 'Podhale Nowy Targ', 'punkty' => 5, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 8, 'bramki_stracone' => 12],
            ['nazwa' => 'Sokół Kleczew', 'punkty' => 5, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 6, 'bramki_stracone' => 13],
            ['nazwa' => 'Resovia', 'punkty' => 2, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 4, 'bramki_stracone' => 10],
            ['nazwa' => 'Świt Szczecin', 'punkty' => 1, 'mecze_rozegrane' => 5, 'bramki_zdobyte' => 3, 'bramki_stracone' => 13],
        ];

        $nazwy = collect($druzyny)->pluck('nazwa')->all();
        Druzyna::whereNotIn('nazwa', $nazwy)->delete();

        foreach ($druzyny as $druzyna) {
            Druzyna::updateOrCreate(
                ['nazwa' => $druzyna['nazwa']],
                $druzyna
            );
        }
    }
}
