<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Druzyna;
use App\Models\Mecz;

class DaneLigoweSeeder extends Seeder
{
    public function run(): void
    {
        $mecze = [
            [
                'rywal' => 'Zawisza Bydgoszcz',
                'data_meczu' => '2026-09-04 18:00:00',
                'miejsce' => 'PCPN Stalowa Wola',
                'czy_domowy' => true,
            ],
            [
                'rywal' => 'Podhale Nowy Targ',
                'data_meczu' => '2026-09-12 14:00:00',
                'miejsce' => 'Stadion wyjazdowy',
                'czy_domowy' => false,
            ],
            [
                'rywal' => 'Resovia',
                'data_meczu' => '2026-09-20 12:00:00',
                'miejsce' => 'PCPN Stalowa Wola',
                'czy_domowy' => true,
            ],
            [
                'rywal' => 'Znicz Pruszków',
                'data_meczu' => '2026-10-04 13:00:00',
                'miejsce' => 'Stadion wyjazdowy',
                'czy_domowy' => false,
            ],
            [
                'rywal' => 'Śląsk II Wrocław',
                'data_meczu' => '2026-10-10 19:30:00',
                'miejsce' => 'PCPN Stalowa Wola',
                'czy_domowy' => true,
            ],
        ];

        $terminy = collect($mecze)->pluck('data_meczu')->all();
        Mecz::whereNotIn('data_meczu', $terminy)->delete();

        foreach ($mecze as $mecz) {
            $druzyna = Druzyna::where('nazwa', $mecz['rywal'])->first();

            if (!$druzyna) {
                continue;
            }

            Mecz::updateOrCreate(
                [
                    'druzyna_id' => $druzyna->id,
                    'data_meczu' => $mecz['data_meczu'],
                ],
                [
                    'miejsce' => $mecz['miejsce'],
                    'czy_domowy' => $mecz['czy_domowy'],
                    'wynik_stal' => null,
                    'wynik_rywal' => null,
                    'status' => 'Planowany',
                ]
            );
        }
    }
}
