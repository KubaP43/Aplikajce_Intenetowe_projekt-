# Klub_Stal_Stalowa_Wola - dokumentacja projektu (Jakub Pelic 134957)

## Temat projektu

**Klub_Stal_Stalowa_Wola** to aplikacja webowa dla klubu pilkarskiego Stal Stalowa Wola. Jej celem jest polaczenie strony informacyjnej dla kibicow z prostym panelem zarzadzania dla prezesa klubu.

Aplikacja rozwiazuje problem rozproszenia danych: terminarz, tabela ligowa, kadra i bilety znajduja sie w jednym systemie. Kibic moze sprawdzic informacje o klubie i zarezerwowac bilet, a prezes moze zarzadzac meczami, druzynami, pilkarzami oraz rezerwacjami.

Repozytorium GitHub: [KubaP43/Aplikajce_Intenetowe_projekt-](https://github.com/KubaP43/Aplikajce_Intenetowe_projekt-)

## Uruchomienie projektu - developer

### Technologie

| Technologia | Wersja uzyta w projekcie 
| --- | --- | --- |
| PHP | 8.5.6 |
| Laravel | 13.11.2 |
| PostgreSQL | 18.1 |
| Composer | 2.9.8 |
| Blade | Laravel 13.11.2 |
| Tailwind CSS | 4.0.0 |
| Vite | 8.0.0 |
| System operacyjny | Windows 10 |

### Wymagania programowe

Do uruchomienia projektu na czystym komputerze potrzebne sa:

- Windows 10/11, macOS albo Linux,
- PHP 8.5.6 lub zgodne PHP 8.3+,
- Composer 2.9.8 lub nowszy,
- PostgreSQL 18.1 lub zgodny,
- przegladarka internetowa, np. Chrome, Firefox
- opcjonalnie Node.js i npm


### Proces instalacji

1. Pobrac projekt z repozytorium:

```bash
git clone https://github.com/KubaP43/Aplikajce_Intenetowe_projekt-.git
```

2. Przejsc do katalogu projektu:

```bash
cd Aplikajce_Intenetowe_projekt-
```

3. Zainstalowac zaleznosci PHP:

```bash
composer install
```

4. Skopiowac plik konfiguracyjny:

```bash
copy .env.example .env
```

5. Wygenerowac klucz aplikacji:

```bash
php artisan key:generate
```


### Proces konfiguracji

W pliku `.env` nalezy ustawic polaczenie z baza PostgreSQL, np.:

```env
DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5433
DB_DATABASE=Klub_Stal_Stalowa_Wola
DB_USERNAME=postgres
DB_PASSWORD=postgres
```

Nastepnie nalezy utworzyc strukture bazy i dane poczatkowe:

```bash
php artisan migrate --seed
```

Do projektu dolaczony jest tez eksport bazy:

```text
Klub_Stal_Stalowa_Wola.sql
```


### Dane poczatkowe

Seeder tworzy konto prezesa (glownego admina):

```text
E-mail: prezes@stal.pl
Haslo: 1938St@lowka
```

Haslo w bazie jest zapisane jako hash, a nie jako jawny tekst.

### Uruchomienie projektu w terminalu

```bash
php artisan serve
```

Po uruchomieniu aplikacja bedzie dostepna pod adresem:

```text
http://127.0.0.1:8000
```

## Uruchomienie projektu - user

Aplikacja jest projektem webowym uruchamianym lokalnie. W tej wersji nie zostala wdrozona na publiczny hosting, dlatego uzytkownik koncowy korzysta z niej po uruchomieniu serwera developerskiego Laravel.

Wymagania sprzetowe sa niewielkie:

- komputer z systemem Windows, macOS albo Linux,
- przegladarka internetowa,
- minimum 4 GB RAM,
- lokalnie uruchomiony serwer aplikacji i baza PostgreSQL.


## Podrecznik uzytkownika

### Role w systemie

| Rola | Mozliwosci |
| --- | --- |
| Gosc | Przeglada strone glowna, terminarz, tabele, kadre, historie i kontakt |
| Kibic | Moze sie zalogowac, rezerwowac bilety i widziec swoje kody biletow |
| Prezes | Moze zarzadzac terminarzem, kadra, tabela ligowa i widziec dane kupujacych bilety |

### Strona glowna

Na stronie glownej uzytkownik widzi informacje o klubie oraz dane pobrane z bazy: najblizsze mecze i czolowke tabeli.

![Strona glowna](strona_glowna.png)

**Opis:** Zrzut pokazuje glowny ekran aplikacji, menu nawigacyjne, sekcje powitalna i dane z bazy widoczne dla goscia.

### Logowanie

Uzytkownik moze zalogowac sie do systemu przez formularz logowania. Po zalogowaniu system rozpoznaje role uzytkownika.

![Logowanie](logowanie.png)

**Opis:** Formularz logowania, przez ktory kibic lub prezes uzyskuje dostep do funkcji wymagajacych konta.

### Zakup biletu

Kibic wybiera mecz, trybune oraz typ biletu. Po zapisaniu system generuje kod biletu, np. `STAL-1234-XYZ`.

![Bilety](bilety.png)

**Opis:** Widok biletow. Gosc widzi komunikat o koniecznosci zalogowania, a zalogowany kibic moze zarezerwowac bilet.

Najwazniejszy przypadek brzegowy: jeden kibic moze kupic maksymalnie jeden bilet na jeden mecz. System blokuje ponowny zakup na to samo spotkanie.

### Udokumentowany CRUD zasobu zależnego: Bilety

W projekcie jako glowny zasob CRUD opisano **bilety**. Bilet jest zasobem zaleznym od innych tabel:

- `bilety.mecz_id` laczy bilet z tabela `mecze`,
- `bilety.uzytkownik_id` laczy bilet z tabela `uzytkownicy`,
- jeden mecz moze miec wiele biletow,
- jeden uzytkownik moze miec wiele biletow, ale maksymalnie jeden na konkretny mecz.

#### CREATE - dodawanie biletu

Dodawanie biletu odbywa sie przez formularz zakupu. Uzytkownik nie wpisuje recznie identyfikatora meczu, tylko wybiera mecz z listy rozwijanej. Dzieki temu formularz odwzorowuje relacje miedzy tabelami i ogranicza ryzyko bledow.

Formularz zawiera:

- wybor meczu z listy,
- wybor trybuny/sektora,
- wybor typu biletu: normalny albo ulgowy.

Walidacja po stronie klienta korzysta z wymaganych pol formularza, a walidacja po stronie serwera Laravel sprawdza, czy wybrany mecz istnieje w bazie, czy typ biletu jest poprawny i czy uzytkownik nie kupil juz biletu na ten sam mecz.

#### READ - lista biletow

Lista biletow pokazuje dane rezerwacji. Prezes widzi pelne dane kibica, w tym PESEL, wybrany mecz, sektor, typ biletu i kod biletu. Kibic widzi swoje bilety.

Lista ma filtrowanie i sortowanie:

- filtrowanie po sektorze/trybunie,
- filtrowanie po typie biletu,
- sortowanie po dacie dodania,
- sortowanie po typie biletu,
- sortowanie po trybunie/sektorze.

Takie filtry sa logiczne dla tego zasobu, bo prezes moze szybko sprawdzic np. bilety ulgowe albo rezerwacje na konkretna trybune.

#### UPDATE - edycja biletu

Edycja biletu pozwala zmienic dane rezerwacji, np. mecz, sektor albo typ biletu. Formularz edycji korzysta z list rozwijanych i tych samych zasad walidacji co formularz dodawania.

Serwer ponownie sprawdza poprawność danych, aby nie zapisac nieistniejacego meczu, blednego typu biletu albo drugiej rezerwacji tego samego uzytkownika na ten sam mecz.

#### DELETE - usuwanie biletu

Usuwanie biletu odbywa sie przez formularz z metoda `DELETE`. Laravel wymaga tokena CSRF, wiec przypadkowe lub falszywe usuniecie z zewnetrznej strony jest blokowane.

Przed usunieciem system sprawdza, czy uzytkownik ma prawo wykonac akcje. Prezes moze usuwac rezerwacje administracyjnie, a zwykly kibic nie ma dostepu do panelu prezesa.

#### Dostep dla uzytkownika niezalogowanego

Uzytkownik niezalogowany moze wejsc na zakladke **Bilety** i zobaczyc informacje o sprzedazy oraz komunikat z przyciskami logowania i rejestracji. Nie moze jednak kupic, edytowac ani usunac biletu. Dostep do formularza zakupu wymaga zalogowania.

### Tabela ligowa

Tabela pokazuje miejsca 1-18 i sortuje druzyny wedlug punktow, bilansu bramek oraz liczby strzelonych goli.

![Tabela](tabela.png)

**Opis:** Widok tabeli ligowej Betclic 2. Ligi. Stal Stalowa Wola jest wyrozniona innym kolorem.

### Responsywnosc

Interfejs byl sprawdzany w narzedziach developerskich przegladarki w trybie tabletu. Menu, karty, formularze i tabele dopasowuja sie do mniejszej szerokosci ekranu.

![Widok tablet](tablet_strona_glowna.png)

**Opis:** Strona glowna w widoku tabletu. Elementy ukladaja sie tak, aby pozostaly czytelne na mniejszym ekranie.

### Filtrowanie i sortowanie danych

W zakladce Kadra mozna wyszukiwac pilkarzy po imieniu, nazwisku lub numerze, filtrowac po pozycji i sortowac po statystykach. W tabeli ligowej sortowanie odbywa sie automatycznie wedlug punktow.

### Walidacja i przypadki brzegowe

System obsluguje bledne dane:

- nie mozna wpisac imienia zlozonego z samych cyfr,
- PESEL musi miec 11 cyfr,
- e-mail musi miec poprawny format,
- statystyki nie moga byc ujemne,
- stanowisko lub pozycja musi pochodzic z dozwolonej listy,
- gosc nie moze kupic biletu bez zalogowania,
- kibic nie moze kupic dwoch biletow na ten sam mecz.

### Dane przechowywane przez system

System przechowuje:

- uzytkownikow i ich role,
- dane osobowe wymagane przy rejestracji,
- hashe hasel,
- druzyny ligowe i ich statystyki,
- mecze,
- pilkarzy,
- rezerwacje biletow i wygenerowane kody.

## Plany rozbudowy

W kolejnych wersjach aplikacji można dodać:
- integrację z zewnętrznymi płatnościami internetowymi,
- automatyczne wysyłanie kodu biletu na e-mail klienta,
- panel raportów sprzedażowych dla prezesa,
- eksport zakupionego biletu do pliku PDF,
- system powiadomień dla kibiców,
- optymalizację polegającą na cache'owaniu wybranych zapytań z bazy danych.

## Testowanie

Sprawdzone elementy:

- ladowanie strony glownej,
- ladowanie terminarza,
- ladowanie tabeli,
- ladowanie kadry,
- ladowanie biletow,
- logowanie prezesa,
- walidacja formularzy,
- ograniczenie jednego biletu na jeden mecz,
- responsywnosc w widoku tabletu,
- poprawne dzialanie migracji i seederow.
